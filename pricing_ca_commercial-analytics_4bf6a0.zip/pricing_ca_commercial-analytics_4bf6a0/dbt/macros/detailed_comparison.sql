
{% macro detailed_value_comparison(legacy_table, dp_table, primary_key_columns, compare_columns, filter, filter_col) %}
  
  {% set columns = audit_helper._ensure_all_pks_are_in_column_set(primary_key_columns, compare_columns) %}
  {% set all_columns = columns | join (", ") %}
  with legacy_data as (
    select 
      {{ all_columns }},
      {{ audit_helper._generate_null_safe_surrogate_key(primary_key_columns) }} as dbt_audit_surrogate_key
    from `{{ legacy_table }}`
    {% if filter is defined and filter_col is defined%} 
    where cast({{filter_col}} as STRING) = '{{ filter }}'
    {% endif %}
  ),
  dp_data as (
    select 
      {{ all_columns }},
      {{ audit_helper._generate_null_safe_surrogate_key(primary_key_columns) }} as dbt_audit_surrogate_key
    from `{{ dp_table }}`
    {% if filter is defined and filter_col is defined%} 
    where cast({{filter_col}} as STRING) = '{{ filter }}'
    {% endif %}
  ),
  final as (
    select 
      --coalesce(a.dbt_audit_surrogate_key, b.dbt_audit_surrogate_key) as dbt_audit_surrogate_key,
      {% for column in primary_key_columns %}
        coalesce(a.{{ column }}, b.{{ column }}) as {{ column | lower }},
      {% endfor %}
      {% for comp_column in compare_columns %}
        a.{{ comp_column }} as legacy_{{ comp_column | lower }},
        b.{{ comp_column }} as dp_{{ comp_column | lower }},
        case when a.{{ comp_column }} is null and b.{{ comp_column }} is null then false
          when cast(a.{{ comp_column }} as STRING) = cast(b.{{ comp_column }} as STRING) then false 
        else true end as {{ comp_column | lower }}_has_difference,
      {% endfor %}
      case when a.dbt_audit_surrogate_key is null then 'Not in legacy'
        when b.dbt_audit_surrogate_key is null then 'Not in data product'
      else 'OK' end as missing_records
    from legacy_data a
    full outer join dp_data b
      on a.dbt_audit_surrogate_key = b.dbt_audit_surrogate_key
  )
  select * from final
{% endmacro %}