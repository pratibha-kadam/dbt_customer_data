
--    Derives the sales-team join key.

--    Mirrors the logic already live in the Flash Report source:
--      data-lake-dwh-sls.public.vw_sales_invoices_budget_and_actuals_aggregated_by_calendar_date_2022_no_rls

--    NULL handling: ifnull(...) <> '' is behaviourally identical to the original
--    Territory_code <> "" (NULL falls through to the company/ISO branches) but says
--    so explicitly rather than relying on three-valued logic.


{% macro territory_for_sales_teams(territory_code, company_code, statistic_country_iso) %}
    case
        when ifnull({{ territory_code }}, '') <> ''
            then {{ territory_code }}
        when {{ company_code }} in ('INB', 'FSIP', 'CD', 'MYA', 'UH', 'GMPBE', 'A7')
            then concat({{ company_code }}, '-COMPANY')
        else {{ statistic_country_iso }}
    end
{% endmacro %}



--    Standard projection of the sales-team attributes.

--    `stt.territory` is aliased to sales_team_territory on purpose: most CoMAL
--    models already carry a `territory` column, and selecting both unqualified
--    (as the Flash Report does) either resolves ambiguously or fails view creation
--    on duplicate output column names.


{% macro sales_team_columns(alias='stt') %}
    {{ alias }}.territory_for_salesteams_name,
    {{ alias }}.territory as sales_team_territory,
    {{ alias }}.sub_sales_team,
    {{ alias }}.sales_team,
    {{ alias }}.core_sales_team,
    {{ alias }}.macro_sales_team
{% endmacro %}