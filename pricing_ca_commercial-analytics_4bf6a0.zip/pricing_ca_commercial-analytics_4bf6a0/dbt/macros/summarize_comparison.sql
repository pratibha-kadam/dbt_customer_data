
{% macro summarize_value_comparison(input_table, compare_columns) %}
  
  select 
    count(*) as nbr_records,
    {% for column in compare_columns %}
        sum(if({{ column | lower }}_has_difference, 1, 0)) as {{ column | lower }}_has_difference
        {%- if not loop.last %}, {% endif %}
    {% endfor %}
    from {{ ref(input_table) }}
    where missing_records = 'OK'
    
{% endmacro %}
