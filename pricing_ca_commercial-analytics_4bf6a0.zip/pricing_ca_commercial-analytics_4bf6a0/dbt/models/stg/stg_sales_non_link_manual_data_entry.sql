with source as (
    select * from {{ source('dwh_sls', 'tbl_sales_non_link_manual_data_entry')}}
)
select * from source