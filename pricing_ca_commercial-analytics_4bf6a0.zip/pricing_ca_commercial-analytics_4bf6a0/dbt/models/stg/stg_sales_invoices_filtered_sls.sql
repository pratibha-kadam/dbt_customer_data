{{ config(
    materialized='view'
) }}
with source as (
    select * from {{ source('dwh_sls', 'tbl_sales_invoices_filtered')}}
)
select * from source