with source as (
    select * from {{ source('dwh_prc', 'tbl_integrations')}}
)
select * from source