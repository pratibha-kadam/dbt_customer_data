with source as (
    select
        shipment_date,
        customer_macro_region,
        customer_super_region,
        customer_region,
        customer_sub_region,
        equipment_market,
        equipment_sub_market,
        statistic_country,
        statistic_country_iso,
        sales_channel_code,
        sales_channel_description,
        freight_income_EUR,
        freight_income_currency_cust,
        freight_expense_system_EUR,
        freight_expense_system_currency_cust,
        rate_usd,
        rate_brl,
        rate_cad,
        rate_mxn,
        invoice_currency,
        accounts_receivable_group_description,
        delivery_address_name,
        intercompany_or_external,
        is_pick_up,
        freight_term
    from {{ source('dwh_sls', 'tbl_sales_orders_traffic')}}
)
select * from source
