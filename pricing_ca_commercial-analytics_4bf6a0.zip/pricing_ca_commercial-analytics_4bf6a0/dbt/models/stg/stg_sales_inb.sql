with source as (
    select * from {{ source('dwh_sls', 'tbl_sales_INB')}}
)
select * from source