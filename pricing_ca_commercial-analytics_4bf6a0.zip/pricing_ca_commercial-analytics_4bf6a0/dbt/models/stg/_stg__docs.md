# https://docs.getdbt.com/docs/collaborate/documentation#using-docs-blocks

{% docs stg_<table_name> %}

description of staging table stg_<table_name> 

{% enddocs %}