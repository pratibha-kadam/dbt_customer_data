with source as (
    select * from {{ source('dwh_mkt', 'dwh_countries')}}
)
select * from source