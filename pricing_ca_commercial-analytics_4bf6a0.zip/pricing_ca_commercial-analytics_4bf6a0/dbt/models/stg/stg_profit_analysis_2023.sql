with source as (
    select * from {{ source('dwh_prc', 'tbl_profit_analysis_2023')}}
)
select * from source