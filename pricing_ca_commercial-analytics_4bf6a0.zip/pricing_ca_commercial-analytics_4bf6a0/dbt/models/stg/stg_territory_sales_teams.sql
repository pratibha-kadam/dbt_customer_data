{{
    config(
        materialized = 'table'
    )
}}

-- Territory -> sales team mapping, maintained by the business in a Google Sheet
-- and surfaced as a BigQuery table by Customer Master Data.
--
-- Deliberately NOT deduplicated by picking a winner: `select distinct` collapses
-- rows that are genuinely identical, and the unique test on the key then fails
-- loudly if two rows disagree on the sales-team attributes. That is a mapping
-- error to send back to the owner, not something to silently resolve here --
-- a wrong pick fans out revenue in five financial marts.

with source as (

    select
        territory_for_salesteams_code,
        territory_for_salesteams_name,
        territory,
        sub_sales_team,
        sales_team,
        core_sales_team,
        macro_sales_team

    from {{ source('customer_master', 'territory_sales_teams') }}

    where ifnull(territory_for_salesteams_code, '') <> ''

      -- 'TBD' is a placeholder the sheet owner uses for rows not yet assigned.
      -- It carries 4 rows with 3 different sales_team values, so it is a genuine
      -- conflict, not a duplicate to collapse. Anything keyed 'TBD' should fall
      -- out of the join as unmapped (NULL) rather than pick one of three answers
      -- or fan out 4x. Remove this filter once the sheet resolves those rows.
      and territory_for_salesteams_code <> 'TBD'

)

select distinct * from source