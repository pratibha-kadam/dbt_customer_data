with source as (
    select * from {{ source('dwh_sls', 'tbl_sales_FSIP')}}
)
select * from source