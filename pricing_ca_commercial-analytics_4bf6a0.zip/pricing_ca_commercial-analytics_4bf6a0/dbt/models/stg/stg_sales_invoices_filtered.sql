with source as (
    select * from {{ source('dwh_prc', 'vw_sales_invoices_filtered')}}
)
select * from source