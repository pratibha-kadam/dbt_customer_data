with source as (
    select * from {{ source('dwh_dat', 'tbl_country_holiday')}}
)
select * from source