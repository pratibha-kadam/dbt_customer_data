with source as (
    select * from {{ source('int_finance_ca', 'int_operationalfreight_budget_2026')}}
)
select * from source