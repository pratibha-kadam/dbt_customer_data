with source as (
    select * from {{ source('dwh_sls', 'vw_sales_non_link_accounting_data')}}
)
select * from source