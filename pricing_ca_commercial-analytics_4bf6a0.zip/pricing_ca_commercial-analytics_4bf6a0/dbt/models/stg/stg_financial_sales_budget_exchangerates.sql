with source as (
    select * from {{ source('dwh_sls', 'tbl_financial_sales_budget_exchangerates')}}
)
select * from source