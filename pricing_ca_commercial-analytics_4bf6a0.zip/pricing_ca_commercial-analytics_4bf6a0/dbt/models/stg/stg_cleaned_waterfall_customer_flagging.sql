with source as (
    select * from {{ source('dwh_prc', 'vw_prc_cleaned_waterfall_customer_flagging_max')}}
)
select * from source
