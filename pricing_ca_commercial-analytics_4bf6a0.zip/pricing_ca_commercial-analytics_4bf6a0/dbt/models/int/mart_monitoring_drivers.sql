{{ config(
    materialized='table',
    partition_by={
      "field": "period",
      "data_type": "date",
      "granularity": "day"
    },
    cluster_by="sub_region"
) }}

with country_mapping as (

select
      distinct
        Statistic_country,
        Statistic_country_iso,
        case Statistic_country_iso
              when 'GU' then 'Other AUSTRALIA'
              when 'PG' then 'Other AUSTRALIA'
              when 'SB' then 'Other AUSTRALIA'
              when 'MM' then 'Other SEA'
              when 'LA' then 'Other SEA'
              when 'KH' then 'Other SEA'
              when 'BN' then 'Other SEA'
              when 'NP' then 'Other SAARC'
              when 'MV' then 'Other SAARC'
              when 'MO' then 'Other CHINA'
              when 'MN' then 'Other CHINA'
              when 'AZ' then 'Other NEE'
              when 'GE' then 'Other NEE'
              when 'KG' then 'Other NEE'
              when 'UZ' then 'Other NEE'
              when 'AM' then 'Other NEE'
              when 'TM' then 'Other NEE'
              when 'AL' then 'Other SEE'
              when 'MK' then 'Other SEE'
              when 'MK' then 'Other SEE'
              when 'MD' then 'Other SEE'
              when 'XK' then 'Other SEE'
              when 'ME' then 'Other SEE'
              when 'QA' then 'Other Middle East'
              when 'LB' then 'Other Middle East'
              when 'PK' then 'Other Middle East'
              when 'BH' then 'Other Middle East'
              when 'JO' then 'Other Middle East'
              when 'IQ' then 'Other Middle East'
              when 'KW' then 'Other Middle East'
              when 'YE' then 'Other Middle East'
              when 'GH' then 'Other Northern Africa'
              when 'MU' then 'Other Northern Africa'
              when 'GA' then 'Other Northern Africa'
              when 'MG' then 'Other Northern Africa'
              when 'BF' then 'Other Northern Africa'
              when 'LY' then 'Other Northern Africa'
              when 'CD' then 'Other Northern Africa'
              when 'DJ' then 'Other Northern Africa'
              when 'SN' then 'Other Northern Africa'
              when 'CV' then 'Other Northern Africa'
              when 'RW' then 'Other Northern Africa'
              when 'GN' then 'Other Northern Africa'
              when 'CG' then 'Other Northern Africa'
              when 'BJ' then 'Other Northern Africa'
              when 'MR' then 'Other Northern Africa'
              when 'ET' then 'Other Northern Africa'
              when 'SD' then 'Other Northern Africa'
              when 'ML' then 'Other Northern Africa'
              when 'GM' then 'Other Northern Africa'
              when 'NE' then 'Other Northern Africa'
              when 'TG' then 'Other Northern Africa'
              when 'SL' then 'Other Northern Africa'
              when 'SO' then 'Other Northern Africa'
              when 'SC' then 'Other Northern Africa'
              when 'LR' then 'Other Northern Africa'
              when 'TD' then 'Other Northern Africa'
              when 'BI' then 'Other Northern Africa'
              when 'MZ' then 'Other Southern Africa'
              when 'KE' then 'Other Southern Africa'
              when 'NA' then 'Other Southern Africa'
              when 'ZW' then 'Other Southern Africa'
              when 'BW' then 'Other Southern Africa'
              when 'SZ' then 'Other Southern Africa'
              when 'ZM' then 'Other Southern Africa'
              when 'TZ' then 'Other Southern Africa'
              when 'UG' then 'Other Southern Africa'
              when 'MW' then 'Other Southern Africa'
              when 'LS' then 'Other Southern Africa'
              when 'BB' then 'Other LATIN AMERICA'
              when 'BZ' then 'Other LATIN AMERICA'
              when 'SR' then 'Other LATIN AMERICA'
              when 'KY' then 'Other LATIN AMERICA'
              when 'HN' then 'Other LATIN AMERICA'
              when 'JM' then 'Other LATIN AMERICA'
              when 'SV' then 'Other LATIN AMERICA'
              when 'CW' then 'Other LATIN AMERICA'
              when 'CW' then 'Other LATIN AMERICA'
              when 'BO' then 'Other LATIN AMERICA'
              when 'NI' then 'Other LATIN AMERICA'
              when 'GY' then 'Other LATIN AMERICA'
              when 'VG' then 'Other LATIN AMERICA'
              when 'HT' then 'Other LATIN AMERICA'
              when 'JE' then 'Other UK/IRELAND'
              when 'GG' then 'Other UK/IRELAND'
              when 'IM' then 'Other UK/IRELAND'
              when 'FO' then 'Other NORDICS'
              when 'GL' then 'Other NORDICS'
              when 'RE' then 'Other FRANCE'
              when 'GP' then 'Other FRANCE'
              when 'MQ' then 'Other FRANCE'
              when 'GF' then 'Other FRANCE'
              when 'YT' then 'Other FRANCE'
              when 'NC' then 'Other FRANCE'
              when 'PF' then 'Other FRANCE'
              when 'MF' then 'Other FRANCE'
              when 'BL' then 'Other FRANCE'
              when 'VU' then 'Other FRANCE'
              when 'WF' then 'Other FRANCE'
              when 'MC' then 'Other FRANCE'
              when 'IC' then 'Other IBERICA'
              when 'AO' then 'Other IBERICA'
        else Statistic_country end as Statistic_country_new
        
      from {{ref('int_profit_analysis_budget_growth_decomposition')}}

)

-- Getting the dimensions/level of calculation for the growth decomposition
, dimensions as (
  
                  select *
                  from ( 
                      select  
                      distinct 
                      --- Calculation level
                        ifnull(SKU_no, "") as SKU_no,

                        ifnull(equipment_market, "") as equipment_market,
                        ifnull(equipment_sub_market, "") as equipment_sub_market,
                        equipment_id_code,
                      
                        ifnull(Statistic_country,"" ) as Statistic_country,
                        ifnull(Statistic_country_iso,"") as Statistic_country_iso,

                        ifnull(brm_grouping,"") as brm_grouping,
                        ifnull(brm_grouping_sales_team,"") as brm_grouping_sales_team,

                        ifnull(Currency_transaction,"") as Currency_transaction,

                        ifnull(Product_category,"") as Product_category,
                        ifnull(product_subcategory,"") as product_subcategory,
                        ifnull(product_class,"") as product_class,
                        ifnull(product_type,"") as product_type,
                        ifnull(product_growth_classification_macro_region,"") as product_growth_classification_macro_region,

                        ifnull(TVH_no_Brand_code,"") as TVH_no_Brand_code,
                        ifnull(TVH_no_Brand_descr,"") as TVH_no_Brand_descr,
                        ifnull(unit,"") as unit

                        from {{ref('int_profit_analysis_budget_growth_decomposition')}}
                          where
                          extract(YEAR from sales_invoice_date) in (2025,2026)
                          --and source_system_new = 'Link'
                      ),
                  unnest (GENERATE_DATE_ARRAY('2025-01-01','2026-12-01', interval 1 month)) as Period
                )

--- GROWTH DECOMPOSITION | month over month calculation ---------------------------------------------------------------------------------------------
    -- STEP 1: Get measures on SKU level for Current Period

, step1_measures_on_SKU_level_mom_CP as (

      select  
          --- Calculation level
            SKU_no,

            equipment_market,
            equipment_sub_market,
            equipment_id_code,

            Statistic_country,
            Statistic_country_iso,

            brm_grouping,
            brm_grouping_sales_team,

            Currency_transaction,

            product_category, 
            product_subcategory, 
            product_class,
            product_type,
            product_growth_classification_macro_region,

            TVH_no_Brand_code,
            TVH_no_Brand_descr,
            unit,

            date_trunc(Sales_invoice_date, month)                                                                                    as Period, 

          --- Sales
            sum(Delivered_amount_transaction_cur * budget_rate_eur)                                                                  as sales_amount_EUR_CP,
            sum(Delivered_amount_transaction_cur * budget_rate_usd)                                                                  as sales_amount_USD_CP,
            sum(Delivered_amount_transaction_cur * budget_rate_cad)                                                                  as sales_amount_CAD_CP,
            sum(Delivered_amount_transaction_cur * budget_rate_mxn)                                                                  as sales_amount_MXN_CP,
            sum(Delivered_amount_transaction_cur * budget_rate_brl)                                                                  as sales_amount_BRL_CP,

            sum(Delivered_amount_transaction_cur)                                                                                    as sales_amount_transaction_cur_CP,

            sum(case when is_integrated_flag = false then Fees_sales_transaction_cur * budget_rate_eur end)                           as Fees_sales_EUR_CP,
            sum(case when is_integrated_flag = false then Fees_sales_transaction_cur * budget_rate_usd end)                           as Fees_sales_USD_CP,
            sum(case when is_integrated_flag = false then Fees_sales_transaction_cur * budget_rate_cad end)                           as Fees_sales_CAD_CP,
            sum(case when is_integrated_flag = false then Fees_sales_transaction_cur * budget_rate_mxn end)                           as Fees_sales_MXN_CP,
            sum(case when is_integrated_flag = false then Fees_sales_transaction_cur * budget_rate_brl end)                           as Fees_sales_BRL_CP,

            sum(case when is_integrated_flag = false then Rebates_sales_transaction_cur * budget_rate_eur end)                        as Rebates_sales_EUR_CP,
            sum(case when is_integrated_flag = false then Rebates_sales_transaction_cur * budget_rate_usd end)                        as Rebates_sales_USD_CP,
            sum(case when is_integrated_flag = false then Rebates_sales_transaction_cur * budget_rate_cad end)                        as Rebates_sales_CAD_CP,
            sum(case when is_integrated_flag = false then Rebates_sales_transaction_cur * budget_rate_mxn end)                        as Rebates_sales_MXN_CP,
            sum(case when is_integrated_flag = false then Rebates_sales_transaction_cur * budget_rate_brl end)                        as Rebates_sales_BRL_CP,

            sum(case when is_integrated_flag = false then warranties_sales_transaction_cur * budget_rate_eur end)                     as warranties_sales_EUR_CP,
            sum(case when is_integrated_flag = false then warranties_sales_transaction_cur * budget_rate_usd end)                     as warranties_sales_USD_CP,
            sum(case when is_integrated_flag = false then warranties_sales_transaction_cur * budget_rate_cad end)                     as warranties_sales_CAD_CP,
            sum(case when is_integrated_flag = false then warranties_sales_transaction_cur * budget_rate_mxn end)                     as warranties_sales_MXN_CP,
            sum(case when is_integrated_flag = false then warranties_sales_transaction_cur * budget_rate_brl end)                     as warranties_sales_BRL_CP,

            sum(case when is_integrated_flag = false then returns_on_warranties_sales_transaction_cur * budget_rate_eur end)          as returns_on_warranties_sales_EUR_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_sales_transaction_cur * budget_rate_usd end)          as returns_on_warranties_sales_USD_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_sales_transaction_cur * budget_rate_cad end)          as returns_on_warranties_sales_CAD_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_sales_transaction_cur * budget_rate_mxn end)          as returns_on_warranties_sales_MXN_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_sales_transaction_cur * budget_rate_brl end)          as returns_on_warranties_sales_BRL_CP,

            sum(case when is_integrated_flag = false then returns_sales_transaction_cur * budget_rate_eur end)                        as returns_sales_EUR_CP,
            sum(case when is_integrated_flag = false then returns_sales_transaction_cur * budget_rate_usd end)                        as returns_sales_USD_CP,
            sum(case when is_integrated_flag = false then returns_sales_transaction_cur * budget_rate_cad end)                        as returns_sales_CAD_CP,
            sum(case when is_integrated_flag = false then returns_sales_transaction_cur * budget_rate_mxn end)                        as returns_sales_MXN_CP,
            sum(case when is_integrated_flag = false then returns_sales_transaction_cur * budget_rate_brl end)                        as returns_sales_BRL_CP,

            sum(case when is_integrated_flag = false then Noncommercial_sales_transaction_cur * budget_rate_eur end)                  as noncommercial_sales_EUR_CP,
            sum(case when is_integrated_flag = false then Noncommercial_sales_transaction_cur * budget_rate_usd end)                  as noncommercial_sales_USD_CP,
            sum(case when is_integrated_flag = false then Noncommercial_sales_transaction_cur * budget_rate_cad end)                  as noncommercial_sales_CAD_CP,
            sum(case when is_integrated_flag = false then Noncommercial_sales_transaction_cur * budget_rate_mxn end)                  as noncommercial_sales_MXN_CP,
            sum(case when is_integrated_flag = false then Noncommercial_sales_transaction_cur * budget_rate_brl end)                  as noncommercial_sales_BRL_CP,

            sum(case when is_integrated_flag = true then Delivered_amount_transaction_cur * budget_rate_eur end)                      as integration_sales_EUR_CP,
            sum(case when is_integrated_flag = true then Delivered_amount_transaction_cur * budget_rate_usd end)                      as integration_sales_USD_CP,
            sum(case when is_integrated_flag = true then Delivered_amount_transaction_cur * budget_rate_cad end)                      as integration_sales_CAD_CP,
            sum(case when is_integrated_flag = true then Delivered_amount_transaction_cur * budget_rate_mxn end)                      as integration_sales_MXN_CP,
            sum(case when is_integrated_flag = true then Delivered_amount_transaction_cur * budget_rate_brl end)                      as integration_sales_BRL_CP,


            sum(case when is_integrated_flag = false then orders_sales_transaction_cur * budget_rate_eur end)                         as orders_sales_EUR_CP, 
            sum(case when is_integrated_flag = false then orders_sales_transaction_cur * budget_rate_usd end)                         as orders_sales_USD_CP, 
            sum(case when is_integrated_flag = false then orders_sales_transaction_cur * budget_rate_cad end)                         as orders_sales_CAD_CP, 
            sum(case when is_integrated_flag = false then orders_sales_transaction_cur * budget_rate_mxn end)                         as orders_sales_MXN_CP, 
            sum(case when is_integrated_flag = false then orders_sales_transaction_cur * budget_rate_brl end)                         as orders_sales_BRL_CP, 

            sum(case when is_integrated_flag = false then orders_sales_transaction_cur end)                                           as orders_sales_transaction_currency_CP,

          --- Cost (group)
            sum(case when is_integrated_flag = false then Fees_cost_transaction_cur * budget_rate_eur end)                            as Fees_cost_EUR_CP,
            sum(case when is_integrated_flag = false then Fees_cost_transaction_cur * budget_rate_usd end)                            as Fees_cost_USD_CP,
            sum(case when is_integrated_flag = false then Fees_cost_transaction_cur * budget_rate_cad end)                            as Fees_cost_CAD_CP,
            sum(case when is_integrated_flag = false then Fees_cost_transaction_cur * budget_rate_mxn end)                            as Fees_cost_MXN_CP,
            sum(case when is_integrated_flag = false then Fees_cost_transaction_cur * budget_rate_brl end)                            as Fees_cost_BRL_CP,

            sum(case when is_integrated_flag = false then Rebates_cost_transaction_cur * budget_rate_eur end)                         as Rebates_cost_EUR_CP,
            sum(case when is_integrated_flag = false then Rebates_cost_transaction_cur * budget_rate_usd end)                         as Rebates_cost_USD_CP,
            sum(case when is_integrated_flag = false then Rebates_cost_transaction_cur * budget_rate_cad end)                         as Rebates_cost_CAD_CP,
            sum(case when is_integrated_flag = false then Rebates_cost_transaction_cur * budget_rate_mxn end)                         as Rebates_cost_MXN_CP,
            sum(case when is_integrated_flag = false then Rebates_cost_transaction_cur * budget_rate_brl end)                         as Rebates_cost_BRL_CP,

            sum(case when is_integrated_flag = false then warranties_cost_transaction_cur * budget_rate_eur end)                      as warranties_cost_EUR_CP,           
            sum(case when is_integrated_flag = false then warranties_cost_transaction_cur * budget_rate_usd end)                      as warranties_cost_USD_CP,
            sum(case when is_integrated_flag = false then warranties_cost_transaction_cur * budget_rate_cad end)                      as warranties_cost_CAD_CP,
            sum(case when is_integrated_flag = false then warranties_cost_transaction_cur * budget_rate_mxn end)                      as warranties_cost_MXN_CP,
            sum(case when is_integrated_flag = false then warranties_cost_transaction_cur * budget_rate_brl end)                      as warranties_cost_BRL_CP,

            sum(case when is_integrated_flag = false then returns_on_warranties_cost_transaction_cur * budget_rate_eur end)           as returns_on_warranties_cost_EUR_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_transaction_cur * budget_rate_usd end)           as returns_on_warranties_cost_USD_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_transaction_cur * budget_rate_cad end)           as returns_on_warranties_cost_CAD_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_transaction_cur * budget_rate_mxn end)           as returns_on_warranties_cost_MXN_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_transaction_cur * budget_rate_brl end)           as returns_on_warranties_cost_BRL_CP,

            sum(case when is_integrated_flag = false then returns_cost_transaction_cur * budget_rate_eur end)                         as returns_cost_EUR_CP,
            sum(case when is_integrated_flag = false then returns_cost_transaction_cur * budget_rate_usd end)                         as returns_cost_USD_CP,
            sum(case when is_integrated_flag = false then returns_cost_transaction_cur * budget_rate_cad end)                         as returns_cost_CAD_CP,
            sum(case when is_integrated_flag = false then returns_cost_transaction_cur * budget_rate_mxn end)                         as returns_cost_MXN_CP,
            sum(case when is_integrated_flag = false then returns_cost_transaction_cur * budget_rate_brl end)                         as returns_cost_BRL_CP,

            sum(case when is_integrated_flag = false then noncommercial_cost_transaction_cur * budget_rate_eur end)                   as noncommercial_cost_EUR_CP,
            sum(case when is_integrated_flag = false then noncommercial_cost_transaction_cur * budget_rate_usd end)                   as noncommercial_cost_USD_CP,
            sum(case when is_integrated_flag = false then noncommercial_cost_transaction_cur * budget_rate_cad end)                   as noncommercial_cost_CAD_CP,
            sum(case when is_integrated_flag = false then noncommercial_cost_transaction_cur * budget_rate_mxn end)                   as noncommercial_cost_MXN_CP,
            sum(case when is_integrated_flag = false then noncommercial_cost_transaction_cur * budget_rate_brl end)                   as noncommercial_cost_BRL_CP,

            sum(case when is_integrated_flag = true then Avg_unit_price_group_amount_transaction_cur * budget_rate_eur end)          as integration_cost_EUR_CP,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_amount_transaction_cur * budget_rate_usd end)          as integration_cost_USD_CP,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_amount_transaction_cur * budget_rate_cad end)          as integration_cost_CAD_CP,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_amount_transaction_cur * budget_rate_mxn end)          as integration_cost_MXN_CP,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_amount_transaction_cur * budget_rate_brl end)          as integration_cost_BRL_CP,

            sum(case when is_integrated_flag = false then orders_cost_transaction_cur * budget_rate_eur end)                          as orders_cost_EUR_CP,
            sum(case when is_integrated_flag = false then orders_cost_transaction_cur * budget_rate_usd end)                          as orders_cost_USD_CP,
            sum(case when is_integrated_flag = false then orders_cost_transaction_cur * budget_rate_cad end)                          as orders_cost_CAD_CP,
            sum(case when is_integrated_flag = false then orders_cost_transaction_cur * budget_rate_mxn end)                          as orders_cost_MXN_CP,
            sum(case when is_integrated_flag = false then orders_cost_transaction_cur * budget_rate_brl end)                          as orders_cost_BRL_CP,

            sum(case when is_integrated_flag = false then orders_cost_transaction_cur end)                                            as orders_cost_transaction_currency_CP,

          --- Cost (group landed)
            sum(case when is_integrated_flag = false then Fees_cost_landed_transaction_cur * budget_rate_eur end)                     as Fees_cost_landed_EUR_CP,
            sum(case when is_integrated_flag = false then Fees_cost_landed_transaction_cur * budget_rate_usd end)                     as Fees_cost_landed_USD_CP,
            sum(case when is_integrated_flag = false then Fees_cost_landed_transaction_cur * budget_rate_cad end)                     as Fees_cost_landed_CAD_CP,
            sum(case when is_integrated_flag = false then Fees_cost_landed_transaction_cur * budget_rate_mxn end)                     as Fees_cost_landed_MXN_CP,
            sum(case when is_integrated_flag = false then Fees_cost_landed_transaction_cur * budget_rate_brl end)                     as Fees_cost_landed_BRL_CP,

            sum(case when is_integrated_flag = false then Rebates_cost_landed_transaction_cur * budget_rate_eur end)                  as Rebates_cost_landed_EUR_CP,
            sum(case when is_integrated_flag = false then Rebates_cost_landed_transaction_cur * budget_rate_usd end)                  as Rebates_cost_landed_USD_CP,
            sum(case when is_integrated_flag = false then Rebates_cost_landed_transaction_cur * budget_rate_cad end)                  as Rebates_cost_landed_CAD_CP,
            sum(case when is_integrated_flag = false then Rebates_cost_landed_transaction_cur * budget_rate_mxn end)                  as Rebates_cost_landed_MXN_CP,
            sum(case when is_integrated_flag = false then Rebates_cost_landed_transaction_cur * budget_rate_brl end)                  as Rebates_cost_landed_BRL_CP,

            sum(case when is_integrated_flag = false then warranties_cost_landed_transaction_cur * budget_rate_eur end)               as warranties_cost_landed_EUR_CP,
            sum(case when is_integrated_flag = false then warranties_cost_landed_transaction_cur * budget_rate_usd end)               as warranties_cost_landed_USD_CP,
            sum(case when is_integrated_flag = false then warranties_cost_landed_transaction_cur * budget_rate_cad end)               as warranties_cost_landed_CAD_CP,
            sum(case when is_integrated_flag = false then warranties_cost_landed_transaction_cur * budget_rate_mxn end)               as warranties_cost_landed_MXN_CP,
            sum(case when is_integrated_flag = false then warranties_cost_landed_transaction_cur * budget_rate_brl end)               as warranties_cost_landed_BRL_CP,

            sum(case when is_integrated_flag = false then returns_on_warranties_cost_landed_transaction_cur * budget_rate_eur end)    as returns_on_warranties_cost_landed_EUR_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_landed_transaction_cur * budget_rate_usd end)    as returns_on_warranties_cost_landed_USD_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_landed_transaction_cur * budget_rate_cad end)    as returns_on_warranties_cost_landed_CAD_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_landed_transaction_cur * budget_rate_mxn end)    as returns_on_warranties_cost_landed_MXN_CP,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_landed_transaction_cur * budget_rate_brl end)    as returns_on_warranties_cost_landed_BRL_CP,

            sum(case when is_integrated_flag = false then returns_cost_landed_transaction_cur * budget_rate_eur end)                  as returns_cost_landed_EUR_CP,
            sum(case when is_integrated_flag = false then returns_cost_landed_transaction_cur * budget_rate_usd end)                  as returns_cost_landed_USD_CP,
            sum(case when is_integrated_flag = false then returns_cost_landed_transaction_cur * budget_rate_cad end)                  as returns_cost_landed_CAD_CP,
            sum(case when is_integrated_flag = false then returns_cost_landed_transaction_cur * budget_rate_mxn end)                  as returns_cost_landed_MXN_CP,
            sum(case when is_integrated_flag = false then returns_cost_landed_transaction_cur * budget_rate_brl end)                  as returns_cost_landed_BRL_CP,

            sum(case when is_integrated_flag = false then noncommercial_cost_landed_transaction_cur * budget_rate_eur end)            as noncommercial_cost_landed_EUR_CP,
            sum(case when is_integrated_flag = false then noncommercial_cost_landed_transaction_cur * budget_rate_usd end)            as noncommercial_cost_landed_USD_CP,
            sum(case when is_integrated_flag = false then noncommercial_cost_landed_transaction_cur * budget_rate_cad end)            as noncommercial_cost_landed_CAD_CP,
            sum(case when is_integrated_flag = false then noncommercial_cost_landed_transaction_cur * budget_rate_mxn end)            as noncommercial_cost_landed_MXN_CP,
            sum(case when is_integrated_flag = false then noncommercial_cost_landed_transaction_cur * budget_rate_brl end)            as noncommercial_cost_landed_BRL_CP,

            sum(case when is_integrated_flag = true then avg_unit_price_group_landed_amount_transaction_cur * budget_rate_eur end)   as integration_cost_landed_EUR_CP,
            sum(case when is_integrated_flag = true then avg_unit_price_group_landed_amount_transaction_cur * budget_rate_usd end)   as integration_cost_landed_USD_CP,
            sum(case when is_integrated_flag = true then avg_unit_price_group_landed_amount_transaction_cur * budget_rate_cad end)   as integration_cost_landed_CAD_CP,
            sum(case when is_integrated_flag = true then avg_unit_price_group_landed_amount_transaction_cur * budget_rate_mxn end)   as integration_cost_landed_MXN_CP,
            sum(case when is_integrated_flag = true then avg_unit_price_group_landed_amount_transaction_cur * budget_rate_brl end)   as integration_cost_landed_BRL_CP,

            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur * budget_rate_eur end)                   as orders_cost_landed_EUR_CP,
            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur * budget_rate_usd end)                   as orders_cost_landed_USD_CP,
            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur * budget_rate_cad end)                   as orders_cost_landed_CAD_CP,
            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur * budget_rate_mxn end)                   as orders_cost_landed_MXN_CP,
            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur * budget_rate_brl end)                   as orders_cost_landed_BRL_CP,

            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur end)                                     as orders_cost_landed_transaction_currency_CP,
          
          --- QTY
            sum(case when is_integrated_flag = false then ifnull(orders_quantity,0) end)                                              as orders_quantity_CP,

      from {{ref('int_profit_analysis_budget_growth_decomposition')}} s1

      LEFT JOIN (
          SELECT
            budget_month,
            currency_from,
            min(case when currency_to = 'EUR' then budget_exchange_rate else null end) as budget_rate_eur,
            min(case when currency_to = 'USD' then budget_exchange_rate else null end) as budget_rate_usd,
            min(case when currency_to = 'CAD' then budget_exchange_rate else null end) as budget_rate_cad,
            min(case when currency_to = 'MXN' then budget_exchange_rate else null end) as budget_rate_mxn,
            min(case when currency_to = 'BRL' then budget_exchange_rate else null end) as budget_rate_brl,
          FROM
            {{ref('stg_financial_sales_budget_exchangerates')}}
          WHERE
            currency_to IN ('EUR', 'USD', 'CAD', 'MXN', 'BRL')
            and budget_year = 2026         # Only get 2026 values, so we can apply 2026 rates to 2025 as well
          GROUP BY
            budget_month,
            currency_from) br 
          ON 
              currency_transaction = br.currency_from
              AND extract(month from sales_invoice_date) = extract(month from br.budget_month)
        

        where
        extract(YEAR from sales_invoice_date) in (2025,2026)
        --and source_system_new = 'Link'
        group by all

)

-- Get all the permutations / default structure (Called _part2)

, step1_measures_on_SKU_level_mom_CP_part2 as (

  select distinct

          dim.*,
          s1.* except  (SKU_no,equipment_market,equipment_sub_market,equipment_id_code,
          Statistic_country,
          Statistic_country_iso,
          brm_grouping,
          brm_grouping_sales_team,
          Currency_transaction,
          product_category, 
          product_subcategory, 
          product_class,
          product_type,
          product_growth_classification_macro_region,
          TVH_no_Brand_code,
          TVH_no_Brand_descr,
          unit,
          period)

  from dimensions dim
      left outer join step1_measures_on_SKU_level_mom_CP s1
      on ifnull(dim.SKU_no, "") = ifnull(s1.SKU_no,"")
          and ifnull(dim.equipment_market,"") = ifnull(s1.equipment_market,"")
          and ifnull(dim.equipment_sub_market,"") = ifnull(s1.equipment_sub_market,"")
          and dim.equipment_id_code= s1.equipment_id_code
          and ifnull(dim.Statistic_country,"") = ifnull(s1.Statistic_country,"")
          and ifnull(dim.Statistic_country_iso,"") = ifnull(s1.Statistic_country_iso,"")
          and ifnull(dim.brm_grouping,"") = ifnull(s1.brm_grouping,"")
          and ifnull(dim.brm_grouping_sales_team,"") = ifnull(s1.brm_grouping_sales_team,"")
          and ifnull(dim.Currency_transaction,"") = ifnull(s1.Currency_transaction,"")
          and ifnull(dim.product_category,"") = ifnull(s1.product_category,"")
          and ifnull(dim.product_subcategory,"") = ifnull(s1.product_subcategory,"")
          and ifnull(dim.product_class,"") = ifnull(s1.product_class,"")
          and ifnull(dim.product_type,"") = ifnull(s1.product_type,"")
          and ifnull(dim.product_growth_classification_macro_region,"") = ifnull(s1.product_growth_classification_macro_region,"")
          and ifnull(dim.TVH_no_Brand_code,"") = ifnull(s1.TVH_no_Brand_code,"")
          and ifnull(dim.TVH_no_Brand_descr,"") = ifnull(s1.TVH_no_Brand_descr,"")
          and ifnull(dim.unit,"") = ifnull(s1.unit,"")
          and dim.period = s1.period

        )

    -- STEP 2: Add lagged values

, step2_measures_on_SKU_level_mom_PP as (

      select *,
            --- Add lag variables

            --- Sales
            lag(sales_amount_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as sales_amount_EUR_PP,
            
            lag(sales_amount_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as sales_amount_USD_PP,
            
            lag(sales_amount_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as sales_amount_CAD_PP,
            
            lag(sales_amount_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as sales_amount_MXN_PP,
            
            lag(sales_amount_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as sales_amount_BRL_PP,
              -------------------------------------------

            lag(Fees_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_sales_EUR_PP,
            
            lag(Fees_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_sales_USD_PP,

            lag(Fees_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_sales_CAD_PP,

            lag(Fees_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_sales_MXN_PP,

            lag(Fees_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_sales_BRL_PP,
            -----------------------------------------------------------------------

            lag(Rebates_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_sales_EUR_PP,
            
            lag(Rebates_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_sales_USD_PP,
            
            lag(Rebates_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_sales_CAD_PP,
            
            lag(Rebates_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_sales_MXN_PP,
            
            lag(Rebates_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_sales_BRL_PP,
            -------------------------------------------------------------------

            lag(warranties_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_sales_EUR_PP,
            
            lag(warranties_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_sales_USD_PP,
            
            lag(warranties_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_sales_CAD_PP,
            
            lag(warranties_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_sales_MXN_PP,
            
            lag(warranties_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_sales_BRL_PP,
            ----------------------------------------------------------------

            lag(returns_on_warranties_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_sales_EUR_PP,
            
            lag(returns_on_warranties_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_sales_USD_PP,
            
            lag(returns_on_warranties_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_sales_CAD_PP,
            
            lag(returns_on_warranties_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_sales_MXN_PP,
            
            lag(returns_on_warranties_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_sales_BRL_PP,
            -----------------------------------------------------------

            lag(returns_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_sales_EUR_PP,
            
            lag(returns_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_sales_USD_PP,
            
            lag(returns_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_sales_CAD_PP,
            
            lag(returns_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_sales_MXN_PP,
            
            lag(returns_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_sales_BRL_PP,
            ---------------------------------------------------

            lag(noncommercial_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_sales_EUR_PP,
            
            lag(noncommercial_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_sales_USD_PP,
            
            lag(noncommercial_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_sales_CAD_PP,
            
            lag(noncommercial_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_sales_MXN_PP,
            
            lag(noncommercial_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_sales_BRL_PP,
            -----------------------------------------------------------

            lag(integration_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_sales_EUR_PP,

            lag(integration_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_sales_USD_PP,

            lag(integration_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_sales_CAD_PP,

            lag(integration_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_sales_MXN_PP,

            lag(integration_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_sales_BRL_PP,
            --------------------------------------------------------------                          

            lag(orders_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_EUR_PP,
            
            lag(orders_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_USD_PP,
            
            lag(orders_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_CAD_PP,
            
            lag(orders_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_MXN_PP,
            
            lag(orders_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_BRL_PP,
            ------------------------------------------------------------------------

            lag(orders_sales_transaction_currency_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_transaction_currency_PP,

            --- Cost (group)
            lag(Fees_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_EUR_PP,
            
            lag(Fees_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_USD_PP,
            
            lag(Fees_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_CAD_PP,
            
            lag(Fees_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_MXN_PP,
            
            lag(Fees_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_BRL_PP,
            ---------------------------------------------------------

            lag(Rebates_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_EUR_PP,
            
            lag(Rebates_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_USD_PP,
            
            lag(Rebates_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_CAD_PP,
            
            lag(Rebates_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_MXN_PP,
            
            lag(Rebates_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_BRL_PP,
            -----------------------------------------------------

            lag(warranties_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_EUR_PP,
            
            lag(warranties_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_USD_PP,
            
            lag(warranties_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_CAD_PP,
            
            lag(warranties_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_MXN_PP,
            
            lag(warranties_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_BRL_PP,
            --------------------------------------------------------------

            lag(returns_on_warranties_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_EUR_PP,
            
            lag(returns_on_warranties_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_USD_PP,
            
            lag(returns_on_warranties_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_CAD_PP,
            
            lag(returns_on_warranties_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_MXN_PP,
            
            lag(returns_on_warranties_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_BRL_PP,
            -------------------------------------------------------------------

            lag(returns_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_EUR_PP,
            
            lag(returns_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_USD_PP,
            
            lag(returns_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_CAD_PP,
            
            lag(returns_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_MXN_PP,
            
            lag(returns_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_BRL_PP,
            ------------------------------------------------------------

            lag(noncommercial_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_EUR_PP,
            
            lag(noncommercial_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_USD_PP,
            
            lag(noncommercial_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_CAD_PP,
            
            lag(noncommercial_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_MXN_PP,
            
            lag(noncommercial_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_BRL_PP,
            ----------------------------------------------------------------

            lag(integration_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_EUR_PP,

            lag(integration_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_USD_PP,

            lag(integration_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_CAD_PP,

            lag(integration_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_MXN_PP,

            lag(integration_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_BRL_PP,  
            ------------------------------------------------------------------------                       

            lag(orders_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_EUR_PP,
            
            lag(orders_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_USD_PP,
            
            lag(orders_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_CAD_PP,
            
            lag(orders_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_MXN_PP,
            
            lag(orders_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_BRL_PP,
            -------------------------------------------------------
            
            lag(orders_cost_transaction_currency_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_transaction_currency_PP,

            --- Cost (group landed)
            lag(Fees_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_landed_EUR_PP,
            
            lag(Fees_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_landed_USD_PP,
            
            lag(Fees_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_landed_CAD_PP,
            
            lag(Fees_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_landed_MXN_PP,
            
            lag(Fees_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_landed_BRL_PP,
            ----------------------------------------------------------------------

            lag(Rebates_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_landed_EUR_PP,
            
            lag(Rebates_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_landed_USD_PP,
            
            lag(Rebates_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_landed_CAD_PP,
            
            lag(Rebates_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_landed_MXN_PP,
            
            lag(Rebates_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_landed_BRL_PP,
            ------------------------------------------------------------------------

            lag(warranties_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_landed_EUR_PP,
            
            lag(warranties_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_landed_USD_PP,
            
            lag(warranties_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_landed_CAD_PP,
            
            lag(warranties_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_landed_MXN_PP,
            
            lag(warranties_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_landed_BRL_PP,
            --------------------------------------------------------------

            lag(returns_on_warranties_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_landed_EUR_PP,
            
            lag(returns_on_warranties_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_landed_USD_PP,
            
            lag(returns_on_warranties_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_landed_CAD_PP,
            
            lag(returns_on_warranties_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_landed_MXN_PP,
            
            lag(returns_on_warranties_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_landed_BRL_PP,
            ---------------------------------------------------------------------

            lag(returns_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_landed_EUR_PP,
            
            lag(returns_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_landed_USD_PP,
            
            lag(returns_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_landed_CAD_PP,
            
            lag(returns_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_landed_MXN_PP,
            
            lag(returns_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_landed_BRL_PP,
            -------------------------------------------------------

            lag(noncommercial_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_landed_EUR_PP,
            
            lag(noncommercial_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_landed_USD_PP,
            
            lag(noncommercial_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_landed_CAD_PP,
            
            lag(noncommercial_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_landed_MXN_PP,
            
            lag(noncommercial_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_landed_BRL_PP,
            --------------------------------------------------------------------

            lag(integration_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_landed_EUR_PP,

            lag(integration_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_landed_USD_PP,

            lag(integration_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_landed_CAD_PP,

            lag(integration_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_landed_MXN_PP,

            lag(integration_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_landed_BRL_PP,
            -------------------------------------------------------------                             

            lag(orders_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_EUR_PP,
            
            lag(orders_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_USD_PP,
            
            lag(orders_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_CAD_PP,
            
            lag(orders_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_MXN_PP,
            
            lag(orders_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_BRL_PP,
            ------------------------------------------------------------
            
            lag(orders_cost_landed_transaction_currency_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_transaction_currency_PP,                            

            lag(orders_quantity_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_quantity_PP,

      from step1_measures_on_SKU_level_mom_CP_part2 --changed to step 1 part 2

        )


    -- STEP 3: Do calculations & aggregate

, step3_calculations_on_sku_level_mom_CP as (

    select *,

          --- Calculate recurring, new and lost
          case    when ifnull(orders_quantity_CP,0) > 0  and ifnull(orders_quantity_PP,0) = 0 then 'NEW'
                  when ifnull(orders_quantity_CP,0) = 0  and ifnull(orders_quantity_PP,0) > 0 then 'LOST'
                  when ifnull(orders_quantity_CP,0) > 0  and ifnull(orders_quantity_PP,0) > 0 then 'RECURRING' 
          end as evolution_type,

          --- Calculate average price per unit - needed to calculate sales price effect
          ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0) as average_price_per_unit_transaction_currency_CP,
          ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0) as average_price_per_unit_transaction_currency_PP,

          ifnull(safe_divide(orders_sales_EUR_CP , orders_quantity_CP),0) as average_price_per_unit_EUR_CP,
          ifnull(safe_divide(orders_sales_EUR_PP , orders_quantity_PP),0) as average_price_per_unit_EUR_PP,

          ifnull(safe_divide(orders_sales_USD_CP , orders_quantity_CP),0) as average_price_per_unit_USD_CP,
          ifnull(safe_divide(orders_sales_USD_PP , orders_quantity_PP),0) as average_price_per_unit_USD_PP,

          ifnull(safe_divide(orders_sales_CAD_CP , orders_quantity_CP),0) as average_price_per_unit_CAD_CP,
          ifnull(safe_divide(orders_sales_CAD_PP , orders_quantity_PP),0) as average_price_per_unit_CAD_PP,

          ifnull(safe_divide(orders_sales_MXN_CP , orders_quantity_CP),0) as average_price_per_unit_MXN_CP,
          ifnull(safe_divide(orders_sales_MXN_PP , orders_quantity_PP),0) as average_price_per_unit_MXN_PP,

          ifnull(safe_divide(orders_sales_BRL_CP , orders_quantity_CP),0) as average_price_per_unit_BRL_CP,
          ifnull(safe_divide(orders_sales_BRL_PP , orders_quantity_PP),0) as average_price_per_unit_BRL_PP,

          --- Calculate average cost per unit - needed to calculate sales price effect
          ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0) as average_cost_per_unit_transaction_currency_CP,
          ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0) as average_cost_per_unit_transaction_currency_PP,

          ifnull(safe_divide(orders_cost_EUR_CP , orders_quantity_CP),0) as average_cost_per_unit_EUR_CP,
          ifnull(safe_divide(orders_cost_EUR_PP , orders_quantity_PP),0) as average_cost_per_unit_EUR_PP,

          ifnull(safe_divide(orders_cost_USD_CP , orders_quantity_CP),0) as average_cost_per_unit_USD_CP,
          ifnull(safe_divide(orders_cost_USD_PP , orders_quantity_PP),0) as average_cost_per_unit_USD_PP,

          ifnull(safe_divide(orders_cost_CAD_CP , orders_quantity_CP),0) as average_cost_per_unit_CAD_CP,
          ifnull(safe_divide(orders_cost_CAD_PP , orders_quantity_PP),0) as average_cost_per_unit_CAD_PP,

          ifnull(safe_divide(orders_cost_MXN_CP , orders_quantity_CP),0) as average_cost_per_unit_MXN_CP,
          ifnull(safe_divide(orders_cost_MXN_PP , orders_quantity_PP),0) as average_cost_per_unit_MXN_PP,

          ifnull(safe_divide(orders_cost_BRL_CP , orders_quantity_CP),0) as average_cost_per_unit_BRL_CP,
          ifnull(safe_divide(orders_cost_BRL_PP , orders_quantity_PP),0) as average_cost_per_unit_BRL_PP,

          --- Calculate average cost landed per unit - needed to calculate sales price effect
          ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_transaction_currency_CP,
          ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_transaction_currency_PP,

          ifnull(safe_divide(orders_cost_landed_EUR_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_EUR_CP,
          ifnull(safe_divide(orders_cost_landed_EUR_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_EUR_PP,

          ifnull(safe_divide(orders_cost_landed_USD_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_USD_CP,
          ifnull(safe_divide(orders_cost_landed_USD_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_USD_PP,

          ifnull(safe_divide(orders_cost_landed_CAD_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_CAD_CP,
          ifnull(safe_divide(orders_cost_landed_CAD_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_CAD_PP,

          ifnull(safe_divide(orders_cost_landed_MXN_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_MXN_CP,
          ifnull(safe_divide(orders_cost_landed_MXN_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_MXN_PP,

          ifnull(safe_divide(orders_cost_landed_BRL_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_BRL_CP,
          ifnull(safe_divide(orders_cost_landed_BRL_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_BRL_PP,                            

          --- Calculate price per unit CP for fx rate PP (needed to calculate Fx effect)
          case    when round(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_sales_EUR_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_sales_EUR_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_sales_EUR_PP , orders_quantity_PP),0))))) 
                          end as average_price_per_unit_EUR_CP_with_fx_rate_PP,
          
          case    when round(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_sales_USD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_sales_USD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_sales_USD_PP , orders_quantity_PP),0))))) 
                          end as average_price_per_unit_USD_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_sales_CAD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_sales_CAD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_sales_CAD_PP , orders_quantity_PP),0))))) 
                          end as average_price_per_unit_CAD_CP_with_fx_rate_PP,
          
          case    when round(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_sales_MXN_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_sales_MXN_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_sales_MXN_PP , orders_quantity_PP),0))))) 
                          end as average_price_per_unit_MXN_CP_with_fx_rate_PP,
          
          case    when round(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_sales_BRL_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_sales_BRL_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_sales_BRL_PP , orders_quantity_PP),0))))) 
                          end as average_price_per_unit_BRL_CP_with_fx_rate_PP,

          --- Calculate cost per unit CP for fx rate PP (needed to calculate Fx effect)
          case    when round(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_EUR_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_EUR_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_EUR_PP , orders_quantity_PP),0))))) 
                          end as average_cost_per_unit_EUR_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_USD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_USD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_USD_PP , orders_quantity_PP),0))))) 
                          end as average_cost_per_unit_USD_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_CAD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_CAD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_CAD_PP , orders_quantity_PP),0))))) 
                          end as average_cost_per_unit_CAD_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_MXN_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_MXN_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_MXN_PP , orders_quantity_PP),0))))) 
                          end as average_cost_per_unit_MXN_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_BRL_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_BRL_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_BRL_PP , orders_quantity_PP),0))))) 
                          end as average_cost_per_unit_BRL_CP_with_fx_rate_PP,

          --- Calculate cost landed per unit CP for fx rate PP (needed to calculate Fx effect)
          case    when round(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_landed_EUR_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_landed_EUR_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_landed_EUR_PP , orders_quantity_PP),0))))) 
                          end as average_cost_landed_per_unit_EUR_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_landed_USD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_landed_USD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_landed_USD_PP , orders_quantity_PP),0))))) 
                          end as average_cost_landed_per_unit_USD_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_landed_CAD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_landed_CAD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_landed_CAD_PP , orders_quantity_PP),0))))) 
                          end as average_cost_landed_per_unit_CAD_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_landed_MXN_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_landed_MXN_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_landed_MXN_PP , orders_quantity_PP),0))))) 
                          end as average_cost_landed_per_unit_MXN_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_landed_BRL_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_landed_BRL_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_landed_BRL_PP , orders_quantity_PP),0))))) 
                          end as average_cost_landed_per_unit_BRL_CP_with_fx_rate_PP,

    from step2_measures_on_SKU_level_mom_PP

)

    -- STEP 4: Further aggregations on the right level

, step4_further_calculations_on_sku_level_and_aggregation_mom_CP as (

    select 
          --- Calculation level
            SKU_no,

            equipment_market,
            equipment_sub_market,
            equipment_id_code,

            Statistic_country,
            Statistic_country_iso,

            brm_grouping,
            brm_grouping_sales_team,

            Currency_transaction,

            product_category, 
            product_subcategory, 
            product_class,
            product_type,
            product_growth_classification_macro_region,

            TVH_no_Brand_code,
            TVH_no_Brand_descr,

            unit,

            period, 
            Evolution_type,

      --- Sales
            sum(Fees_sales_EUR_PP) as Fees_sales_EUR_PP,
            sum(Rebates_sales_EUR_PP) as Rebates_sales_EUR_PP,
            sum(warranties_sales_EUR_PP) as warranties_sales_EUR_PP,
            sum(returns_on_warranties_sales_EUR_PP) as returns_on_warranties_sales_EUR_PP,
            sum(returns_sales_EUR_PP) as returns_sales_EUR_PP,
            sum(noncommercial_sales_EUR_PP) as noncommercial_sales_EUR_PP,
            sum(integration_sales_EUR_PP) as integration_sales_EUR_PP,
            sum(ifnull(orders_sales_EUR_PP,0)) as orders_sales_EUR_PP,
            sum(orders_sales_EUR_CP) as orders_sales_EUR_CP,
            sum(sales_amount_EUR_CP) as sales_amount_EUR_CP,
            sum(sales_amount_EUR_PP) as sales_amount_EUR_PP,

            sum(Fees_sales_USD_PP) as Fees_sales_USD_PP,
            sum(Rebates_sales_USD_PP) as Rebates_sales_USD_PP,
            sum(warranties_sales_USD_PP) as warranties_sales_USD_PP,
            sum(returns_on_warranties_sales_USD_PP) as returns_on_warranties_sales_USD_PP,
            sum(returns_sales_USD_PP) as returns_sales_USD_PP,
            sum(noncommercial_sales_USD_PP) as noncommercial_sales_USD_PP,
            sum(integration_sales_USD_PP) as integration_sales_USD_PP,
            sum(ifnull(orders_sales_USD_PP,0)) as orders_sales_USD_PP,
            sum(orders_sales_USD_CP) as orders_sales_USD_CP,
            sum(sales_amount_USD_CP) as sales_amount_USD_CP,
            sum(sales_amount_USD_PP) as sales_amount_USD_PP,

            sum(Fees_sales_CAD_PP) as Fees_sales_CAD_PP,
            sum(Rebates_sales_CAD_PP) as Rebates_sales_CAD_PP,
            sum(warranties_sales_CAD_PP) as warranties_sales_CAD_PP,
            sum(returns_on_warranties_sales_CAD_PP) as returns_on_warranties_sales_CAD_PP,
            sum(returns_sales_CAD_PP) as returns_sales_CAD_PP,
            sum(noncommercial_sales_CAD_PP) as noncommercial_sales_CAD_PP,
            sum(integration_sales_CAD_PP) as integration_sales_CAD_PP,
            sum(ifnull(orders_sales_CAD_PP,0)) as orders_sales_CAD_PP,
            sum(orders_sales_CAD_CP) as orders_sales_CAD_CP,
            sum(sales_amount_CAD_CP) as sales_amount_CAD_CP,
            sum(sales_amount_CAD_PP) as sales_amount_CAD_PP,

            sum(Fees_sales_MXN_PP) as Fees_sales_MXN_PP,
            sum(Rebates_sales_MXN_PP) as Rebates_sales_MXN_PP,
            sum(warranties_sales_MXN_PP) as warranties_sales_MXN_PP,
            sum(returns_on_warranties_sales_MXN_PP) as returns_on_warranties_sales_MXN_PP,
            sum(returns_sales_MXN_PP) as returns_sales_MXN_PP,
            sum(noncommercial_sales_MXN_PP) as noncommercial_sales_MXN_PP,
            sum(integration_sales_MXN_PP) as integration_sales_MXN_PP,
            sum(ifnull(orders_sales_MXN_PP,0)) as orders_sales_MXN_PP,
            sum(orders_sales_MXN_CP) as orders_sales_MXN_CP,
            sum(sales_amount_MXN_CP) as sales_amount_MXN_CP,
            sum(sales_amount_MXN_PP) as sales_amount_MXN_PP,

            sum(Fees_sales_BRL_PP) as Fees_sales_BRL_PP,
            sum(Rebates_sales_BRL_PP) as Rebates_sales_BRL_PP,
            sum(warranties_sales_BRL_PP) as warranties_sales_BRL_PP,
            sum(returns_on_warranties_sales_BRL_PP) as returns_on_warranties_sales_BRL_PP,
            sum(returns_sales_BRL_PP) as returns_sales_BRL_PP,
            sum(noncommercial_sales_BRL_PP) as noncommercial_sales_BRL_PP,
            sum(integration_sales_BRL_PP) as integration_sales_BRL_PP,
            sum(ifnull(orders_sales_BRL_PP,0)) as orders_sales_BRL_PP,
            sum(orders_sales_BRL_CP) as orders_sales_BRL_CP,
            sum(sales_amount_BRL_CP) as sales_amount_BRL_CP,
            sum(sales_amount_BRL_PP) as sales_amount_BRL_PP,

      --- Cost
            sum(Fees_cost_EUR_PP) as Fees_cost_EUR_PP,
            sum(Rebates_cost_EUR_PP) as Rebates_cost_EUR_PP,
            sum(warranties_cost_EUR_PP) as warranties_cost_EUR_PP,
            sum(returns_on_warranties_cost_EUR_PP) as returns_on_warranties_cost_EUR_PP,
            sum(returns_cost_EUR_PP) as returns_cost_EUR_PP,
            sum(noncommercial_cost_EUR_PP) as noncommercial_cost_EUR_PP,
            sum(integration_cost_EUR_PP) as integration_cost_EUR_PP,
            sum(ifnull(orders_cost_EUR_PP,0)) as orders_cost_EUR_PP,
            sum(orders_cost_EUR_CP) as orders_cost_EUR_CP,

            sum(Fees_cost_USD_PP) as Fees_cost_USD_PP,
            sum(Rebates_cost_USD_PP) as Rebates_cost_USD_PP,
            sum(warranties_cost_USD_PP) as warranties_cost_USD_PP,
            sum(returns_on_warranties_cost_USD_PP) as returns_on_warranties_cost_USD_PP,
            sum(returns_cost_USD_PP) as returns_cost_USD_PP,
            sum(noncommercial_cost_USD_PP) as noncommercial_cost_USD_PP,
            sum(integration_cost_USD_PP) as integration_cost_USD_PP,
            sum(ifnull(orders_cost_USD_PP,0)) as orders_cost_USD_PP,
            sum(orders_cost_USD_CP) as orders_cost_USD_CP,

            sum(Fees_cost_CAD_PP) as Fees_cost_CAD_PP,
            sum(Rebates_cost_CAD_PP) as Rebates_cost_CAD_PP,
            sum(warranties_cost_CAD_PP) as warranties_cost_CAD_PP,
            sum(returns_on_warranties_cost_CAD_PP) as returns_on_warranties_cost_CAD_PP,
            sum(returns_cost_CAD_PP) as returns_cost_CAD_PP,
            sum(noncommercial_cost_CAD_PP) as noncommercial_cost_CAD_PP,
            sum(integration_cost_CAD_PP) as integration_cost_CAD_PP,
            sum(ifnull(orders_cost_CAD_PP,0)) as orders_cost_CAD_PP,
            sum(orders_cost_CAD_CP) as orders_cost_CAD_CP,

            sum(Fees_cost_MXN_PP) as Fees_cost_MXN_PP,
            sum(Rebates_cost_MXN_PP) as Rebates_cost_MXN_PP,
            sum(warranties_cost_MXN_PP) as warranties_cost_MXN_PP,
            sum(returns_on_warranties_cost_MXN_PP) as returns_on_warranties_cost_MXN_PP,
            sum(returns_cost_MXN_PP) as returns_cost_MXN_PP,
            sum(noncommercial_cost_MXN_PP) as noncommercial_cost_MXN_PP,
            sum(integration_cost_MXN_PP) as integration_cost_MXN_PP,
            sum(ifnull(orders_cost_MXN_PP,0)) as orders_cost_MXN_PP,
            sum(orders_cost_MXN_CP) as orders_cost_MXN_CP,

            sum(Fees_cost_BRL_PP) as Fees_cost_BRL_PP,
            sum(Rebates_cost_BRL_PP) as Rebates_cost_BRL_PP,
            sum(warranties_cost_BRL_PP) as warranties_cost_BRL_PP,
            sum(returns_on_warranties_cost_BRL_PP) as returns_on_warranties_cost_BRL_PP,
            sum(returns_cost_BRL_PP) as returns_cost_BRL_PP,
            sum(noncommercial_cost_BRL_PP) as noncommercial_cost_BRL_PP,
            sum(integration_cost_BRL_PP) as integration_cost_BRL_PP,
            sum(ifnull(orders_cost_BRL_PP,0)) as orders_cost_BRL_PP,
            sum(orders_cost_BRL_CP) as orders_cost_BRL_CP,

      --- Cost landed
            sum(Fees_cost_landed_EUR_PP) as Fees_cost_landed_EUR_PP,
            sum(Rebates_cost_landed_EUR_PP) as Rebates_cost_landed_EUR_PP,
            sum(warranties_cost_landed_EUR_PP) as warranties_cost_landed_EUR_PP,
            sum(returns_on_warranties_cost_landed_EUR_PP) as returns_on_warranties_cost_landed_EUR_PP,
            sum(returns_cost_landed_EUR_PP) as returns_cost_landed_EUR_PP,
            sum(noncommercial_cost_landed_EUR_PP) as noncommercial_cost_landed_EUR_PP,
            sum(integration_cost_landed_EUR_PP) as integration_cost_landed_EUR_PP,
            sum(ifnull(orders_cost_landed_EUR_PP,0)) as orders_cost_landed_EUR_PP,
            sum(orders_cost_landed_EUR_CP) as orders_cost_landed_EUR_CP,  

            sum(Fees_cost_landed_USD_PP) as Fees_cost_landed_USD_PP,
            sum(Rebates_cost_landed_USD_PP) as Rebates_cost_landed_USD_PP,
            sum(warranties_cost_landed_USD_PP) as warranties_cost_landed_USD_PP,
            sum(returns_on_warranties_cost_landed_USD_PP) as returns_on_warranties_cost_landed_USD_PP,
            sum(returns_cost_landed_USD_PP) as returns_cost_landed_USD_PP,
            sum(noncommercial_cost_landed_USD_PP) as noncommercial_cost_landed_USD_PP,
            sum(integration_cost_landed_USD_PP) as integration_cost_landed_USD_PP,
            sum(ifnull(orders_cost_landed_USD_PP,0)) as orders_cost_landed_USD_PP,
            sum(orders_cost_landed_USD_CP) as orders_cost_landed_USD_CP,  

            sum(Fees_cost_landed_CAD_PP) as Fees_cost_landed_CAD_PP,
            sum(Rebates_cost_landed_CAD_PP) as Rebates_cost_landed_CAD_PP,
            sum(warranties_cost_landed_CAD_PP) as warranties_cost_landed_CAD_PP,
            sum(returns_on_warranties_cost_landed_CAD_PP) as returns_on_warranties_cost_landed_CAD_PP,
            sum(returns_cost_landed_CAD_PP) as returns_cost_landed_CAD_PP,
            sum(noncommercial_cost_landed_CAD_PP) as noncommercial_cost_landed_CAD_PP,
            sum(integration_cost_landed_CAD_PP) as integration_cost_landed_CAD_PP,
            sum(ifnull(orders_cost_landed_CAD_PP,0)) as orders_cost_landed_CAD_PP,
            sum(orders_cost_landed_CAD_CP) as orders_cost_landed_CAD_CP,  

            sum(Fees_cost_landed_MXN_PP) as Fees_cost_landed_MXN_PP,
            sum(Rebates_cost_landed_MXN_PP) as Rebates_cost_landed_MXN_PP,
            sum(warranties_cost_landed_MXN_PP) as warranties_cost_landed_MXN_PP,
            sum(returns_on_warranties_cost_landed_MXN_PP) as returns_on_warranties_cost_landed_MXN_PP,
            sum(returns_cost_landed_MXN_PP) as returns_cost_landed_MXN_PP,
            sum(noncommercial_cost_landed_MXN_PP) as noncommercial_cost_landed_MXN_PP,
            sum(integration_cost_landed_MXN_PP) as integration_cost_landed_MXN_PP,
            sum(ifnull(orders_cost_landed_MXN_PP,0)) as orders_cost_landed_MXN_PP,
            sum(orders_cost_landed_MXN_CP) as orders_cost_landed_MXN_CP,  

            sum(Fees_cost_landed_BRL_PP) as Fees_cost_landed_BRL_PP,
            sum(Rebates_cost_landed_BRL_PP) as Rebates_cost_landed_BRL_PP,
            sum(warranties_cost_landed_BRL_PP) as warranties_cost_landed_BRL_PP,
            sum(returns_on_warranties_cost_landed_BRL_PP) as returns_on_warranties_cost_landed_BRL_PP,
            sum(returns_cost_landed_BRL_PP) as returns_cost_landed_BRL_PP,
            sum(noncommercial_cost_landed_BRL_PP) as noncommercial_cost_landed_BRL_PP,
            sum(integration_cost_landed_BRL_PP) as integration_cost_landed_BRL_PP,
            sum(ifnull(orders_cost_landed_BRL_PP,0)) as orders_cost_landed_BRL_PP,
            sum(orders_cost_landed_BRL_CP) as orders_cost_landed_BRL_CP,                               
              
      --- Calculate delta for excluded categories (fees, reabates, warranties, return on warranties, returns) + total sales growth
            sum(ifnull(Fees_sales_EUR_CP,0)) - sum(ifnull(Fees_sales_EUR_PP,0)) as Fees_sales_EUR_delta,
            sum(ifnull(Rebates_sales_EUR_CP,0)) - sum(ifnull(Rebates_sales_EUR_PP,0)) as Rebates_sales_EUR_delta,
            sum(ifnull(warranties_sales_EUR_CP,0)) - sum(ifnull(warranties_sales_EUR_PP,0)) as warranties_sales_EUR_delta,
            sum(ifnull(returns_on_warranties_sales_EUR_CP,0)) - sum(ifnull(returns_on_warranties_sales_EUR_PP,0)) as returns_on_warranties_sales_EUR_delta,
            sum(ifnull(returns_sales_EUR_CP,0)) - sum(ifnull(returns_sales_EUR_PP,0)) as returns_sales_EUR_delta,
            sum(ifnull(noncommercial_sales_EUR_CP,0)) - sum(ifnull(noncommercial_sales_EUR_PP,0)) as noncommercial_sales_EUR_delta,
            sum(ifnull(integration_sales_EUR_CP,0)) - sum(ifnull(integration_sales_EUR_PP,0)) as integration_sales_EUR_delta,            
            sum(ifnull(sales_amount_EUR_CP,0)) - sum(ifnull(sales_amount_EUR_PP,0)) as sales_amount_EUR_delta,

            sum(ifnull(Fees_sales_USD_CP,0)) - sum(ifnull(Fees_sales_USD_PP,0)) as Fees_sales_USD_delta,
            sum(ifnull(Rebates_sales_USD_CP,0)) - sum(ifnull(Rebates_sales_USD_PP,0)) as Rebates_sales_USD_delta,
            sum(ifnull(warranties_sales_USD_CP,0)) - sum(ifnull(warranties_sales_USD_PP,0)) as warranties_sales_USD_delta,
            sum(ifnull(returns_on_warranties_sales_USD_CP,0)) - sum(ifnull(returns_on_warranties_sales_USD_PP,0)) as returns_on_warranties_sales_USD_delta,
            sum(ifnull(returns_sales_USD_CP,0)) - sum(ifnull(returns_sales_USD_PP,0)) as returns_sales_USD_delta,
            sum(ifnull(noncommercial_sales_USD_CP,0)) - sum(ifnull(noncommercial_sales_USD_PP,0)) as noncommercial_sales_USD_delta,
            sum(ifnull(integration_sales_USD_CP,0)) - sum(ifnull(integration_sales_USD_PP,0)) as integration_sales_USD_delta,            
            sum(ifnull(sales_amount_USD_CP,0)) - sum(ifnull(sales_amount_USD_PP,0)) as sales_amount_USD_delta,

            sum(ifnull(Fees_sales_CAD_CP,0)) - sum(ifnull(Fees_sales_CAD_PP,0)) as Fees_sales_CAD_delta,
            sum(ifnull(Rebates_sales_CAD_CP,0)) - sum(ifnull(Rebates_sales_CAD_PP,0)) as Rebates_sales_CAD_delta,
            sum(ifnull(warranties_sales_CAD_CP,0)) - sum(ifnull(warranties_sales_CAD_PP,0)) as warranties_sales_CAD_delta,
            sum(ifnull(returns_on_warranties_sales_CAD_CP,0)) - sum(ifnull(returns_on_warranties_sales_CAD_PP,0)) as returns_on_warranties_sales_CAD_delta,
            sum(ifnull(returns_sales_CAD_CP,0)) - sum(ifnull(returns_sales_CAD_PP,0)) as returns_sales_CAD_delta,
            sum(ifnull(noncommercial_sales_CAD_CP,0)) - sum(ifnull(noncommercial_sales_CAD_PP,0)) as noncommercial_sales_CAD_delta,
            sum(ifnull(integration_sales_CAD_CP,0)) - sum(ifnull(integration_sales_CAD_PP,0)) as integration_sales_CAD_delta,            
            sum(ifnull(sales_amount_CAD_CP,0)) - sum(ifnull(sales_amount_CAD_PP,0)) as sales_amount_CAD_delta,

            sum(ifnull(Fees_sales_MXN_CP,0)) - sum(ifnull(Fees_sales_MXN_PP,0)) as Fees_sales_MXN_delta,
            sum(ifnull(Rebates_sales_MXN_CP,0)) - sum(ifnull(Rebates_sales_MXN_PP,0)) as Rebates_sales_MXN_delta,
            sum(ifnull(warranties_sales_MXN_CP,0)) - sum(ifnull(warranties_sales_MXN_PP,0)) as warranties_sales_MXN_delta,
            sum(ifnull(returns_on_warranties_sales_MXN_CP,0)) - sum(ifnull(returns_on_warranties_sales_MXN_PP,0)) as returns_on_warranties_sales_MXN_delta,
            sum(ifnull(returns_sales_MXN_CP,0)) - sum(ifnull(returns_sales_MXN_PP,0)) as returns_sales_MXN_delta,
            sum(ifnull(noncommercial_sales_MXN_CP,0)) - sum(ifnull(noncommercial_sales_MXN_PP,0)) as noncommercial_sales_MXN_delta,
            sum(ifnull(integration_sales_MXN_CP,0)) - sum(ifnull(integration_sales_MXN_PP,0)) as integration_sales_MXN_delta,            
            sum(ifnull(sales_amount_MXN_CP,0)) - sum(ifnull(sales_amount_MXN_PP,0)) as sales_amount_MXN_delta,

            sum(ifnull(Fees_sales_BRL_CP,0)) - sum(ifnull(Fees_sales_BRL_PP,0)) as Fees_sales_BRL_delta,
            sum(ifnull(Rebates_sales_BRL_CP,0)) - sum(ifnull(Rebates_sales_BRL_PP,0)) as Rebates_sales_BRL_delta,
            sum(ifnull(warranties_sales_BRL_CP,0)) - sum(ifnull(warranties_sales_BRL_PP,0)) as warranties_sales_BRL_delta,
            sum(ifnull(returns_on_warranties_sales_BRL_CP,0)) - sum(ifnull(returns_on_warranties_sales_BRL_PP,0)) as returns_on_warranties_sales_BRL_delta,
            sum(ifnull(returns_sales_BRL_CP,0)) - sum(ifnull(returns_sales_BRL_PP,0)) as returns_sales_BRL_delta,
            sum(ifnull(noncommercial_sales_BRL_CP,0)) - sum(ifnull(noncommercial_sales_BRL_PP,0)) as noncommercial_sales_BRL_delta,
            sum(ifnull(integration_sales_BRL_CP,0)) - sum(ifnull(integration_sales_BRL_PP,0)) as integration_sales_BRL_delta,            
            sum(ifnull(sales_amount_BRL_CP,0)) - sum(ifnull(sales_amount_BRL_PP,0)) as sales_amount_BRL_delta,

      --- Calculate cost delta for excluded categories (fees, reabates, warranties, return on warranties, returns)
            sum(ifnull(Fees_cost_EUR_CP,0)) - sum(ifnull(Fees_cost_EUR_PP,0)) as Fees_cost_EUR_delta,
            sum(ifnull(Rebates_cost_EUR_CP,0)) - sum(ifnull(Rebates_cost_EUR_PP,0)) as Rebates_cost_EUR_delta,
            sum(ifnull(warranties_cost_EUR_CP,0)) - sum(ifnull(warranties_cost_EUR_PP,0)) as warranties_cost_EUR_delta,
            sum(ifnull(returns_on_warranties_cost_EUR_CP,0)) - sum(ifnull(returns_on_warranties_cost_EUR_PP,0)) as returns_on_warranties_cost_EUR_delta,
            sum(ifnull(returns_cost_EUR_CP,0)) - sum(ifnull(returns_cost_EUR_PP,0)) as returns_cost_EUR_delta,
            sum(ifnull(noncommercial_cost_EUR_CP,0)) - sum(ifnull(noncommercial_cost_EUR_PP,0)) as noncommercial_cost_EUR_delta,
            sum(ifnull(integration_cost_EUR_CP,0)) - sum(ifnull(integration_cost_EUR_PP,0)) as integration_cost_EUR_delta,

            sum(ifnull(Fees_cost_USD_CP,0)) - sum(ifnull(Fees_cost_USD_PP,0)) as Fees_cost_USD_delta,
            sum(ifnull(Rebates_cost_USD_CP,0)) - sum(ifnull(Rebates_cost_USD_PP,0)) as Rebates_cost_USD_delta,
            sum(ifnull(warranties_cost_USD_CP,0)) - sum(ifnull(warranties_cost_USD_PP,0)) as warranties_cost_USD_delta,
            sum(ifnull(returns_on_warranties_cost_USD_CP,0)) - sum(ifnull(returns_on_warranties_cost_USD_PP,0)) as returns_on_warranties_cost_USD_delta,
            sum(ifnull(returns_cost_USD_CP,0)) - sum(ifnull(returns_cost_USD_PP,0)) as returns_cost_USD_delta,
            sum(ifnull(noncommercial_cost_USD_CP,0)) - sum(ifnull(noncommercial_cost_USD_PP,0)) as noncommercial_cost_USD_delta,
            sum(ifnull(integration_cost_USD_CP,0)) - sum(ifnull(integration_cost_USD_PP,0)) as integration_cost_USD_delta,

            sum(ifnull(Fees_cost_CAD_CP,0)) - sum(ifnull(Fees_cost_CAD_PP,0)) as Fees_cost_CAD_delta,
            sum(ifnull(Rebates_cost_CAD_CP,0)) - sum(ifnull(Rebates_cost_CAD_PP,0)) as Rebates_cost_CAD_delta,
            sum(ifnull(warranties_cost_CAD_CP,0)) - sum(ifnull(warranties_cost_CAD_PP,0)) as warranties_cost_CAD_delta,
            sum(ifnull(returns_on_warranties_cost_CAD_CP,0)) - sum(ifnull(returns_on_warranties_cost_CAD_PP,0)) as returns_on_warranties_cost_CAD_delta,
            sum(ifnull(returns_cost_CAD_CP,0)) - sum(ifnull(returns_cost_CAD_PP,0)) as returns_cost_CAD_delta,
            sum(ifnull(noncommercial_cost_CAD_CP,0)) - sum(ifnull(noncommercial_cost_CAD_PP,0)) as noncommercial_cost_CAD_delta,
            sum(ifnull(integration_cost_CAD_CP,0)) - sum(ifnull(integration_cost_CAD_PP,0)) as integration_cost_CAD_delta,

            sum(ifnull(Fees_cost_MXN_CP,0)) - sum(ifnull(Fees_cost_MXN_PP,0)) as Fees_cost_MXN_delta,
            sum(ifnull(Rebates_cost_MXN_CP,0)) - sum(ifnull(Rebates_cost_MXN_PP,0)) as Rebates_cost_MXN_delta,
            sum(ifnull(warranties_cost_MXN_CP,0)) - sum(ifnull(warranties_cost_MXN_PP,0)) as warranties_cost_MXN_delta,
            sum(ifnull(returns_on_warranties_cost_MXN_CP,0)) - sum(ifnull(returns_on_warranties_cost_MXN_PP,0)) as returns_on_warranties_cost_MXN_delta,
            sum(ifnull(returns_cost_MXN_CP,0)) - sum(ifnull(returns_cost_MXN_PP,0)) as returns_cost_MXN_delta,
            sum(ifnull(noncommercial_cost_MXN_CP,0)) - sum(ifnull(noncommercial_cost_MXN_PP,0)) as noncommercial_cost_MXN_delta,
            sum(ifnull(integration_cost_MXN_CP,0)) - sum(ifnull(integration_cost_MXN_PP,0)) as integration_cost_MXN_delta,

            sum(ifnull(Fees_cost_BRL_CP,0)) - sum(ifnull(Fees_cost_BRL_PP,0)) as Fees_cost_BRL_delta,
            sum(ifnull(Rebates_cost_BRL_CP,0)) - sum(ifnull(Rebates_cost_BRL_PP,0)) as Rebates_cost_BRL_delta,
            sum(ifnull(warranties_cost_BRL_CP,0)) - sum(ifnull(warranties_cost_BRL_PP,0)) as warranties_cost_BRL_delta,
            sum(ifnull(returns_on_warranties_cost_BRL_CP,0)) - sum(ifnull(returns_on_warranties_cost_BRL_PP,0)) as returns_on_warranties_cost_BRL_delta,
            sum(ifnull(returns_cost_BRL_CP,0)) - sum(ifnull(returns_cost_BRL_PP,0)) as returns_cost_BRL_delta,
            sum(ifnull(noncommercial_cost_BRL_CP,0)) - sum(ifnull(noncommercial_cost_BRL_PP,0)) as noncommercial_cost_BRL_delta,
            sum(ifnull(integration_cost_BRL_CP,0)) - sum(ifnull(integration_cost_BRL_PP,0)) as integration_cost_BRL_delta,            

            sum(ifnull(Fees_cost_EUR_CP,0)) 
              + sum(ifnull(Rebates_cost_EUR_CP,0)) 
              + sum(ifnull(warranties_cost_EUR_CP,0)) 
              + sum(ifnull(returns_on_warranties_cost_EUR_CP,0)) 
              + sum(ifnull(returns_cost_EUR_CP,0)) 
              + sum(ifnull(orders_cost_EUR_CP,0)) 
              + sum(ifnull(noncommercial_cost_EUR_CP,0)) 
              + sum(ifnull(integration_cost_EUR_CP,0)) 
            as cost_EUR_CP,

          sum(ifnull(Fees_cost_USD_CP,0)) 
              + sum(ifnull(Rebates_cost_USD_CP,0)) 
              + sum(ifnull(warranties_cost_USD_CP,0)) 
              + sum(ifnull(returns_on_warranties_cost_USD_CP,0)) 
              + sum(ifnull(returns_cost_USD_CP,0)) 
              + sum(ifnull(orders_cost_USD_CP,0)) 
              + sum(ifnull(noncommercial_cost_USD_CP,0)) 
              + sum(ifnull(integration_cost_USD_CP,0)) 
            as cost_USD_CP,

          sum(ifnull(Fees_cost_CAD_CP,0)) 
              + sum(ifnull(Rebates_cost_CAD_CP,0)) 
              + sum(ifnull(warranties_cost_CAD_CP,0)) 
              + sum(ifnull(returns_on_warranties_cost_CAD_CP,0)) 
              + sum(ifnull(returns_cost_CAD_CP,0)) 
              + sum(ifnull(orders_cost_CAD_CP,0)) 
              + sum(ifnull(noncommercial_cost_CAD_CP,0)) 
              + sum(ifnull(integration_cost_CAD_CP,0)) 
            as cost_CAD_CP,

          sum(ifnull(Fees_cost_MXN_CP,0)) 
              + sum(ifnull(Rebates_cost_MXN_CP,0)) 
              + sum(ifnull(warranties_cost_MXN_CP,0)) 
              + sum(ifnull(returns_on_warranties_cost_MXN_CP,0)) 
              + sum(ifnull(returns_cost_MXN_CP,0)) 
              + sum(ifnull(orders_cost_MXN_CP,0)) 
              + sum(ifnull(noncommercial_cost_MXN_CP,0)) 
              + sum(ifnull(integration_cost_MXN_CP,0)) 
            as cost_MXN_CP,

          sum(ifnull(Fees_cost_BRL_CP,0)) 
              + sum(ifnull(Rebates_cost_BRL_CP,0)) 
              + sum(ifnull(warranties_cost_BRL_CP,0)) 
              + sum(ifnull(returns_on_warranties_cost_BRL_CP,0)) 
              + sum(ifnull(returns_cost_BRL_CP,0)) 
              + sum(ifnull(orders_cost_BRL_CP,0)) 
              + sum(ifnull(noncommercial_cost_BRL_CP,0)) 
              + sum(ifnull(integration_cost_BRL_CP,0)) 
            as cost_BRL_CP,

            sum(ifnull(Fees_cost_EUR_PP,0)) 
              + sum(ifnull(Rebates_cost_EUR_PP,0)) 
              + sum(ifnull(warranties_cost_EUR_PP,0)) 
              +sum(ifnull(returns_on_warranties_cost_EUR_PP,0)) 
              + sum(ifnull(returns_cost_EUR_PP,0)) 
              + sum(ifnull(orders_cost_EUR_PP,0)) 
              + sum(ifnull(noncommercial_cost_EUR_PP,0)) 
              + sum(ifnull(integration_cost_EUR_PP,0)) 
            as cost_EUR_PP,

          sum(ifnull(Fees_cost_USD_PP,0)) 
              + sum(ifnull(Rebates_cost_USD_PP,0)) 
              + sum(ifnull(warranties_cost_USD_PP,0)) 
              +sum(ifnull(returns_on_warranties_cost_USD_PP,0)) 
              + sum(ifnull(returns_cost_USD_PP,0)) 
              + sum(ifnull(orders_cost_USD_PP,0)) 
              + sum(ifnull(noncommercial_cost_USD_PP,0)) 
              + sum(ifnull(integration_cost_USD_PP,0)) 
            as cost_USD_PP,

          sum(ifnull(Fees_cost_CAD_PP,0)) 
              + sum(ifnull(Rebates_cost_CAD_PP,0)) 
              + sum(ifnull(warranties_cost_CAD_PP,0)) 
              +sum(ifnull(returns_on_warranties_cost_CAD_PP,0)) 
              + sum(ifnull(returns_cost_CAD_PP,0)) 
              + sum(ifnull(orders_cost_CAD_PP,0)) 
              + sum(ifnull(noncommercial_cost_CAD_PP,0)) 
              + sum(ifnull(integration_cost_CAD_PP,0)) 
            as cost_CAD_PP,

          sum(ifnull(Fees_cost_MXN_PP,0)) 
              + sum(ifnull(Rebates_cost_MXN_PP,0)) 
              + sum(ifnull(warranties_cost_MXN_PP,0)) 
              +sum(ifnull(returns_on_warranties_cost_MXN_PP,0)) 
              + sum(ifnull(returns_cost_MXN_PP,0)) 
              + sum(ifnull(orders_cost_MXN_PP,0)) 
              + sum(ifnull(noncommercial_cost_MXN_PP,0)) 
              + sum(ifnull(integration_cost_MXN_PP,0)) 
            as cost_MXN_PP,

          sum(ifnull(Fees_cost_BRL_PP,0)) 
              + sum(ifnull(Rebates_cost_BRL_PP,0)) 
              + sum(ifnull(warranties_cost_BRL_PP,0)) 
              +sum(ifnull(returns_on_warranties_cost_BRL_PP,0)) 
              + sum(ifnull(returns_cost_BRL_PP,0)) 
              + sum(ifnull(orders_cost_BRL_PP,0)) 
              + sum(ifnull(noncommercial_cost_BRL_PP,0)) 
              + sum(ifnull(integration_cost_BRL_PP,0)) 
            as cost_BRL_PP,           

      --- Calculate cost landed delta for excluded categories (fees, reabates, warranties, return on warranties, returns)
            sum(ifnull(Fees_cost_landed_EUR_CP,0)) - sum(ifnull(Fees_cost_landed_EUR_PP,0)) as Fees_cost_landed_EUR_delta,
            sum(ifnull(Rebates_cost_landed_EUR_CP,0)) - sum(ifnull(Rebates_cost_landed_EUR_PP,0)) as Rebates_cost_landed_EUR_delta,
            sum(ifnull(warranties_cost_landed_EUR_CP,0)) - sum(ifnull(warranties_cost_landed_EUR_PP,0)) as warranties_cost_landed_EUR_delta,
            sum(ifnull(returns_on_warranties_cost_landed_EUR_CP,0)) - sum(ifnull(returns_on_warranties_cost_landed_EUR_PP,0)) as returns_on_warranties_cost_landed_EUR_delta,
            sum(ifnull(returns_cost_landed_EUR_CP,0)) - sum(ifnull(returns_cost_landed_EUR_PP,0)) as returns_cost_landed_EUR_delta,
            sum(ifnull(noncommercial_cost_landed_EUR_CP,0)) - sum(ifnull(noncommercial_cost_landed_EUR_PP,0)) as noncommercial_cost_landed_EUR_delta,
            sum(ifnull(integration_cost_landed_EUR_CP,0)) - sum(ifnull(integration_cost_landed_EUR_PP,0)) as integration_cost_landed_EUR_delta,

            sum(ifnull(Fees_cost_landed_USD_CP,0)) - sum(ifnull(Fees_cost_landed_USD_PP,0)) as Fees_cost_landed_USD_delta,
            sum(ifnull(Rebates_cost_landed_USD_CP,0)) - sum(ifnull(Rebates_cost_landed_USD_PP,0)) as Rebates_cost_landed_USD_delta,
            sum(ifnull(warranties_cost_landed_USD_CP,0)) - sum(ifnull(warranties_cost_landed_USD_PP,0)) as warranties_cost_landed_USD_delta,
            sum(ifnull(returns_on_warranties_cost_landed_USD_CP,0)) - sum(ifnull(returns_on_warranties_cost_landed_USD_PP,0)) as returns_on_warranties_cost_landed_USD_delta,
            sum(ifnull(returns_cost_landed_USD_CP,0)) - sum(ifnull(returns_cost_landed_USD_PP,0)) as returns_cost_landed_USD_delta,
            sum(ifnull(noncommercial_cost_landed_USD_CP,0)) - sum(ifnull(noncommercial_cost_landed_USD_PP,0)) as noncommercial_cost_landed_USD_delta,
            sum(ifnull(integration_cost_landed_USD_CP,0)) - sum(ifnull(integration_cost_landed_USD_PP,0)) as integration_cost_landed_USD_delta,

            sum(ifnull(Fees_cost_landed_CAD_CP,0)) - sum(ifnull(Fees_cost_landed_CAD_PP,0)) as Fees_cost_landed_CAD_delta,
            sum(ifnull(Rebates_cost_landed_CAD_CP,0)) - sum(ifnull(Rebates_cost_landed_CAD_PP,0)) as Rebates_cost_landed_CAD_delta,
            sum(ifnull(warranties_cost_landed_CAD_CP,0)) - sum(ifnull(warranties_cost_landed_CAD_PP,0)) as warranties_cost_landed_CAD_delta,
            sum(ifnull(returns_on_warranties_cost_landed_CAD_CP,0)) - sum(ifnull(returns_on_warranties_cost_landed_CAD_PP,0)) as returns_on_warranties_cost_landed_CAD_delta,
            sum(ifnull(returns_cost_landed_CAD_CP,0)) - sum(ifnull(returns_cost_landed_CAD_PP,0)) as returns_cost_landed_CAD_delta,
            sum(ifnull(noncommercial_cost_landed_CAD_CP,0)) - sum(ifnull(noncommercial_cost_landed_CAD_PP,0)) as noncommercial_cost_landed_CAD_delta,
            sum(ifnull(integration_cost_landed_CAD_CP,0)) - sum(ifnull(integration_cost_landed_CAD_PP,0)) as integration_cost_landed_CAD_delta,

            sum(ifnull(Fees_cost_landed_MXN_CP,0)) - sum(ifnull(Fees_cost_landed_MXN_PP,0)) as Fees_cost_landed_MXN_delta,
            sum(ifnull(Rebates_cost_landed_MXN_CP,0)) - sum(ifnull(Rebates_cost_landed_MXN_PP,0)) as Rebates_cost_landed_MXN_delta,
            sum(ifnull(warranties_cost_landed_MXN_CP,0)) - sum(ifnull(warranties_cost_landed_MXN_PP,0)) as warranties_cost_landed_MXN_delta,
            sum(ifnull(returns_on_warranties_cost_landed_MXN_CP,0)) - sum(ifnull(returns_on_warranties_cost_landed_MXN_PP,0)) as returns_on_warranties_cost_landed_MXN_delta,
            sum(ifnull(returns_cost_landed_MXN_CP,0)) - sum(ifnull(returns_cost_landed_MXN_PP,0)) as returns_cost_landed_MXN_delta,
            sum(ifnull(noncommercial_cost_landed_MXN_CP,0)) - sum(ifnull(noncommercial_cost_landed_MXN_PP,0)) as noncommercial_cost_landed_MXN_delta,
            sum(ifnull(integration_cost_landed_MXN_CP,0)) - sum(ifnull(integration_cost_landed_MXN_PP,0)) as integration_cost_landed_MXN_delta,

            sum(ifnull(Fees_cost_landed_BRL_CP,0)) - sum(ifnull(Fees_cost_landed_BRL_PP,0)) as Fees_cost_landed_BRL_delta,
            sum(ifnull(Rebates_cost_landed_BRL_CP,0)) - sum(ifnull(Rebates_cost_landed_BRL_PP,0)) as Rebates_cost_landed_BRL_delta,
            sum(ifnull(warranties_cost_landed_BRL_CP,0)) - sum(ifnull(warranties_cost_landed_BRL_PP,0)) as warranties_cost_landed_BRL_delta,
            sum(ifnull(returns_on_warranties_cost_landed_BRL_CP,0)) - sum(ifnull(returns_on_warranties_cost_landed_BRL_PP,0)) as returns_on_warranties_cost_landed_BRL_delta,
            sum(ifnull(returns_cost_landed_BRL_CP,0)) - sum(ifnull(returns_cost_landed_BRL_PP,0)) as returns_cost_landed_BRL_delta,
            sum(ifnull(noncommercial_cost_landed_BRL_CP,0)) - sum(ifnull(noncommercial_cost_landed_BRL_PP,0)) as noncommercial_cost_landed_BRL_delta,
            sum(ifnull(integration_cost_landed_BRL_CP,0)) - sum(ifnull(integration_cost_landed_BRL_PP,0)) as integration_cost_landed_BRL_delta,                     

            sum(ifnull(Fees_cost_landed_EUR_CP,0)) 
              + sum(ifnull(Rebates_cost_landed_EUR_CP,0)) 
              + sum(ifnull(warranties_cost_landed_EUR_CP,0)) 
              +sum(ifnull(returns_on_warranties_cost_landed_EUR_CP,0)) 
              + sum(ifnull(returns_cost_landed_EUR_CP,0)) 
              + sum(ifnull(orders_cost_landed_EUR_CP,0)) 
              + sum(ifnull(noncommercial_cost_landed_EUR_CP,0)) 
              + sum(ifnull(integration_cost_landed_EUR_CP,0)) 
            as cost_landed_EUR_CP,

          sum(ifnull(Fees_cost_landed_USD_CP,0)) 
              + sum(ifnull(Rebates_cost_landed_USD_CP,0)) 
              + sum(ifnull(warranties_cost_landed_USD_CP,0)) 
              +sum(ifnull(returns_on_warranties_cost_landed_USD_CP,0)) 
              + sum(ifnull(returns_cost_landed_USD_CP,0)) 
              + sum(ifnull(orders_cost_landed_USD_CP,0)) 
              + sum(ifnull(noncommercial_cost_landed_USD_CP,0)) 
              + sum(ifnull(integration_cost_landed_USD_CP,0)) 
            as cost_landed_USD_CP,

          sum(ifnull(Fees_cost_landed_CAD_CP,0)) 
              + sum(ifnull(Rebates_cost_landed_CAD_CP,0)) 
              + sum(ifnull(warranties_cost_landed_CAD_CP,0)) 
              +sum(ifnull(returns_on_warranties_cost_landed_CAD_CP,0)) 
              + sum(ifnull(returns_cost_landed_CAD_CP,0)) 
              + sum(ifnull(orders_cost_landed_CAD_CP,0)) 
              + sum(ifnull(noncommercial_cost_landed_CAD_CP,0)) 
              + sum(ifnull(integration_cost_landed_CAD_CP,0)) 
            as cost_landed_CAD_CP,

          sum(ifnull(Fees_cost_landed_MXN_CP,0)) 
              + sum(ifnull(Rebates_cost_landed_MXN_CP,0)) 
              + sum(ifnull(warranties_cost_landed_MXN_CP,0)) 
              +sum(ifnull(returns_on_warranties_cost_landed_MXN_CP,0)) 
              + sum(ifnull(returns_cost_landed_MXN_CP,0)) 
              + sum(ifnull(orders_cost_landed_MXN_CP,0)) 
              + sum(ifnull(noncommercial_cost_landed_MXN_CP,0)) 
              + sum(ifnull(integration_cost_landed_MXN_CP,0)) 
            as cost_landed_MXN_CP,

          sum(ifnull(Fees_cost_landed_BRL_CP,0)) 
              + sum(ifnull(Rebates_cost_landed_BRL_CP,0)) 
              + sum(ifnull(warranties_cost_landed_BRL_CP,0)) 
              +sum(ifnull(returns_on_warranties_cost_landed_BRL_CP,0)) 
              + sum(ifnull(returns_cost_landed_BRL_CP,0)) 
              + sum(ifnull(orders_cost_landed_BRL_CP,0)) 
              + sum(ifnull(noncommercial_cost_landed_BRL_CP,0)) 
              + sum(ifnull(integration_cost_landed_BRL_CP,0)) 
            as cost_landed_BRL_CP,

            sum(ifnull(Fees_cost_landed_EUR_PP,0)) 
              + sum(ifnull(Rebates_cost_landed_EUR_PP,0)) 
              + sum(ifnull(warranties_cost_landed_EUR_PP,0)) 
              +sum(ifnull(returns_on_warranties_cost_landed_EUR_PP,0)) 
              + sum(ifnull(returns_cost_landed_EUR_PP,0)) 
              + sum(ifnull(orders_cost_landed_EUR_PP,0)) 
              + sum(ifnull(noncommercial_cost_landed_EUR_PP,0)) 
              + sum(ifnull(integration_cost_landed_EUR_PP,0)) 
            as cost_landed_EUR_PP, 

          sum(ifnull(Fees_cost_landed_USD_PP,0)) 
              + sum(ifnull(Rebates_cost_landed_USD_PP,0)) 
              + sum(ifnull(warranties_cost_landed_USD_PP,0)) 
              +sum(ifnull(returns_on_warranties_cost_landed_USD_PP,0)) 
              + sum(ifnull(returns_cost_landed_USD_PP,0)) 
              + sum(ifnull(orders_cost_landed_USD_PP,0)) 
              + sum(ifnull(noncommercial_cost_landed_USD_PP,0)) 
              + sum(ifnull(integration_cost_landed_USD_PP,0)) 
            as cost_landed_USD_PP, 

          sum(ifnull(Fees_cost_landed_CAD_PP,0)) 
              + sum(ifnull(Rebates_cost_landed_CAD_PP,0)) 
              + sum(ifnull(warranties_cost_landed_CAD_PP,0)) 
              +sum(ifnull(returns_on_warranties_cost_landed_CAD_PP,0)) 
              + sum(ifnull(returns_cost_landed_CAD_PP,0)) 
              + sum(ifnull(orders_cost_landed_CAD_PP,0)) 
              + sum(ifnull(noncommercial_cost_landed_CAD_PP,0)) 
              + sum(ifnull(integration_cost_landed_CAD_PP,0)) 
            as cost_landed_CAD_PP, 

          sum(ifnull(Fees_cost_landed_MXN_PP,0)) 
              + sum(ifnull(Rebates_cost_landed_MXN_PP,0)) 
              + sum(ifnull(warranties_cost_landed_MXN_PP,0)) 
              +sum(ifnull(returns_on_warranties_cost_landed_MXN_PP,0)) 
              + sum(ifnull(returns_cost_landed_MXN_PP,0)) 
              + sum(ifnull(orders_cost_landed_MXN_PP,0)) 
              + sum(ifnull(noncommercial_cost_landed_MXN_PP,0)) 
              + sum(ifnull(integration_cost_landed_MXN_PP,0)) 
            as cost_landed_MXN_PP, 

          sum(ifnull(Fees_cost_landed_BRL_PP,0)) 
              + sum(ifnull(Rebates_cost_landed_BRL_PP,0)) 
              + sum(ifnull(warranties_cost_landed_BRL_PP,0)) 
              +sum(ifnull(returns_on_warranties_cost_landed_BRL_PP,0)) 
              + sum(ifnull(returns_cost_landed_BRL_PP,0)) 
              + sum(ifnull(orders_cost_landed_BRL_PP,0)) 
              + sum(ifnull(noncommercial_cost_landed_BRL_PP,0)) 
              + sum(ifnull(integration_cost_landed_BRL_PP,0)) 
            as cost_landed_BRL_PP,                             

      --- Calculate sales #New,lost & recurring
              sum(case when evolution_type = 'NEW'  then orders_sales_EUR_CP else NULL end) as sales_amount_new_EUR_CP,
              sum(case when evolution_type = 'LOST' then orders_sales_EUR_PP else NULL end) as sales_amount_lost_EUR_CP, --attention! takes the PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_sales_EUR_CP else NULL end) as orders_sales_recurring_EUR_CP,
              sum(case when evolution_type = 'RECURRING' then orders_sales_EUR_PP else NULL end) as orders_sales_recurring_EUR_PP,

              sum(case when evolution_type = 'NEW'  then orders_sales_USD_CP else NULL end) as sales_amount_new_USD_CP,
              sum(case when evolution_type = 'LOST' then orders_sales_USD_PP else NULL end) as sales_amount_lost_USD_CP, --attention! takes the PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_sales_USD_CP else NULL end) as orders_sales_recurring_USD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_sales_USD_PP else NULL end) as orders_sales_recurring_USD_PP,

              sum(case when evolution_type = 'NEW'  then orders_sales_CAD_CP else NULL end) as sales_amount_new_CAD_CP,
              sum(case when evolution_type = 'LOST' then orders_sales_CAD_PP else NULL end) as sales_amount_lost_CAD_CP, --attention! takes the PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_sales_CAD_CP else NULL end) as orders_sales_recurring_CAD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_sales_CAD_PP else NULL end) as orders_sales_recurring_CAD_PP,

              sum(case when evolution_type = 'NEW'  then orders_sales_MXN_CP else NULL end) as sales_amount_new_MXN_CP,
              sum(case when evolution_type = 'LOST' then orders_sales_MXN_PP else NULL end) as sales_amount_lost_MXN_CP, --attention! takes the PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_sales_MXN_CP else NULL end) as orders_sales_recurring_MXN_CP,
              sum(case when evolution_type = 'RECURRING' then orders_sales_MXN_PP else NULL end) as orders_sales_recurring_MXN_PP,

              sum(case when evolution_type = 'NEW'  then orders_sales_BRL_CP else NULL end) as sales_amount_new_BRL_CP,
              sum(case when evolution_type = 'LOST' then orders_sales_BRL_PP else NULL end) as sales_amount_lost_BRL_CP, --attention! takes the PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_sales_BRL_CP else NULL end) as orders_sales_recurring_BRL_CP,
              sum(case when evolution_type = 'RECURRING' then orders_sales_BRL_PP else NULL end) as orders_sales_recurring_BRL_PP,

      --- Calculate cost #New,lost & recurring
              sum(case when evolution_type = 'NEW'  then orders_cost_EUR_CP else NULL end) as cost_amount_new_EUR_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_EUR_PP else NULL end) as cost_amount_lost_EUR_CP, --attention! takes the PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_EUR_CP else NULL end) as orders_cost_recurring_EUR_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_EUR_PP else NULL end) as orders_cost_recurring_EUR_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_USD_CP else NULL end) as cost_amount_new_USD_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_USD_PP else NULL end) as cost_amount_lost_USD_CP, --attention! takes the PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_USD_CP else NULL end) as orders_cost_recurring_USD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_USD_PP else NULL end) as orders_cost_recurring_USD_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_CAD_CP else NULL end) as cost_amount_new_CAD_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_CAD_PP else NULL end) as cost_amount_lost_CAD_CP, --attention! takes the PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_CAD_CP else NULL end) as orders_cost_recurring_CAD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_CAD_PP else NULL end) as orders_cost_recurring_CAD_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_MXN_CP else NULL end) as cost_amount_new_MXN_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_MXN_PP else NULL end) as cost_amount_lost_MXN_CP, --attention! takes the PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_MXN_CP else NULL end) as orders_cost_recurring_MXN_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_MXN_PP else NULL end) as orders_cost_recurring_MXN_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_BRL_CP else NULL end) as cost_amount_new_BRL_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_BRL_PP else NULL end) as cost_amount_lost_BRL_CP, --attention! takes the PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_BRL_CP else NULL end) as orders_cost_recurring_BRL_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_BRL_PP else NULL end) as orders_cost_recurring_BRL_PP,

      --- Calculate cost #New,lost & recurring
              sum(case when evolution_type = 'NEW'  then orders_cost_landed_EUR_CP else NULL end) as cost_landed_amount_new_EUR_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_landed_EUR_PP else NULL end) as cost_landed_amount_lost_EUR_CP, --takes PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_EUR_CP else NULL end) as orders_cost_landed_recurring_EUR_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_EUR_PP else NULL end) as orders_cost_landed_recurring_EUR_PP, 

              sum(case when evolution_type = 'NEW'  then orders_cost_landed_USD_CP else NULL end) as cost_landed_amount_new_USD_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_landed_USD_PP else NULL end) as cost_landed_amount_lost_USD_CP, --takes PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_USD_CP else NULL end) as orders_cost_landed_recurring_USD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_USD_PP else NULL end) as orders_cost_landed_recurring_USD_PP, 

              sum(case when evolution_type = 'NEW'  then orders_cost_landed_CAD_CP else NULL end) as cost_landed_amount_new_CAD_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_landed_CAD_PP else NULL end) as cost_landed_amount_lost_CAD_CP, --takes PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_CAD_CP else NULL end) as orders_cost_landed_recurring_CAD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_CAD_PP else NULL end) as orders_cost_landed_recurring_CAD_PP, 

              sum(case when evolution_type = 'NEW'  then orders_cost_landed_MXN_CP else NULL end) as cost_landed_amount_new_MXN_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_landed_MXN_PP else NULL end) as cost_landed_amount_lost_MXN_CP, --takes PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_MXN_CP else NULL end) as orders_cost_landed_recurring_MXN_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_MXN_PP else NULL end) as orders_cost_landed_recurring_MXN_PP, 

              sum(case when evolution_type = 'NEW'  then orders_cost_landed_BRL_CP else NULL end) as cost_landed_amount_new_BRL_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_landed_BRL_PP else NULL end) as cost_landed_amount_lost_BRL_CP, --takes PP sales to calculate LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_BRL_CP else NULL end) as orders_cost_landed_recurring_BRL_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_BRL_PP else NULL end) as orders_cost_landed_recurring_BRL_PP,                           
              
      --- Calculate the sales price effect
              sum(case when evolution_type = 'RECURRING' 
              then (average_price_per_unit_EUR_CP_with_fx_rate_PP - average_price_per_unit_EUR_PP) * orders_quantity_CP 
              else 0 end) as sales_price_effect_EUR,

              sum(case when evolution_type = 'RECURRING' 
              then (average_price_per_unit_USD_CP_with_fx_rate_PP - average_price_per_unit_USD_PP) * orders_quantity_CP 
              else 0 end) as sales_price_effect_USD,

              sum(case when evolution_type = 'RECURRING' 
              then (average_price_per_unit_CAD_CP_with_fx_rate_PP - average_price_per_unit_CAD_PP) * orders_quantity_CP 
              else 0 end) as sales_price_effect_CAD,

              sum(case when evolution_type = 'RECURRING' 
              then (average_price_per_unit_MXN_CP_with_fx_rate_PP - average_price_per_unit_MXN_PP) * orders_quantity_CP 
              else 0 end) as sales_price_effect_MXN,

              sum(case when evolution_type = 'RECURRING' 
              then (average_price_per_unit_BRL_CP_with_fx_rate_PP - average_price_per_unit_BRL_PP) * orders_quantity_CP 
              else 0 end) as sales_price_effect_BRL,

      --- Calculate the cost effect
              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_per_unit_EUR_CP_with_fx_rate_PP - average_cost_per_unit_EUR_PP) * orders_quantity_CP 
              else 0 end) as cost_effect_EUR,

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_per_unit_USD_CP_with_fx_rate_PP - average_cost_per_unit_USD_PP) * orders_quantity_CP 
              else 0 end) as cost_effect_USD,

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_per_unit_CAD_CP_with_fx_rate_PP - average_cost_per_unit_CAD_PP) * orders_quantity_CP 
              else 0 end) as cost_effect_CAD,

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_per_unit_MXN_CP_with_fx_rate_PP - average_cost_per_unit_MXN_PP) * orders_quantity_CP 
              else 0 end) as cost_effect_MXN,

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_per_unit_BRL_CP_with_fx_rate_PP - average_cost_per_unit_BRL_PP) * orders_quantity_CP 
              else 0 end) as cost_effect_BRL,

      --- Calculate the cost landed effect
              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_landed_per_unit_EUR_CP_with_fx_rate_PP - average_cost_landed_per_unit_EUR_PP) * orders_quantity_CP 
              else 0 end) as cost_landed_effect_EUR, 

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_landed_per_unit_USD_CP_with_fx_rate_PP - average_cost_landed_per_unit_USD_PP) * orders_quantity_CP 
              else 0 end) as cost_landed_effect_USD, 

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_landed_per_unit_CAD_CP_with_fx_rate_PP - average_cost_landed_per_unit_CAD_PP) * orders_quantity_CP 
              else 0 end) as cost_landed_effect_CAD, 

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_landed_per_unit_MXN_CP_with_fx_rate_PP - average_cost_landed_per_unit_MXN_PP) * orders_quantity_CP 
              else 0 end) as cost_landed_effect_MXN, 

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_landed_per_unit_BRL_CP_with_fx_rate_PP - average_cost_landed_per_unit_BRL_PP) * orders_quantity_CP 
              else 0 end) as cost_landed_effect_BRL,                         
              
      --- Calculate the quantity / volume effect for sales
              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_price_per_unit_EUR_PP 
                else 0 end) as quantity_effect_sales_EUR,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_price_per_unit_USD_PP 
                else 0 end) as quantity_effect_sales_USD,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_price_per_unit_CAD_PP 
                else 0 end) as quantity_effect_sales_CAD,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_price_per_unit_MXN_PP 
                else 0 end) as quantity_effect_sales_MXN,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_price_per_unit_BRL_PP 
                else 0 end) as quantity_effect_sales_BRL,

      --- Calculate the quantity / volume effect for cost group
              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_per_unit_EUR_PP 
                else 0 end) as quantity_effect_cost_EUR,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_per_unit_USD_PP 
                else 0 end) as quantity_effect_cost_USD,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_per_unit_CAD_PP 
                else 0 end) as quantity_effect_cost_CAD,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_per_unit_MXN_PP 
                else 0 end) as quantity_effect_cost_MXN,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_per_unit_BRL_PP 
                else 0 end) as quantity_effect_cost_BRL,

      --- Calculate the quantity / volume effect for cost group landed
              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_landed_per_unit_EUR_PP 
                else 0 end) as quantity_effect_cost_landed_EUR,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_landed_per_unit_USD_PP 
                else 0 end) as quantity_effect_cost_landed_USD,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_landed_per_unit_CAD_PP 
                else 0 end) as quantity_effect_cost_landed_CAD,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_landed_per_unit_MXN_PP 
                else 0 end) as quantity_effect_cost_landed_MXN,

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_landed_per_unit_BRL_PP 
                else 0 end) as quantity_effect_cost_landed_BRL,                                               
              
      --- Calculate the Fx effect
              sum(case when evolution_type = 'RECURRING' 
                then (average_price_per_unit_EUR_CP - average_price_per_unit_EUR_CP_with_fx_rate_PP) * orders_quantity_CP 
                else 0 end) as fx_effect_sales_EUR,
              sum(case when evolution_type = 'RECURRING' 
                then safe_divide(((average_price_per_unit_EUR_CP - average_price_per_unit_EUR_CP_with_fx_rate_PP) * orders_quantity_CP),orders_sales_EUR_PP) 
                else 0 end) as fx_effect_sales_percentage_EUR,

              sum(case when evolution_type = 'RECURRING' 
                then (average_price_per_unit_USD_CP - average_price_per_unit_USD_CP_with_fx_rate_PP) * orders_quantity_CP 
                else 0 end) as fx_effect_sales_USD,
              sum(case when evolution_type = 'RECURRING' 
                then safe_divide(((average_price_per_unit_USD_CP - average_price_per_unit_USD_CP_with_fx_rate_PP) * orders_quantity_CP),orders_sales_USD_PP) 
                else 0 end) as fx_effect_sales_percentage_USD,

              sum(case when evolution_type = 'RECURRING' 
                then (average_price_per_unit_CAD_CP - average_price_per_unit_CAD_CP_with_fx_rate_PP) * orders_quantity_CP 
                else 0 end) as fx_effect_sales_CAD,
              sum(case when evolution_type = 'RECURRING' 
                then safe_divide(((average_price_per_unit_CAD_CP - average_price_per_unit_CAD_CP_with_fx_rate_PP) * orders_quantity_CP),orders_sales_CAD_PP) 
                else 0 end) as fx_effect_sales_percentage_CAD,

              sum(case when evolution_type = 'RECURRING' 
                then (average_price_per_unit_MXN_CP - average_price_per_unit_MXN_CP_with_fx_rate_PP) * orders_quantity_CP 
                else 0 end) as fx_effect_sales_MXN,
              sum(case when evolution_type = 'RECURRING' 
                then safe_divide(((average_price_per_unit_MXN_CP - average_price_per_unit_MXN_CP_with_fx_rate_PP) * orders_quantity_CP),orders_sales_MXN_PP) 
                else 0 end) as fx_effect_sales_percentage_MXN,

              sum(case when evolution_type = 'RECURRING' 
                then (average_price_per_unit_BRL_CP - average_price_per_unit_BRL_CP_with_fx_rate_PP) * orders_quantity_CP 
                else 0 end) as fx_effect_sales_BRL,
              sum(case when evolution_type = 'RECURRING' 
                then safe_divide(((average_price_per_unit_BRL_CP - average_price_per_unit_BRL_CP_with_fx_rate_PP) * orders_quantity_CP),orders_sales_BRL_PP) 
                else 0 end) as fx_effect_sales_percentage_BRL,

    from step3_calculations_on_sku_level_mom_CP

    group by all

)

    -- STEP 5: Final select for the Growth decomposition month over month

, waterfall_final_output_countries_mom as (

      select 

        'Link' as source_actuals,
        equipment_market,
        equipment_sub_market,

        Statistic_country,
        Statistic_country_iso,

        product_category,
        product_subcategory,
        product_class,
        product_type,

        brm_grouping,
        brm_grouping_sales_team,

        TVH_no_Brand_code,
        TVH_no_Brand_descr,

        unit,

        Period, 

        # SALES
        sum(orders_sales_recurring_EUR_CP) as orders_sales_recurring_EUR_CP_mom,
        sum(orders_sales_recurring_EUR_PP) as orders_sales_recurring_EUR_PP_mom,

        sum(orders_sales_recurring_USD_CP) as orders_sales_recurring_USD_CP_mom,
        sum(orders_sales_recurring_USD_PP) as orders_sales_recurring_USD_PP_mom,

        sum(orders_sales_recurring_CAD_CP) as orders_sales_recurring_CAD_CP_mom,
        sum(orders_sales_recurring_CAD_PP) as orders_sales_recurring_CAD_PP_mom,

        sum(orders_sales_recurring_MXN_CP) as orders_sales_recurring_MXN_CP_mom,
        sum(orders_sales_recurring_MXN_PP) as orders_sales_recurring_MXN_PP_mom,

        sum(orders_sales_recurring_BRL_CP) as orders_sales_recurring_BRL_CP_mom,
        sum(orders_sales_recurring_BRL_PP) as orders_sales_recurring_BRL_PP_mom,


        sum(sales_amount_EUR_CP) as sales_amount_EUR_CP_mom,
        sum(sales_amount_EUR_PP) as sales_amount_EUR_PP_mom,

        sum(sales_amount_USD_CP) as sales_amount_USD_CP_mom,
        sum(sales_amount_USD_PP) as sales_amount_USD_PP_mom,

        sum(sales_amount_CAD_CP) as sales_amount_CAD_CP_mom,
        sum(sales_amount_CAD_PP) as sales_amount_CAD_PP_mom,

        sum(sales_amount_MXN_CP) as sales_amount_MXN_CP_mom,
        sum(sales_amount_MXN_PP) as sales_amount_MXN_PP_mom,

        sum(sales_amount_BRL_CP) as sales_amount_BRL_CP_mom,
        sum(sales_amount_BRL_PP) as sales_amount_BRL_PP_mom,


        sum(sales_amount_new_EUR_CP) as sales_amount_new_EUR_CP_mom,
        sum(ifnull(sales_amount_lost_EUR_CP,0)) as sales_amount_lost_EUR_CP_mom,
        sum(sales_amount_EUR_delta) as sales_amount_EUR_delta_CP_mom, 

        sum(sales_amount_new_USD_CP) as sales_amount_new_USD_CP_mom,
        sum(ifnull(sales_amount_lost_USD_CP,0)) as sales_amount_lost_USD_CP_mom,
        sum(sales_amount_USD_delta) as sales_amount_USD_delta_CP_mom, 

        sum(sales_amount_new_CAD_CP) as sales_amount_new_CAD_CP_mom,
        sum(ifnull(sales_amount_lost_CAD_CP,0)) as sales_amount_lost_CAD_CP_mom,
        sum(sales_amount_CAD_delta) as sales_amount_CAD_delta_CP_mom, 

        sum(sales_amount_new_MXN_CP) as sales_amount_new_MXN_CP_mom,
        sum(ifnull(sales_amount_lost_MXN_CP,0)) as sales_amount_lost_MXN_CP_mom,
        sum(sales_amount_MXN_delta) as sales_amount_MXN_delta_CP_mom, 

        sum(sales_amount_new_BRL_CP) as sales_amount_new_BRL_CP_mom,
        sum(ifnull(sales_amount_lost_BRL_CP,0)) as sales_amount_lost_BRL_CP_mom,
        sum(sales_amount_BRL_delta) as sales_amount_BRL_delta_CP_mom, 


        sum(Fees_sales_EUR_delta) as Fees_sales_EUR_delta_CP_mom,
        sum(warranties_sales_EUR_delta) as warranties_sales_EUR_delta_CP_mom,
        sum(returns_on_warranties_sales_EUR_delta) as returns_on_warranties_sales_EUR_delta_CP_mom,
        sum(Fees_sales_EUR_delta) + sum(Rebates_sales_EUR_delta) + sum(warranties_sales_EUR_delta) + sum(returns_on_warranties_sales_EUR_delta) as F_R_W_sales_EUR_delta_CP_mom,
        sum(returns_sales_EUR_delta) as returns_sales_EUR_delta_CP_mom,
        sum(noncommercial_sales_EUR_delta) as noncommercial_sales_EUR_delta_CP_mom,
        sum(integration_sales_EUR_delta) as integration_sales_EUR_delta_CP_mom,

        sum(Fees_sales_USD_delta) as Fees_sales_USD_delta_CP_mom,
        sum(warranties_sales_USD_delta) as warranties_sales_USD_delta_CP_mom,
        sum(returns_on_warranties_sales_USD_delta) as returns_on_warranties_sales_USD_delta_CP_mom,
        sum(Fees_sales_USD_delta) + sum(Rebates_sales_USD_delta) + sum(warranties_sales_USD_delta) + sum(returns_on_warranties_sales_USD_delta) as F_R_W_sales_USD_delta_CP_mom,
        sum(returns_sales_USD_delta) as returns_sales_USD_delta_CP_mom,
        sum(noncommercial_sales_USD_delta) as noncommercial_sales_USD_delta_CP_mom,
        sum(integration_sales_USD_delta) as integration_sales_USD_delta_CP_mom,

        sum(Fees_sales_CAD_delta) as Fees_sales_CAD_delta_CP_mom,
        sum(warranties_sales_CAD_delta) as warranties_sales_CAD_delta_CP_mom,
        sum(returns_on_warranties_sales_CAD_delta) as returns_on_warranties_sales_CAD_delta_CP_mom,
        sum(Fees_sales_CAD_delta) + sum(Rebates_sales_CAD_delta) + sum(warranties_sales_CAD_delta) + sum(returns_on_warranties_sales_CAD_delta) as F_R_W_sales_CAD_delta_CP_mom,
        sum(returns_sales_CAD_delta) as returns_sales_CAD_delta_CP_mom,
        sum(noncommercial_sales_CAD_delta) as noncommercial_sales_CAD_delta_CP_mom,
        sum(integration_sales_CAD_delta) as integration_sales_CAD_delta_CP_mom,

        sum(Fees_sales_MXN_delta) as Fees_sales_MXN_delta_CP_mom,
        sum(warranties_sales_MXN_delta) as warranties_sales_MXN_delta_CP_mom,
        sum(returns_on_warranties_sales_MXN_delta) as returns_on_warranties_sales_MXN_delta_CP_mom,
        sum(Fees_sales_MXN_delta) + sum(Rebates_sales_MXN_delta) + sum(warranties_sales_MXN_delta) + sum(returns_on_warranties_sales_MXN_delta) as F_R_W_sales_MXN_delta_CP_mom,
        sum(returns_sales_MXN_delta) as returns_sales_MXN_delta_CP_mom,
        sum(noncommercial_sales_MXN_delta) as noncommercial_sales_MXN_delta_CP_mom,
        sum(integration_sales_MXN_delta) as integration_sales_MXN_delta_CP_mom,

        sum(Fees_sales_BRL_delta) as Fees_sales_BRL_delta_CP_mom,
        sum(warranties_sales_BRL_delta) as warranties_sales_BRL_delta_CP_mom,
        sum(returns_on_warranties_sales_BRL_delta) as returns_on_warranties_sales_BRL_delta_CP_mom,
        sum(Fees_sales_BRL_delta) + sum(Rebates_sales_BRL_delta) + sum(warranties_sales_BRL_delta) + sum(returns_on_warranties_sales_BRL_delta) as F_R_W_sales_BRL_delta_CP_mom,
        sum(returns_sales_BRL_delta) as returns_sales_BRL_delta_CP_mom,
        sum(noncommercial_sales_BRL_delta) as noncommercial_sales_BRL_delta_CP_mom,
        sum(integration_sales_BRL_delta) as integration_sales_BRL_delta_CP_mom,


        # COST
        sum(cost_EUR_CP) as cost_EUR_CP_mom,
        sum(cost_EUR_PP) as cost_EUR_PP_mom,

        sum(cost_USD_CP) as cost_USD_CP_mom,
        sum(cost_USD_PP) as cost_USD_PP_mom,

        sum(cost_CAD_CP) as cost_CAD_CP_mom,
        sum(cost_CAD_PP) as cost_CAD_PP_mom,

        sum(cost_MXN_CP) as cost_MXN_CP_mom,
        sum(cost_MXN_PP) as cost_MXN_PP_mom,

        sum(cost_BRL_CP) as cost_BRL_CP_mom,
        sum(cost_BRL_PP) as cost_BRL_PP_mom,


        sum(orders_cost_EUR_CP) as orders_cost_EUR_CP_mom,
        sum(orders_cost_EUR_PP) as orders_cost_EUR_PP_mom,
        sum(orders_cost_recurring_EUR_CP) as orders_cost_recurring_EUR_CP_mom,
        sum(orders_cost_recurring_EUR_PP) as orders_cost_recurring_EUR_PP_mom,

        sum(orders_cost_USD_CP) as orders_cost_USD_CP_mom,
        sum(orders_cost_USD_PP) as orders_cost_USD_PP_mom,
        sum(orders_cost_recurring_USD_CP) as orders_cost_recurring_USD_CP_mom,
        sum(orders_cost_recurring_USD_PP) as orders_cost_recurring_USD_PP_mom,

        sum(orders_cost_CAD_CP) as orders_cost_CAD_CP_mom,
        sum(orders_cost_CAD_PP) as orders_cost_CAD_PP_mom,
        sum(orders_cost_recurring_CAD_CP) as orders_cost_recurring_CAD_CP_mom,
        sum(orders_cost_recurring_CAD_PP) as orders_cost_recurring_CAD_PP_mom,

        sum(orders_cost_MXN_CP) as orders_cost_MXN_CP_mom,
        sum(orders_cost_MXN_PP) as orders_cost_MXN_PP_mom,
        sum(orders_cost_recurring_MXN_CP) as orders_cost_recurring_MXN_CP_mom,
        sum(orders_cost_recurring_MXN_PP) as orders_cost_recurring_MXN_PP_mom,

        sum(orders_cost_BRL_CP) as orders_cost_BRL_CP_mom,
        sum(orders_cost_BRL_PP) as orders_cost_BRL_PP_mom,
        sum(orders_cost_recurring_BRL_CP) as orders_cost_recurring_BRL_CP_mom,
        sum(orders_cost_recurring_BRL_PP) as orders_cost_recurring_BRL_PP_mom,

        sum(cost_amount_new_EUR_CP) as cost_amount_new_EUR_CP_mom,
        sum(ifnull(cost_amount_lost_EUR_CP,0)) as cost_amount_lost_EUR_CP_mom,

        sum(cost_amount_new_USD_CP) as cost_amount_new_USD_CP_mom,
        sum(ifnull(cost_amount_lost_USD_CP,0)) as cost_amount_lost_USD_CP_mom,

        sum(cost_amount_new_CAD_CP) as cost_amount_new_CAD_CP_mom,
        sum(ifnull(cost_amount_lost_CAD_CP,0)) as cost_amount_lost_CAD_CP_mom,

        sum(cost_amount_new_MXN_CP) as cost_amount_new_MXN_CP_mom,
        sum(ifnull(cost_amount_lost_MXN_CP,0)) as cost_amount_lost_MXN_CP_mom,

        sum(cost_amount_new_BRL_CP) as cost_amount_new_BRL_CP_mom,
        sum(ifnull(cost_amount_lost_BRL_CP,0)) as cost_amount_lost_BRL_CP_mom,

        sum(Fees_cost_EUR_delta) as Fees_cost_EUR_delta_CP_mom,
        sum(warranties_cost_EUR_delta) as warranties_cost_EUR_delta_CP_mom,
        sum(returns_on_warranties_cost_EUR_delta) as returns_on_warranties_cost_EUR_delta_CP_mom,
        sum(Fees_cost_EUR_delta) + sum(Rebates_cost_EUR_delta) + sum(warranties_cost_EUR_delta) + sum(returns_on_warranties_cost_EUR_delta) as F_R_W_cost_EUR_delta_CP_mom,
        sum(returns_cost_EUR_delta) as returns_cost_EUR_delta_CP_mom,
        sum(noncommercial_cost_EUR_delta) as noncommercial_cost_EUR_delta_CP_mom,
        sum(integration_cost_EUR_delta) as integration_cost_EUR_delta_CP_mom,     

        sum(Fees_cost_USD_delta) as Fees_cost_USD_delta_CP_mom,
        sum(warranties_cost_USD_delta) as warranties_cost_USD_delta_CP_mom,
        sum(returns_on_warranties_cost_USD_delta) as returns_on_warranties_cost_USD_delta_CP_mom,
        sum(Fees_cost_USD_delta) + sum(Rebates_cost_USD_delta) + sum(warranties_cost_USD_delta) + sum(returns_on_warranties_cost_USD_delta) as F_R_W_cost_USD_delta_CP_mom,
        sum(returns_cost_USD_delta) as returns_cost_USD_delta_CP_mom,
        sum(noncommercial_cost_USD_delta) as noncommercial_cost_USD_delta_CP_mom,
        sum(integration_cost_USD_delta) as integration_cost_USD_delta_CP_mom,

        sum(Fees_cost_CAD_delta) as Fees_cost_CAD_delta_CP_mom,
        sum(warranties_cost_CAD_delta) as warranties_cost_CAD_delta_CP_mom,
        sum(returns_on_warranties_cost_CAD_delta) as returns_on_warranties_cost_CAD_delta_CP_mom,
        sum(Fees_cost_CAD_delta) + sum(Rebates_cost_CAD_delta) + sum(warranties_cost_CAD_delta) + sum(returns_on_warranties_cost_CAD_delta) as F_R_W_cost_CAD_delta_CP_mom,
        sum(returns_cost_CAD_delta) as returns_cost_CAD_delta_CP_mom,
        sum(noncommercial_cost_CAD_delta) as noncommercial_cost_CAD_delta_CP_mom,
        sum(integration_cost_CAD_delta) as integration_cost_CAD_delta_CP_mom,

        sum(Fees_cost_MXN_delta) as Fees_cost_MXN_delta_CP_mom,
        sum(warranties_cost_MXN_delta) as warranties_cost_MXN_delta_CP_mom,
        sum(returns_on_warranties_cost_MXN_delta) as returns_on_warranties_cost_MXN_delta_CP_mom,
        sum(Fees_cost_MXN_delta) + sum(Rebates_cost_MXN_delta) + sum(warranties_cost_MXN_delta) + sum(returns_on_warranties_cost_MXN_delta) as F_R_W_cost_MXN_delta_CP_mom,
        sum(returns_cost_MXN_delta) as returns_cost_MXN_delta_CP_mom,
        sum(noncommercial_cost_MXN_delta) as noncommercial_cost_MXN_delta_CP_mom,
        sum(integration_cost_MXN_delta) as integration_cost_MXN_delta_CP_mom,

        sum(Fees_cost_BRL_delta) as Fees_cost_BRL_delta_CP_mom,
        sum(warranties_cost_BRL_delta) as warranties_cost_BRL_delta_CP_mom,
        sum(returns_on_warranties_cost_BRL_delta) as returns_on_warranties_cost_BRL_delta_CP_mom,
        sum(Fees_cost_BRL_delta) + sum(Rebates_cost_BRL_delta) + sum(warranties_cost_BRL_delta) + sum(returns_on_warranties_cost_BRL_delta) as F_R_W_cost_BRL_delta_CP_mom,
        sum(returns_cost_BRL_delta) as returns_cost_BRL_delta_CP_mom,
        sum(noncommercial_cost_BRL_delta) as noncommercial_cost_BRL_delta_CP_mom,
        sum(integration_cost_BRL_delta) as integration_cost_BRL_delta_CP_mom,

        # COST LANDED       
        sum(cost_landed_EUR_CP) as cost_landed_EUR_CP_mom,
        sum(cost_landed_EUR_PP) as cost_landed_EUR_PP_mom,

        sum(cost_landed_USD_CP) as cost_landed_USD_CP_mom,
        sum(cost_landed_USD_PP) as cost_landed_USD_PP_mom,

        sum(cost_landed_CAD_CP) as cost_landed_CAD_CP_mom,
        sum(cost_landed_CAD_PP) as cost_landed_CAD_PP_mom,

        sum(cost_landed_MXN_CP) as cost_landed_MXN_CP_mom,
        sum(cost_landed_MXN_PP) as cost_landed_MXN_PP_mom,

        sum(cost_landed_BRL_CP) as cost_landed_BRL_CP_mom,
        sum(cost_landed_BRL_PP) as cost_landed_BRL_PP_mom,

        sum(orders_cost_landed_EUR_CP) as orders_cost_landed_EUR_CP_mom,
        sum(orders_cost_landed_EUR_PP) as orders_cost_landed_EUR_PP_mom,
        sum(orders_cost_landed_recurring_EUR_CP) as orders_cost_landed_recurring_EUR_CP_mom,
        sum(orders_cost_landed_recurring_EUR_PP) as orders_cost_landed_recurring_EUR_PP_mom,

        sum(orders_cost_landed_USD_CP) as orders_cost_landed_USD_CP_mom,
        sum(orders_cost_landed_USD_PP) as orders_cost_landed_USD_PP_mom,
        sum(orders_cost_landed_recurring_USD_CP) as orders_cost_landed_recurring_USD_CP_mom,
        sum(orders_cost_landed_recurring_USD_PP) as orders_cost_landed_recurring_USD_PP_mom,

        sum(orders_cost_landed_CAD_CP) as orders_cost_landed_CAD_CP_mom,
        sum(orders_cost_landed_CAD_PP) as orders_cost_landed_CAD_PP_mom,
        sum(orders_cost_landed_recurring_CAD_CP) as orders_cost_landed_recurring_CAD_CP_mom,
        sum(orders_cost_landed_recurring_CAD_PP) as orders_cost_landed_recurring_CAD_PP_mom,

        sum(orders_cost_landed_MXN_CP) as orders_cost_landed_MXN_CP_mom,
        sum(orders_cost_landed_MXN_PP) as orders_cost_landed_MXN_PP_mom,
        sum(orders_cost_landed_recurring_MXN_CP) as orders_cost_landed_recurring_MXN_CP_mom,
        sum(orders_cost_landed_recurring_MXN_PP) as orders_cost_landed_recurring_MXN_PP_mom,

        sum(orders_cost_landed_BRL_CP) as orders_cost_landed_BRL_CP_mom,
        sum(orders_cost_landed_BRL_PP) as orders_cost_landed_BRL_PP_mom,
        sum(orders_cost_landed_recurring_BRL_CP) as orders_cost_landed_recurring_BRL_CP_mom,
        sum(orders_cost_landed_recurring_BRL_PP) as orders_cost_landed_recurring_BRL_PP_mom,


        sum(cost_landed_amount_new_EUR_CP) as cost_landed_amount_new_EUR_CP_mom,
        sum(ifnull(cost_landed_amount_lost_EUR_CP,0)) as cost_landed_amount_lost_EUR_CP_mom,

        sum(cost_landed_amount_new_USD_CP) as cost_landed_amount_new_USD_CP_mom,
        sum(ifnull(cost_landed_amount_lost_USD_CP,0)) as cost_landed_amount_lost_USD_CP_mom,

        sum(cost_landed_amount_new_CAD_CP) as cost_landed_amount_new_CAD_CP_mom,
        sum(ifnull(cost_landed_amount_lost_CAD_CP,0)) as cost_landed_amount_lost_CAD_CP_mom,

        sum(cost_landed_amount_new_MXN_CP) as cost_landed_amount_new_MXN_CP_mom,
        sum(ifnull(cost_landed_amount_lost_MXN_CP,0)) as cost_landed_amount_lost_MXN_CP_mom,

        sum(cost_landed_amount_new_BRL_CP) as cost_landed_amount_new_BRL_CP_mom,
        sum(ifnull(cost_landed_amount_lost_BRL_CP,0)) as cost_landed_amount_lost_BRL_CP_mom,

        sum(Fees_cost_landed_EUR_delta) as Fees_cost_landed_EUR_delta_CP_mom,
        sum(warranties_cost_landed_EUR_delta) as warranties_cost_landed_EUR_delta_CP_mom,
        sum(returns_on_warranties_cost_landed_EUR_delta) as returns_on_warranties_cost_landed_EUR_delta_CP_mom,
        sum(Fees_cost_landed_EUR_delta) + sum(Rebates_cost_landed_EUR_delta) + sum(warranties_cost_landed_EUR_delta) + sum(returns_on_warranties_cost_landed_EUR_delta) as F_R_W_cost_landed_EUR_delta_CP_mom,
        sum(returns_cost_landed_EUR_delta) as returns_cost_landed_EUR_delta_CP_mom,
        sum(noncommercial_cost_landed_EUR_delta) as noncommercial_cost_landed_EUR_delta_CP_mom,
        sum(integration_cost_landed_EUR_delta) as integration_cost_landed_EUR_delta_CP_mom,       

        sum(Fees_cost_landed_USD_delta) as Fees_cost_landed_USD_delta_CP_mom,
        sum(warranties_cost_landed_USD_delta) as warranties_cost_landed_USD_delta_CP_mom,
        sum(returns_on_warranties_cost_landed_USD_delta) as returns_on_warranties_cost_landed_USD_delta_CP_mom,
        sum(Fees_cost_landed_USD_delta) + sum(Rebates_cost_landed_USD_delta) + sum(warranties_cost_landed_USD_delta) + sum(returns_on_warranties_cost_landed_USD_delta) as F_R_W_cost_landed_USD_delta_CP_mom,
        sum(returns_cost_landed_USD_delta) as returns_cost_landed_USD_delta_CP_mom,
        sum(noncommercial_cost_landed_USD_delta) as noncommercial_cost_landed_USD_delta_CP_mom,
        sum(integration_cost_landed_USD_delta) as integration_cost_landed_USD_delta_CP_mom,

        sum(Fees_cost_landed_CAD_delta) as Fees_cost_landed_CAD_delta_CP_mom,
        sum(warranties_cost_landed_CAD_delta) as warranties_cost_landed_CAD_delta_CP_mom,
        sum(returns_on_warranties_cost_landed_CAD_delta) as returns_on_warranties_cost_landed_CAD_delta_CP_mom,
        sum(Fees_cost_landed_CAD_delta) + sum(Rebates_cost_landed_CAD_delta) + sum(warranties_cost_landed_CAD_delta) + sum(returns_on_warranties_cost_landed_CAD_delta) as F_R_W_cost_landed_CAD_delta_CP_mom,
        sum(returns_cost_landed_CAD_delta) as returns_cost_landed_CAD_delta_CP_mom,
        sum(noncommercial_cost_landed_CAD_delta) as noncommercial_cost_landed_CAD_delta_CP_mom,
        sum(integration_cost_landed_CAD_delta) as integration_cost_landed_CAD_delta_CP_mom,

        sum(Fees_cost_landed_MXN_delta) as Fees_cost_landed_MXN_delta_CP_mom,
        sum(warranties_cost_landed_MXN_delta) as warranties_cost_landed_MXN_delta_CP_mom,
        sum(returns_on_warranties_cost_landed_MXN_delta) as returns_on_warranties_cost_landed_MXN_delta_CP_mom,
        sum(Fees_cost_landed_MXN_delta) + sum(Rebates_cost_landed_MXN_delta) + sum(warranties_cost_landed_MXN_delta) + sum(returns_on_warranties_cost_landed_MXN_delta) as F_R_W_cost_landed_MXN_delta_CP_mom,
        sum(returns_cost_landed_MXN_delta) as returns_cost_landed_MXN_delta_CP_mom,
        sum(noncommercial_cost_landed_MXN_delta) as noncommercial_cost_landed_MXN_delta_CP_mom,
        sum(integration_cost_landed_MXN_delta) as integration_cost_landed_MXN_delta_CP_mom,

        sum(Fees_cost_landed_BRL_delta) as Fees_cost_landed_BRL_delta_CP_mom,
        sum(warranties_cost_landed_BRL_delta) as warranties_cost_landed_BRL_delta_CP_mom,
        sum(returns_on_warranties_cost_landed_BRL_delta) as returns_on_warranties_cost_landed_BRL_delta_CP_mom,
        sum(Fees_cost_landed_BRL_delta) + sum(Rebates_cost_landed_BRL_delta) + sum(warranties_cost_landed_BRL_delta) + sum(returns_on_warranties_cost_landed_BRL_delta) as F_R_W_cost_landed_BRL_delta_CP_mom,
        sum(returns_cost_landed_BRL_delta) as returns_cost_landed_BRL_delta_CP_mom,
        sum(noncommercial_cost_landed_BRL_delta) as noncommercial_cost_landed_BRL_delta_CP_mom,
        sum(integration_cost_landed_BRL_delta) as integration_cost_landed_BRL_delta_CP_mom,


        # EFFECTS
        sum(sales_price_effect_EUR) as sales_price_effect_recurring_EUR_CP_mom,
        sum(quantity_effect_sales_EUR) as quantity_effect_sales_recurring_EUR_CP_mom,
        sum(quantity_effect_cost_EUR) as quantity_effect_cost_recurring_EUR_CP_mom,
        sum(quantity_effect_cost_landed_EUR) as quantity_effect_cost_landed_recurring_EUR_CP_mom,
        sum(fx_effect_sales_EUR) as fx_effect_sales_recurring_EUR_CP_mom,
        sum(cost_effect_EUR) as cost_effect_recurring_EUR_CP_mom,
        sum(cost_landed_effect_EUR) as cost_landed_effect_recurring_EUR_CP_mom,

        sum(sales_price_effect_USD) as sales_price_effect_recurring_USD_CP_mom,
        sum(quantity_effect_sales_USD) as quantity_effect_sales_recurring_USD_CP_mom,
        sum(quantity_effect_cost_USD) as quantity_effect_cost_recurring_USD_CP_mom,
        sum(quantity_effect_cost_landed_USD) as quantity_effect_cost_landed_recurring_USD_CP_mom,
        sum(fx_effect_sales_USD) as fx_effect_sales_recurring_USD_CP_mom,
        sum(cost_effect_USD) as cost_effect_recurring_USD_CP_mom,
        sum(cost_landed_effect_USD) as cost_landed_effect_recurring_USD_CP_mom,

        sum(sales_price_effect_CAD) as sales_price_effect_recurring_CAD_CP_mom,
        sum(quantity_effect_sales_CAD) as quantity_effect_sales_recurring_CAD_CP_mom,
        sum(quantity_effect_cost_CAD) as quantity_effect_cost_recurring_CAD_CP_mom,
        sum(quantity_effect_cost_landed_CAD) as quantity_effect_cost_landed_recurring_CAD_CP_mom,
        sum(fx_effect_sales_CAD) as fx_effect_sales_recurring_CAD_CP_mom,
        sum(cost_effect_CAD) as cost_effect_recurring_CAD_CP_mom,
        sum(cost_landed_effect_CAD) as cost_landed_effect_recurring_CAD_CP_mom,

        sum(sales_price_effect_MXN) as sales_price_effect_recurring_MXN_CP_mom,
        sum(quantity_effect_sales_MXN) as quantity_effect_sales_recurring_MXN_CP_mom,
        sum(quantity_effect_cost_MXN) as quantity_effect_cost_recurring_MXN_CP_mom,
        sum(quantity_effect_cost_landed_MXN) as quantity_effect_cost_landed_recurring_MXN_CP_mom,
        sum(fx_effect_sales_MXN) as fx_effect_sales_recurring_MXN_CP_mom,
        sum(cost_effect_MXN) as cost_effect_recurring_MXN_CP_mom,
        sum(cost_landed_effect_MXN) as cost_landed_effect_recurring_MXN_CP_mom,

        sum(sales_price_effect_BRL) as sales_price_effect_recurring_BRL_CP_mom,
        sum(quantity_effect_sales_BRL) as quantity_effect_sales_recurring_BRL_CP_mom,
        sum(quantity_effect_cost_BRL) as quantity_effect_cost_recurring_BRL_CP_mom,
        sum(quantity_effect_cost_landed_BRL) as quantity_effect_cost_landed_recurring_BRL_CP_mom,
        sum(fx_effect_sales_BRL) as fx_effect_sales_recurring_BRL_CP_mom,
        sum(cost_effect_BRL) as cost_effect_recurring_BRL_CP_mom,
        sum(cost_landed_effect_BRL) as cost_landed_effect_recurring_BRL_CP_mom              


      from step4_further_calculations_on_sku_level_and_aggregation_mom_CP base
      group by all
)

-- GROWTH DECOMPOSITION | Year to month calculation ---------------------------------------------------------------------------------------------
    -- STEP 1: Get measures on SKU level for Current Period

, step1_measures_on_SKU_level_ytm_CP as (

      select  
          --- Calculation level
            SKU_no,

            equipment_market,
            equipment_sub_market,
            equipment_id_code,

            Statistic_country,
            Statistic_country_iso,

            brm_grouping,
            brm_grouping_sales_team,

            Currency_transaction,

            product_category, 
            product_subcategory, 
            product_class,
            product_type,
            product_growth_classification_macro_region,

            TVH_no_Brand_code,
            TVH_no_Brand_descr,

            unit,

            date_trunc(Sales_invoice_date, month) as Period, 

          --- Sales
            sum(Delivered_amount_transaction_cur * budget_rate_eur)                                                                   as sales_amount_EUR_CP_ytm,
            sum(Delivered_amount_transaction_cur * budget_rate_usd)                                                                   as sales_amount_USD_CP_ytm,
            sum(Delivered_amount_transaction_cur * budget_rate_cad)                                                                   as sales_amount_CAD_CP_ytm,
            sum(Delivered_amount_transaction_cur * budget_rate_mxn)                                                                   as sales_amount_MXN_CP_ytm,
            sum(Delivered_amount_transaction_cur * budget_rate_brl)                                                                   as sales_amount_BRL_CP_ytm,
            sum(Delivered_amount_transaction_cur)                                                                                     as sales_amount_transaction_cur_CP_ytm,

            sum(case when is_integrated_flag = false then Fees_sales_transaction_cur * budget_rate_eur end)                            as Fees_sales_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_sales_transaction_cur * budget_rate_eur end)                         as Rebates_sales_EUR_CP_ytm,          
            sum(case when is_integrated_flag = false then warranties_sales_transaction_cur * budget_rate_eur end)                      as warranties_sales_EUR_CP_ytm,          
            sum(case when is_integrated_flag = false then returns_on_warranties_sales_transaction_cur * budget_rate_eur end)           as returns_on_warranties_sales_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then returns_sales_transaction_cur * budget_rate_eur end)                         as returns_sales_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_sales_transaction_cur * budget_rate_eur end)                   as noncommercial_sales_EUR_CP_ytm,
            sum(case when is_integrated_flag = true then Delivered_amount_transaction_cur * budget_rate_eur end)                       as integration_sales_EUR_CP_ytm,               
            sum(case when is_integrated_flag = false then orders_sales_transaction_cur * budget_rate_eur end)                          as orders_sales_EUR_CP_ytm,

            sum(case when is_integrated_flag = false then Fees_sales_transaction_cur * budget_rate_usd end)                            as Fees_sales_USD_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_sales_transaction_cur * budget_rate_usd end)                         as Rebates_sales_USD_CP_ytm,          
            sum(case when is_integrated_flag = false then warranties_sales_transaction_cur * budget_rate_usd end)                      as warranties_sales_USD_CP_ytm,          
            sum(case when is_integrated_flag = false then returns_on_warranties_sales_transaction_cur * budget_rate_usd end)           as returns_on_warranties_sales_USD_CP_ytm,
            sum(case when is_integrated_flag = false then returns_sales_transaction_cur * budget_rate_usd end)                         as returns_sales_USD_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_sales_transaction_cur * budget_rate_usd end)                   as noncommercial_sales_USD_CP_ytm,
            sum(case when is_integrated_flag = true then Delivered_amount_transaction_cur * budget_rate_usd end)                       as integration_sales_USD_CP_ytm,               
            sum(case when is_integrated_flag = false then orders_sales_transaction_cur * budget_rate_usd end)                          as orders_sales_USD_CP_ytm,

            sum(case when is_integrated_flag = false then Fees_sales_transaction_cur * budget_rate_CAD end)                            as Fees_sales_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_sales_transaction_cur * budget_rate_CAD end)                         as Rebates_sales_CAD_CP_ytm,          
            sum(case when is_integrated_flag = false then warranties_sales_transaction_cur * budget_rate_CAD end)                      as warranties_sales_CAD_CP_ytm,          
            sum(case when is_integrated_flag = false then returns_on_warranties_sales_transaction_cur * budget_rate_CAD end)           as returns_on_warranties_sales_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then returns_sales_transaction_cur * budget_rate_CAD end)                         as returns_sales_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_sales_transaction_cur * budget_rate_CAD end)                   as noncommercial_sales_CAD_CP_ytm,
            sum(case when is_integrated_flag = true then Delivered_amount_transaction_cur * budget_rate_CAD end)                       as integration_sales_CAD_CP_ytm,               
            sum(case when is_integrated_flag = false then orders_sales_transaction_cur * budget_rate_CAD end)                          as orders_sales_CAD_CP_ytm,

            sum(case when is_integrated_flag = false then Fees_sales_transaction_cur * budget_rate_mxn end)                            as Fees_sales_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_sales_transaction_cur * budget_rate_mxn end)                         as Rebates_sales_MXN_CP_ytm,          
            sum(case when is_integrated_flag = false then warranties_sales_transaction_cur * budget_rate_mxn end)                      as warranties_sales_MXN_CP_ytm,          
            sum(case when is_integrated_flag = false then returns_on_warranties_sales_transaction_cur * budget_rate_mxn end)           as returns_on_warranties_sales_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then returns_sales_transaction_cur * budget_rate_mxn end)                         as returns_sales_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_sales_transaction_cur * budget_rate_mxn end)                   as noncommercial_sales_MXN_CP_ytm,
            sum(case when is_integrated_flag = true then Delivered_amount_transaction_cur * budget_rate_mxn end)                       as integration_sales_MXN_CP_ytm,               
            sum(case when is_integrated_flag = false then orders_sales_transaction_cur * budget_rate_mxn end)                          as orders_sales_MXN_CP_ytm,

            sum(case when is_integrated_flag = false then Fees_sales_transaction_cur * budget_rate_brl end)                            as Fees_sales_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_sales_transaction_cur * budget_rate_brl end)                         as Rebates_sales_BRL_CP_ytm,          
            sum(case when is_integrated_flag = false then warranties_sales_transaction_cur * budget_rate_brl end)                      as warranties_sales_BRL_CP_ytm,          
            sum(case when is_integrated_flag = false then returns_on_warranties_sales_transaction_cur * budget_rate_brl end)           as returns_on_warranties_sales_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then returns_sales_transaction_cur * budget_rate_brl end)                         as returns_sales_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_sales_transaction_cur * budget_rate_brl end)                   as noncommercial_sales_BRL_CP_ytm,
            sum(case when is_integrated_flag = true then Delivered_amount_transaction_cur * budget_rate_brl end)                       as integration_sales_BRL_CP_ytm,               
            sum(case when is_integrated_flag = false then orders_sales_transaction_cur * budget_rate_brl end)                          as orders_sales_BRL_CP_ytm,        

            sum(case when is_integrated_flag = false then orders_sales_transaction_cur end)                                            as orders_sales_transaction_currency_CP_ytm,

          --- Cost (group)
            sum(case when is_integrated_flag = false then Fees_cost_transaction_cur * budget_rate_eur end)                          as Fees_cost_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_cost_transaction_cur * budget_rate_eur end)                       as Rebates_cost_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then warranties_cost_transaction_cur * budget_rate_eur end)                    as warranties_cost_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_transaction_cur * budget_rate_eur end)         as returns_on_warranties_cost_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then returns_cost_transaction_cur * budget_rate_eur end)                       as returns_cost_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_cost_transaction_cur * budget_rate_eur end)                 as noncommercial_cost_EUR_CP_ytm,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_amount_transaction_cur * budget_rate_eur end)         as integration_cost_EUR_CP_ytm,
            sum( case when is_integrated_flag = false then orders_cost_transaction_cur * budget_rate_eur end)                        as orders_cost_EUR_CP_ytm,          

            sum(case when is_integrated_flag = false then Fees_cost_transaction_cur * budget_rate_usd end)                          as Fees_cost_USD_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_cost_transaction_cur * budget_rate_usd end)                       as Rebates_cost_USD_CP_ytm,
            sum(case when is_integrated_flag = false then warranties_cost_transaction_cur * budget_rate_usd end)                    as warranties_cost_USD_CP_ytm,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_transaction_cur * budget_rate_usd end)         as returns_on_warranties_cost_USD_CP_ytm,
            sum(case when is_integrated_flag = false then returns_cost_transaction_cur * budget_rate_usd end)                       as returns_cost_USD_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_cost_transaction_cur * budget_rate_usd end)                 as noncommercial_cost_USD_CP_ytm,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_amount_transaction_cur * budget_rate_usd end)         as integration_cost_USD_CP_ytm,
            sum( case when is_integrated_flag = false then orders_cost_transaction_cur * budget_rate_usd end)                        as orders_cost_USD_CP_ytm,

            sum(case when is_integrated_flag = false then Fees_cost_transaction_cur * budget_rate_cad end)                          as Fees_cost_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_cost_transaction_cur * budget_rate_cad end)                       as Rebates_cost_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then warranties_cost_transaction_cur * budget_rate_cad end)                    as warranties_cost_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_transaction_cur * budget_rate_cad end)         as returns_on_warranties_cost_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then returns_cost_transaction_cur * budget_rate_cad end)                       as returns_cost_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_cost_transaction_cur * budget_rate_cad end)                 as noncommercial_cost_CAD_CP_ytm,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_amount_transaction_cur * budget_rate_cad end)         as integration_cost_CAD_CP_ytm,
            sum( case when is_integrated_flag = false then orders_cost_transaction_cur * budget_rate_cad end)                        as orders_cost_CAD_CP_ytm,

            sum(case when is_integrated_flag = false then Fees_cost_transaction_cur * budget_rate_mxn end)                          as Fees_cost_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_cost_transaction_cur * budget_rate_mxn end)                       as Rebates_cost_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then warranties_cost_transaction_cur * budget_rate_mxn end)                    as warranties_cost_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_transaction_cur * budget_rate_mxn end)         as returns_on_warranties_cost_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then returns_cost_transaction_cur * budget_rate_mxn end)                       as returns_cost_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_cost_transaction_cur * budget_rate_mxn end)                 as noncommercial_cost_MXN_CP_ytm,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_amount_transaction_cur * budget_rate_mxn end)         as integration_cost_MXN_CP_ytm,
            sum( case when is_integrated_flag = false then orders_cost_transaction_cur * budget_rate_mxn end)                        as orders_cost_MXN_CP_ytm,

            sum(case when is_integrated_flag = false then Fees_cost_transaction_cur * budget_rate_brl end)                          as Fees_cost_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_cost_transaction_cur * budget_rate_brl end)                       as Rebates_cost_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then warranties_cost_transaction_cur * budget_rate_brl end)                    as warranties_cost_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_transaction_cur * budget_rate_brl end)         as returns_on_warranties_cost_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then returns_cost_transaction_cur * budget_rate_brl end)                       as returns_cost_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_cost_transaction_cur * budget_rate_brl end)                 as noncommercial_cost_BRL_CP_ytm,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_amount_transaction_cur * budget_rate_brl end)         as integration_cost_BRL_CP_ytm,
            sum( case when is_integrated_flag = false then orders_cost_transaction_cur * budget_rate_brl end)                        as orders_cost_BRL_CP_ytm,
            
            sum( case when is_integrated_flag = false then orders_cost_transaction_cur end)                                          as orders_cost_transaction_currency_CP_ytm,

          --- Cost (group landed)
            sum(case when is_integrated_flag = false then Fees_cost_landed_transaction_cur * budget_rate_eur end)                   as Fees_cost_landed_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_cost_landed_transaction_cur * budget_rate_eur end)                as Rebates_cost_landed_EUR_CP_ytm,         
            sum(case when is_integrated_flag = false then warranties_cost_landed_transaction_cur * budget_rate_eur end)             as warranties_cost_landed_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_landed_transaction_cur * budget_rate_eur end)  as returns_on_warranties_cost_landed_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then returns_cost_landed_transaction_cur * budget_rate_eur end)                as returns_cost_landed_EUR_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_cost_landed_transaction_cur * budget_rate_eur end)          as noncommercial_cost_landed_EUR_CP_ytm,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_landed_amount_transaction_cur * budget_rate_eur end)  as integration_cost_landed_EUR_CP_ytm, 
            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur * budget_rate_eur end)                 as orders_cost_landed_EUR_CP_ytm,        

            sum(case when is_integrated_flag = false then Fees_cost_landed_transaction_cur * budget_rate_usd end)                   as Fees_cost_landed_USD_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_cost_landed_transaction_cur * budget_rate_usd end)                as Rebates_cost_landed_USD_CP_ytm,         
            sum(case when is_integrated_flag = false then warranties_cost_landed_transaction_cur * budget_rate_usd end)             as warranties_cost_landed_USD_CP_ytm,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_landed_transaction_cur * budget_rate_usd end)  as returns_on_warranties_cost_landed_USD_CP_ytm,
            sum(case when is_integrated_flag = false then returns_cost_landed_transaction_cur * budget_rate_usd end)                as returns_cost_landed_USD_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_cost_landed_transaction_cur * budget_rate_usd end)          as noncommercial_cost_landed_USD_CP_ytm,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_landed_amount_transaction_cur * budget_rate_usd end)  as integration_cost_landed_USD_CP_ytm, 
            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur * budget_rate_usd end)                 as orders_cost_landed_USD_CP_ytm,        

            sum(case when is_integrated_flag = false then Fees_cost_landed_transaction_cur * budget_rate_cad end)                   as Fees_cost_landed_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_cost_landed_transaction_cur * budget_rate_cad end)                as Rebates_cost_landed_CAD_CP_ytm,         
            sum(case when is_integrated_flag = false then warranties_cost_landed_transaction_cur * budget_rate_cad end)             as warranties_cost_landed_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_landed_transaction_cur * budget_rate_cad end)  as returns_on_warranties_cost_landed_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then returns_cost_landed_transaction_cur * budget_rate_cad end)                as returns_cost_landed_CAD_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_cost_landed_transaction_cur * budget_rate_cad end)          as noncommercial_cost_landed_CAD_CP_ytm,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_landed_amount_transaction_cur * budget_rate_cad end)  as integration_cost_landed_CAD_CP_ytm, 
            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur * budget_rate_cad end)                 as orders_cost_landed_CAD_CP_ytm,        

            sum(case when is_integrated_flag = false then Fees_cost_landed_transaction_cur * budget_rate_mxn end)                   as Fees_cost_landed_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_cost_landed_transaction_cur * budget_rate_mxn end)                as Rebates_cost_landed_MXN_CP_ytm,         
            sum(case when is_integrated_flag = false then warranties_cost_landed_transaction_cur * budget_rate_mxn end)             as warranties_cost_landed_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_landed_transaction_cur * budget_rate_mxn end)  as returns_on_warranties_cost_landed_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then returns_cost_landed_transaction_cur * budget_rate_mxn end)                as returns_cost_landed_MXN_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_cost_landed_transaction_cur * budget_rate_mxn end)          as noncommercial_cost_landed_MXN_CP_ytm,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_landed_amount_transaction_cur * budget_rate_mxn end)  as integration_cost_landed_MXN_CP_ytm, 
            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur * budget_rate_mxn end)                 as orders_cost_landed_MXN_CP_ytm,        

            sum(case when is_integrated_flag = false then Fees_cost_landed_transaction_cur * budget_rate_brl end)                   as Fees_cost_landed_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then Rebates_cost_landed_transaction_cur * budget_rate_brl end)                as Rebates_cost_landed_BRL_CP_ytm,         
            sum(case when is_integrated_flag = false then warranties_cost_landed_transaction_cur * budget_rate_brl end)             as warranties_cost_landed_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then returns_on_warranties_cost_landed_transaction_cur * budget_rate_brl end)  as returns_on_warranties_cost_landed_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then returns_cost_landed_transaction_cur * budget_rate_brl end)                as returns_cost_landed_BRL_CP_ytm,
            sum(case when is_integrated_flag = false then Noncommercial_cost_landed_transaction_cur * budget_rate_brl end)          as noncommercial_cost_landed_BRL_CP_ytm,
            sum(case when is_integrated_flag = true then Avg_unit_price_group_landed_amount_transaction_cur * budget_rate_brl end)  as integration_cost_landed_BRL_CP_ytm, 
            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur * budget_rate_brl end)                 as orders_cost_landed_BRL_CP_ytm,        

            sum(case when is_integrated_flag = false then orders_cost_landed_transaction_cur end)                                   as orders_cost_landed_transaction_currency_CP_ytm,
          
          --- QTY
            sum(case when is_integrated_flag = false then ifnull(orders_quantity,0) end )                                           as orders_quantity_CP_ytm,

      from   {{ref('int_profit_analysis_budget_growth_decomposition')}} s1

      LEFT JOIN (          SELECT
            budget_month,
            currency_from,
            min(case when currency_to = 'EUR' then budget_exchange_rate else null end) as budget_rate_eur,
            min(case when currency_to = 'USD' then budget_exchange_rate else null end) as budget_rate_usd,
            min(case when currency_to = 'CAD' then budget_exchange_rate else null end) as budget_rate_cad,
            min(case when currency_to = 'MXN' then budget_exchange_rate else null end) as budget_rate_mxn,
            min(case when currency_to = 'BRL' then budget_exchange_rate else null end) as budget_rate_brl,
          FROM
            {{ref('stg_financial_sales_budget_exchangerates')}}
          WHERE
            currency_to IN ('EUR', 'USD', 'CAD', 'MXN', 'BRL')
            and budget_year = 2026         # Only get 2026 values, so we can apply 2026 rates to 2025 as well
          GROUP BY
            budget_month,
            currency_from) br 
          ON 
              currency_transaction = br.currency_from
              AND extract(month from sales_invoice_date) = extract(month from br.budget_month)

        where
        extract(YEAR from sales_invoice_date) in (2025,2026)
        --and source_system_new = 'Link'
        group by all

)

-- Get all the permutations / default structure (Called _part2)

, step1_measures_on_SKU_level_ytm_CP_part2 as (
        select distinct

          dim.*,
          s1.* except  (SKU_no,equipment_market,equipment_sub_market,equipment_id_code,
          Statistic_country,
          Statistic_country_iso,
          brm_grouping,
          brm_grouping_sales_team,
          Currency_transaction,
          product_category, 
          product_subcategory, 
          product_class,
          product_type,
          TVH_no_Brand_code,
          TVH_no_Brand_descr,
          product_growth_classification_macro_region,
          unit,
          period)

        from dimensions dim
        left outer join step1_measures_on_SKU_level_ytm_CP s1 -- change name of source to right step 1 
          on ifnull(dim.SKU_no, "") = ifnull(s1.SKU_no,"")
          and ifnull(dim.equipment_market,"") = ifnull(s1.equipment_market,"")
          and ifnull(dim.equipment_sub_market,"") = ifnull(s1.equipment_sub_market,"")
          and dim.equipment_id_code= s1.equipment_id_code
          and ifnull(dim.Statistic_country,"") = ifnull(s1.Statistic_country,"")
          and ifnull(dim.Statistic_country_iso,"") = ifnull(s1.Statistic_country_iso,"")
          and ifnull(dim.brm_grouping,"") = ifnull(s1.brm_grouping,"")
          and ifnull(dim.brm_grouping_sales_team,"") = ifnull(s1.brm_grouping_sales_team,"")
          and ifnull(dim.Currency_transaction,"") = ifnull(s1.Currency_transaction,"")
          and ifnull(dim.product_category,"") = ifnull(s1.product_category,"")
          and ifnull(dim.product_subcategory,"") = ifnull(s1.product_subcategory,"")
          and ifnull(dim.product_class,"") = ifnull(s1.product_class,"")
          and ifnull(dim.product_type,"") = ifnull(s1.product_type,"")
          and ifnull(dim.product_growth_classification_macro_region,"") = ifnull(s1.product_growth_classification_macro_region,"")
          and ifnull(dim.TVH_no_Brand_code,"") = ifnull(s1.TVH_no_Brand_code,"")
          and ifnull(dim.TVH_no_Brand_descr,"") = ifnull(s1.TVH_no_Brand_descr,"")
          and ifnull(dim.unit,"") = ifnull(s1.unit,"")
          and dim.period = s1.period
)

  -- STEP 2: Add ytm values

, step2_measures_on_SKU_level_ytm_CP as (

      select *,

            --- Sales - Add YTM variables
            sum(sales_amount_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as sales_amount_EUR_CP,

            sum(sales_amount_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as sales_amount_USD_CP,

            sum(sales_amount_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as sales_amount_CAD_CP,

            sum(sales_amount_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as sales_amount_MXN_CP,

            sum(sales_amount_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as sales_amount_BRL_CP,

            sum(sales_amount_transaction_cur_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as sales_amount_transaction_cur_CP,

            sum(Fees_sales_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_sales_EUR_CP,

            sum(Fees_sales_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_sales_USD_CP,

            sum(Fees_sales_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_sales_CAD_CP,

            sum(Fees_sales_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_sales_MXN_CP,

            sum(Fees_sales_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_sales_BRL_CP,

            sum(Rebates_sales_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_sales_EUR_CP,

            sum(Rebates_sales_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_sales_USD_CP,

            sum(Rebates_sales_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_sales_CAD_CP,

            sum(Rebates_sales_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_sales_MXN_CP,

            sum(Rebates_sales_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_sales_BRL_CP,

            sum(warranties_sales_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_sales_EUR_CP,

            sum(warranties_sales_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_sales_USD_CP,

            sum(warranties_sales_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_sales_CAD_CP,

            sum(warranties_sales_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_sales_MXN_CP,

            sum(warranties_sales_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_sales_BRL_CP,

            sum(returns_on_warranties_sales_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_sales_EUR_CP,

            sum(returns_on_warranties_sales_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_sales_USD_CP,

            sum(returns_on_warranties_sales_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_sales_CAD_CP,

            sum(returns_on_warranties_sales_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_sales_MXN_CP,

            sum(returns_on_warranties_sales_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_sales_BRL_CP,

            sum(returns_sales_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_sales_EUR_CP,

            sum(returns_sales_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_sales_USD_CP,

            sum(returns_sales_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_sales_CAD_CP,

            sum(returns_sales_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_sales_MXN_CP,

            sum(returns_sales_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_sales_BRL_CP,

            sum(noncommercial_sales_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_sales_EUR_CP,

            sum(noncommercial_sales_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_sales_USD_CP,

            sum(noncommercial_sales_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_sales_CAD_CP,

            sum(noncommercial_sales_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_sales_MXN_CP,

            sum(noncommercial_sales_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_sales_BRL_CP,

            sum(integration_sales_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_sales_EUR_CP, 

            sum(integration_sales_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_sales_USD_CP, 

            sum(integration_sales_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_sales_CAD_CP, 

            sum(integration_sales_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_sales_MXN_CP, 

            sum(integration_sales_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_sales_BRL_CP,

            sum(orders_sales_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_sales_EUR_CP,

            sum(orders_sales_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_sales_USD_CP,

            sum(orders_sales_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_sales_CAD_CP,

            sum(orders_sales_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_sales_MXN_CP,

            sum(orders_sales_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_sales_BRL_CP,

            sum(orders_sales_transaction_currency_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_sales_transaction_currency_CP,

            --- Cost (group) - Add YTM variables
            sum(Fees_cost_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_cost_EUR_CP,

            sum(Rebates_cost_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_cost_EUR_CP,

            sum(warranties_cost_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_cost_EUR_CP,

            sum(returns_on_warranties_cost_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_cost_EUR_CP,

            sum(returns_cost_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_cost_EUR_CP,

            sum(noncommercial_cost_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_cost_EUR_CP,

            sum(integration_cost_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_cost_EUR_CP,                      

            sum(orders_cost_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_EUR_CP,

            sum(Fees_cost_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_cost_USD_CP,

            sum(Rebates_cost_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_cost_USD_CP,

            sum(warranties_cost_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_cost_USD_CP,

            sum(returns_on_warranties_cost_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_cost_USD_CP,

            sum(returns_cost_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_cost_USD_CP,

            sum(noncommercial_cost_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_cost_USD_CP,

            sum(integration_cost_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_cost_USD_CP,                      

            sum(orders_cost_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_USD_CP,

            sum(Fees_cost_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_cost_CAD_CP,

            sum(Rebates_cost_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_cost_CAD_CP,

            sum(warranties_cost_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_cost_CAD_CP,

            sum(returns_on_warranties_cost_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_cost_CAD_CP,

            sum(returns_cost_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_cost_CAD_CP,

            sum(noncommercial_cost_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_cost_CAD_CP,

            sum(integration_cost_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_cost_CAD_CP,                      

            sum(orders_cost_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_CAD_CP,

            sum(Fees_cost_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_cost_MXN_CP,

            sum(Rebates_cost_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_cost_MXN_CP,

            sum(warranties_cost_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_cost_MXN_CP,

            sum(returns_on_warranties_cost_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_cost_MXN_CP,

            sum(returns_cost_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_cost_MXN_CP,

            sum(noncommercial_cost_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_cost_MXN_CP,

            sum(integration_cost_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_cost_MXN_CP,                      

            sum(orders_cost_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_MXN_CP,

            sum(Fees_cost_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_cost_BRL_CP,

            sum(Rebates_cost_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_cost_BRL_CP,

            sum(warranties_cost_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_cost_BRL_CP,

            sum(returns_on_warranties_cost_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_cost_BRL_CP,

            sum(returns_cost_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_cost_BRL_CP,

            sum(noncommercial_cost_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_cost_BRL_CP,

            sum(integration_cost_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_cost_BRL_CP,                      

            sum(orders_cost_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_BRL_CP,

            sum(orders_cost_transaction_currency_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_transaction_currency_CP,

            --- Cost (group landed) - Add YTM variables
            sum(Fees_cost_landed_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_cost_landed_EUR_CP,

            sum(Rebates_cost_landed_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_cost_landed_EUR_CP,

            sum(warranties_cost_landed_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_cost_landed_EUR_CP,

            sum(returns_on_warranties_cost_landed_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_cost_landed_EUR_CP,

            sum(returns_cost_landed_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_cost_landed_EUR_CP,

            sum(noncommercial_cost_landed_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_cost_landed_EUR_CP,

            sum(integration_cost_landed_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_cost_landed_EUR_CP,                       

            sum(orders_cost_landed_EUR_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_landed_EUR_CP,

            sum(Fees_cost_landed_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_cost_landed_USD_CP,

            sum(Rebates_cost_landed_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_cost_landed_USD_CP,

            sum(warranties_cost_landed_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_cost_landed_USD_CP,

            sum(returns_on_warranties_cost_landed_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_cost_landed_USD_CP,

            sum(returns_cost_landed_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_cost_landed_USD_CP,

            sum(noncommercial_cost_landed_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_cost_landed_USD_CP,

            sum(integration_cost_landed_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_cost_landed_USD_CP,                       

            sum(orders_cost_landed_USD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_landed_USD_CP,

            sum(Fees_cost_landed_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_cost_landed_CAD_CP,

            sum(Rebates_cost_landed_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_cost_landed_CAD_CP,

            sum(warranties_cost_landed_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_cost_landed_CAD_CP,

            sum(returns_on_warranties_cost_landed_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_cost_landed_CAD_CP,

            sum(returns_cost_landed_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_cost_landed_CAD_CP,

            sum(noncommercial_cost_landed_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_cost_landed_CAD_CP,

            sum(integration_cost_landed_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_cost_landed_CAD_CP,                       

            sum(orders_cost_landed_CAD_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_landed_CAD_CP,

            sum(Fees_cost_landed_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_cost_landed_MXN_CP,

            sum(Rebates_cost_landed_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_cost_landed_MXN_CP,

            sum(warranties_cost_landed_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_cost_landed_MXN_CP,

            sum(returns_on_warranties_cost_landed_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_cost_landed_MXN_CP,

            sum(returns_cost_landed_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_cost_landed_MXN_CP,

            sum(noncommercial_cost_landed_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_cost_landed_MXN_CP,

            sum(integration_cost_landed_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_cost_landed_MXN_CP,                       

            sum(orders_cost_landed_MXN_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_landed_MXN_CP,

            sum(Fees_cost_landed_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Fees_cost_landed_BRL_CP,

            sum(Rebates_cost_landed_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as Rebates_cost_landed_BRL_CP,

            sum(warranties_cost_landed_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as warranties_cost_landed_BRL_CP,

            sum(returns_on_warranties_cost_landed_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_on_warranties_cost_landed_BRL_CP,

            sum(returns_cost_landed_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as returns_cost_landed_BRL_CP,

            sum(noncommercial_cost_landed_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as noncommercial_cost_landed_BRL_CP,

            sum(integration_cost_landed_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as integration_cost_landed_BRL_CP,                       

            sum(orders_cost_landed_BRL_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_landed_BRL_CP,

            sum(orders_cost_landed_transaction_currency_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_cost_landed_transaction_currency_CP,                       

            sum(orders_quantity_CP_ytm) over 
            (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit, date_trunc(Period, YEAR) 
            order by Period) as orders_quantity_CP

      from step1_measures_on_SKU_level_ytm_CP_part2 --changed to step 1 part 2

    )

  -- STEP 3: Add lagged values
, step3_measures_on_SKU_level_ytm_PP as (

      select *,
            --- Add lag variables

            --- Sales
            lag(sales_amount_transaction_cur_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_category, product_subcategory, product_growth_classification_macro_region, 
              brm_grouping, brm_grouping_sales_team , unit
              order by period) as sales_amount_transaction_cur_PP,

            lag(sales_amount_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as sales_amount_EUR_PP,

            lag(Fees_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_sales_EUR_PP,

            lag(Rebates_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_sales_EUR_PP,

            lag(warranties_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_sales_EUR_PP,

            lag(returns_on_warranties_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_sales_EUR_PP,

            lag(returns_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_sales_EUR_PP,

            lag(noncommercial_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_sales_EUR_PP,

            lag(integration_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_sales_EUR_PP,                           

            lag(orders_sales_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_EUR_PP,

            lag(sales_amount_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as sales_amount_USD_PP,

            lag(Fees_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_sales_USD_PP,

            lag(Rebates_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_sales_USD_PP,

            lag(warranties_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_sales_USD_PP,

            lag(returns_on_warranties_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_sales_USD_PP,

            lag(returns_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_sales_USD_PP,

            lag(noncommercial_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_sales_USD_PP,

            lag(integration_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_sales_USD_PP,                           

            lag(orders_sales_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_USD_PP,

            lag(sales_amount_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as sales_amount_CAD_PP,

            lag(Fees_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_sales_CAD_PP,

            lag(Rebates_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_sales_CAD_PP,

            lag(warranties_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_sales_CAD_PP,

            lag(returns_on_warranties_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_sales_CAD_PP,

            lag(returns_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_sales_CAD_PP,

            lag(noncommercial_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_sales_CAD_PP,

            lag(integration_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_sales_CAD_PP,                           

            lag(orders_sales_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_CAD_PP,

            lag(sales_amount_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as sales_amount_MXN_PP,

            lag(Fees_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_sales_MXN_PP,

            lag(Rebates_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_sales_MXN_PP,

            lag(warranties_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_sales_MXN_PP,

            lag(returns_on_warranties_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_sales_MXN_PP,

            lag(returns_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_sales_MXN_PP,

            lag(noncommercial_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_sales_MXN_PP,

            lag(integration_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_sales_MXN_PP,                           

            lag(orders_sales_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_MXN_PP,

            lag(sales_amount_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as sales_amount_BRL_PP,

            lag(Fees_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_sales_BRL_PP,

            lag(Rebates_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_sales_BRL_PP,

            lag(warranties_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_sales_BRL_PP,

            lag(returns_on_warranties_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_sales_BRL_PP,

            lag(returns_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_sales_BRL_PP,

            lag(noncommercial_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_sales_BRL_PP,

            lag(integration_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_sales_BRL_PP,                           

            lag(orders_sales_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_BRL_PP,


            lag(orders_sales_transaction_currency_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_sales_transaction_currency_PP,

            --- Cost (group)
            lag(Fees_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_EUR_PP,

            lag(Rebates_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_EUR_PP,

            lag(warranties_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_EUR_PP,

            lag(returns_on_warranties_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_EUR_PP,

            lag(returns_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_EUR_PP,

            lag(noncommercial_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_EUR_PP,

            lag(integration_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_EUR_PP,                            

            lag(orders_cost_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_EUR_PP,

            lag(Fees_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_USD_PP,

            lag(Rebates_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_USD_PP,

            lag(warranties_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_USD_PP,

            lag(returns_on_warranties_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_USD_PP,

            lag(returns_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_USD_PP,

            lag(noncommercial_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_USD_PP,

            lag(integration_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_USD_PP,                            

            lag(orders_cost_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_USD_PP,

            lag(Fees_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_CAD_PP,

            lag(Rebates_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_CAD_PP,

            lag(warranties_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_CAD_PP,

            lag(returns_on_warranties_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_CAD_PP,

            lag(returns_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_CAD_PP,

            lag(noncommercial_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_CAD_PP,

            lag(integration_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_CAD_PP,                            

            lag(orders_cost_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_CAD_PP,

              lag(Fees_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_MXN_PP,

            lag(Rebates_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_MXN_PP,

            lag(warranties_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_MXN_PP,

            lag(returns_on_warranties_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_MXN_PP,

            lag(returns_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_MXN_PP,

            lag(noncommercial_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_MXN_PP,

            lag(integration_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_MXN_PP,                            

            lag(orders_cost_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_MXN_PP,

            lag(Fees_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_BRL_PP,

            lag(Rebates_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_BRL_PP,

            lag(warranties_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_BRL_PP,

            lag(returns_on_warranties_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_BRL_PP,

            lag(returns_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_BRL_PP,

            lag(noncommercial_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_BRL_PP,

            lag(integration_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_BRL_PP,                            

            lag(orders_cost_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_BRL_PP,

            lag(orders_cost_transaction_currency_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_transaction_currency_PP,

            --- Cost (group landed)
            lag(Fees_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_landed_EUR_PP,

            lag(Rebates_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_landed_EUR_PP,

            lag(warranties_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_landed_EUR_PP,

            lag(returns_on_warranties_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_landed_EUR_PP,

            lag(returns_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_landed_EUR_PP,

            lag(noncommercial_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_landed_EUR_PP,

            lag(integration_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_landed_EUR_PP,                          

            lag(orders_cost_landed_EUR_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_EUR_PP,

            lag(Fees_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_landed_USD_PP,

            lag(Rebates_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_landed_USD_PP,

            lag(warranties_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_landed_USD_PP,

            lag(returns_on_warranties_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_landed_USD_PP,

            lag(returns_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_landed_USD_PP,

            lag(noncommercial_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_landed_USD_PP,

            lag(integration_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_landed_USD_PP,                          

            lag(orders_cost_landed_USD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_USD_PP,

            lag(Fees_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_landed_CAD_PP,

            lag(Rebates_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_landed_CAD_PP,

            lag(warranties_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_landed_CAD_PP,

            lag(returns_on_warranties_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_landed_CAD_PP,

            lag(returns_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_landed_CAD_PP,

            lag(noncommercial_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_landed_CAD_PP,

            lag(integration_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_landed_CAD_PP,                          

            lag(orders_cost_landed_CAD_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_CAD_PP,

            lag(Fees_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_landed_MXN_PP,

            lag(Rebates_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_landed_MXN_PP,

            lag(warranties_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_landed_MXN_PP,

            lag(returns_on_warranties_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_landed_MXN_PP,

            lag(returns_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_landed_MXN_PP,

            lag(noncommercial_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_landed_MXN_PP,

            lag(integration_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_landed_MXN_PP,                          

            lag(orders_cost_landed_MXN_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_MXN_PP,

            lag(Fees_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Fees_cost_landed_BRL_PP,

            lag(Rebates_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as Rebates_cost_landed_BRL_PP,

            lag(warranties_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as warranties_cost_landed_BRL_PP,

            lag(returns_on_warranties_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_on_warranties_cost_landed_BRL_PP,

            lag(returns_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as returns_cost_landed_BRL_PP,

            lag(noncommercial_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as noncommercial_cost_landed_BRL_PP,

            lag(integration_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as integration_cost_landed_BRL_PP,                          

            lag(orders_cost_landed_BRL_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_BRL_PP,

            lag(orders_cost_landed_transaction_currency_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_cost_landed_transaction_currency_PP,              

            lag(orders_quantity_CP, 12) over 
              (partition by SKU_no,equipment_market, equipment_sub_market,equipment_id_code,Statistic_country,Statistic_country_iso,Currency_transaction,
              product_class, product_type, product_category, product_subcategory, product_growth_classification_macro_region,TVH_no_Brand_code,TVH_no_Brand_descr, 
              brm_grouping, brm_grouping_sales_team, unit
              order by period) as orders_quantity_PP,

      from step2_measures_on_SKU_level_ytm_CP --changed to step 1 part 2

)


    -- STEP 4.1: Further calculations

, step4_calculations_on_sku_level_ytm_CP as (

      select *,
          --- Calculate recurring, new and lost
          case    when ifnull(orders_quantity_CP,0) > 0  and ifnull(orders_quantity_PP,0) = 0 then 'NEW'
                  when ifnull(orders_quantity_CP,0) = 0  and ifnull(orders_quantity_PP,0) > 0 then 'LOST'
                  when ifnull(orders_quantity_CP,0) > 0  and ifnull(orders_quantity_PP,0) > 0 then 'RECURRING' 
          end as evolution_type,

          --- Calculate average price per unit - needed to calculate sales price effect
          ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0) as average_price_per_unit_transaction_currency_CP,
          ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0) as average_price_per_unit_transaction_currency_PP,

          ifnull(safe_divide(orders_sales_EUR_CP , orders_quantity_CP),0) as average_price_per_unit_EUR_CP,
          ifnull(safe_divide(orders_sales_EUR_PP , orders_quantity_PP),0) as average_price_per_unit_EUR_PP,

          ifnull(safe_divide(orders_sales_USD_CP , orders_quantity_CP),0) as average_price_per_unit_USD_CP,
          ifnull(safe_divide(orders_sales_USD_PP , orders_quantity_PP),0) as average_price_per_unit_USD_PP,

          ifnull(safe_divide(orders_sales_CAD_CP , orders_quantity_CP),0) as average_price_per_unit_CAD_CP,
          ifnull(safe_divide(orders_sales_CAD_PP , orders_quantity_PP),0) as average_price_per_unit_CAD_PP,

          ifnull(safe_divide(orders_sales_MXN_CP , orders_quantity_CP),0) as average_price_per_unit_MXN_CP,
          ifnull(safe_divide(orders_sales_MXN_PP , orders_quantity_PP),0) as average_price_per_unit_MXN_PP,

          ifnull(safe_divide(orders_sales_BRL_CP , orders_quantity_CP),0) as average_price_per_unit_BRL_CP,
          ifnull(safe_divide(orders_sales_BRL_PP , orders_quantity_PP),0) as average_price_per_unit_BRL_PP,

          --- Calculate average cost per unit - needed to calculate sales price effect
          ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0) as average_cost_per_unit_transaction_currency_CP,
          ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0) as average_cost_per_unit_transaction_currency_PP,

          ifnull(safe_divide(orders_cost_EUR_CP , orders_quantity_CP),0) as average_cost_per_unit_EUR_CP,
          ifnull(safe_divide(orders_cost_EUR_PP , orders_quantity_PP),0) as average_cost_per_unit_EUR_PP,

          ifnull(safe_divide(orders_cost_USD_CP , orders_quantity_CP),0) as average_cost_per_unit_USD_CP,
          ifnull(safe_divide(orders_cost_USD_PP , orders_quantity_PP),0) as average_cost_per_unit_USD_PP,

          ifnull(safe_divide(orders_cost_CAD_CP , orders_quantity_CP),0) as average_cost_per_unit_CAD_CP,
          ifnull(safe_divide(orders_cost_CAD_PP , orders_quantity_PP),0) as average_cost_per_unit_CAD_PP,

          ifnull(safe_divide(orders_cost_MXN_CP , orders_quantity_CP),0) as average_cost_per_unit_MXN_CP,
          ifnull(safe_divide(orders_cost_MXN_PP , orders_quantity_PP),0) as average_cost_per_unit_MXN_PP,

          ifnull(safe_divide(orders_cost_BRL_CP , orders_quantity_CP),0) as average_cost_per_unit_BRL_CP,
          ifnull(safe_divide(orders_cost_BRL_PP , orders_quantity_PP),0) as average_cost_per_unit_BRL_PP,

          --- Calculate average cost landed per unit - needed to calculate sales price effect
          ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_transaction_currency_CP,
          ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_transaction_currency_PP,

          ifnull(safe_divide(orders_cost_landed_EUR_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_EUR_CP,
          ifnull(safe_divide(orders_cost_landed_EUR_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_EUR_PP,                            

          ifnull(safe_divide(orders_cost_landed_USD_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_USD_CP,
          ifnull(safe_divide(orders_cost_landed_USD_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_USD_PP,

          ifnull(safe_divide(orders_cost_landed_CAD_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_CAD_CP,
          ifnull(safe_divide(orders_cost_landed_CAD_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_CAD_PP,

          ifnull(safe_divide(orders_cost_landed_MXN_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_MXN_CP,
          ifnull(safe_divide(orders_cost_landed_MXN_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_MXN_PP,

          ifnull(safe_divide(orders_cost_landed_BRL_CP , orders_quantity_CP),0) as average_cost_landed_per_unit_BRL_CP,
          ifnull(safe_divide(orders_cost_landed_BRL_PP , orders_quantity_PP),0) as average_cost_landed_per_unit_BRL_PP,

          --- Calculate price per unit CP for fx rate PP (needed to calculate Fx effect)
          case    when round(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_sales_EUR_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_sales_EUR_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_sales_EUR_PP , orders_quantity_PP),0))))) 
                          end as average_price_per_unit_EUR_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_sales_USD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_sales_USD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_sales_USD_PP , orders_quantity_PP),0))))) 
                          end as average_price_per_unit_USD_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_sales_CAD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_sales_CAD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_sales_CAD_PP , orders_quantity_PP),0))))) 
                          end as average_price_per_unit_CAD_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_sales_MXN_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_sales_MXN_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_sales_MXN_PP , orders_quantity_PP),0))))) 
                          end as average_price_per_unit_MXN_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_sales_BRL_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_sales_BRL_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_sales_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_sales_BRL_PP , orders_quantity_PP),0))))) 
                          end as average_price_per_unit_BRL_CP_with_fx_rate_PP,

          --- Calculate cost per unit CP for fx rate PP (needed to calculate Fx effect)
          case    when round(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_EUR_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_EUR_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_EUR_PP , orders_quantity_PP),0))))) 
                          end as average_cost_per_unit_EUR_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_USD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_USD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_USD_PP , orders_quantity_PP),0))))) 
                          end as average_cost_per_unit_USD_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_CAD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_CAD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_CAD_PP , orders_quantity_PP),0))))) 
                          end as average_cost_per_unit_CAD_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_MXN_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_MXN_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_MXN_PP , orders_quantity_PP),0))))) 
                          end as average_cost_per_unit_MXN_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_BRL_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_BRL_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_BRL_PP , orders_quantity_PP),0))))) 
                          end as average_cost_per_unit_BRL_CP_with_fx_rate_PP,

          --- Calculate cost landed per unit CP for fx rate PP (needed to calculate Fx effect)
          case    when round(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_landed_EUR_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_landed_EUR_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_landed_EUR_PP , orders_quantity_PP),0))))) 
                          end as average_cost_landed_per_unit_EUR_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_landed_USD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_landed_USD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_landed_USD_PP , orders_quantity_PP),0))))) 
                          end as average_cost_landed_per_unit_USD_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_landed_CAD_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_landed_CAD_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_landed_CAD_PP , orders_quantity_PP),0))))) 
                          end as average_cost_landed_per_unit_CAD_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_landed_MXN_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_landed_MXN_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_landed_MXN_PP , orders_quantity_PP),0))))) 
                          end as average_cost_landed_per_unit_MXN_CP_with_fx_rate_PP,

          case    when round(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),3) = 0.000 
                       or round(ifnull(safe_divide(orders_cost_landed_BRL_PP , orders_quantity_PP),0),3) = 0.000
                  then ifnull(safe_divide(orders_cost_landed_BRL_CP , orders_quantity_CP),0)
                  else    (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_CP , orders_quantity_CP),0),
                          (safe_divide(ifnull(safe_divide(orders_cost_landed_transaction_currency_PP , orders_quantity_PP),0),
                          ifnull(safe_divide(orders_cost_landed_BRL_PP , orders_quantity_PP),0))))) 
                          end as average_cost_landed_per_unit_BRL_CP_with_fx_rate_PP,

      from step3_measures_on_SKU_level_ytm_PP

    ),

    -- STEP 4.2: Further aggregations on the right level

step5_further_calculations_on_sku_level_and_aggregation_ytm_CP as (

   select 
          --- Calculation level
            SKU_no,

            equipment_market,
            equipment_sub_market,
            equipment_id_code,

            Statistic_country,
            Statistic_country_iso,

            brm_grouping,
            brm_grouping_sales_team,

            Currency_transaction,

            product_category, 
            product_subcategory, 
            product_class,
            product_type,
            product_growth_classification_macro_region,

            unit,

            TVH_no_Brand_code,
            TVH_no_Brand_descr,

            period, 
            Evolution_type,

      --- Sales
            sum(Fees_sales_EUR_PP) as Fees_sales_EUR_PP,
            sum(Rebates_sales_EUR_PP) as Rebates_sales_EUR_PP,
            sum(warranties_sales_EUR_PP) as warranties_sales_EUR_PP,
            sum(returns_on_warranties_sales_EUR_PP) as returns_on_warranties_sales_EUR_PP,
            sum(returns_sales_EUR_PP) as returns_sales_EUR_PP,
            sum(noncommercial_sales_EUR_PP) as noncommercial_sales_EUR_PP,
            sum(integration_sales_EUR_PP) as integration_sales_EUR_PP,            
            sum(ifnull(orders_sales_EUR_PP,0)) as orders_sales_EUR_PP,
            sum(orders_sales_EUR_CP) as orders_sales_EUR_CP,
            sum(sales_amount_EUR_CP) as sales_amount_EUR_CP,
            sum(sales_amount_EUR_PP) as sales_amount_EUR_PP,

            sum(Fees_sales_USD_PP) as Fees_sales_USD_PP,
            sum(Rebates_sales_USD_PP) as Rebates_sales_USD_PP,
            sum(warranties_sales_USD_PP) as warranties_sales_USD_PP,
            sum(returns_on_warranties_sales_USD_PP) as returns_on_warranties_sales_USD_PP,
            sum(returns_sales_USD_PP) as returns_sales_USD_PP,
            sum(noncommercial_sales_USD_PP) as noncommercial_sales_USD_PP,
            sum(integration_sales_USD_PP) as integration_sales_USD_PP,            
            sum(ifnull(orders_sales_USD_PP,0)) as orders_sales_USD_PP,
            sum(orders_sales_USD_CP) as orders_sales_USD_CP,
            sum(sales_amount_USD_CP) as sales_amount_USD_CP,
            sum(sales_amount_USD_PP) as sales_amount_USD_PP,

            sum(Fees_sales_CAD_PP) as Fees_sales_CAD_PP,
            sum(Rebates_sales_CAD_PP) as Rebates_sales_CAD_PP,
            sum(warranties_sales_CAD_PP) as warranties_sales_CAD_PP,
            sum(returns_on_warranties_sales_CAD_PP) as returns_on_warranties_sales_CAD_PP,
            sum(returns_sales_CAD_PP) as returns_sales_CAD_PP,
            sum(noncommercial_sales_CAD_PP) as noncommercial_sales_CAD_PP,
            sum(integration_sales_CAD_PP) as integration_sales_CAD_PP,            
            sum(ifnull(orders_sales_CAD_PP,0)) as orders_sales_CAD_PP,
            sum(orders_sales_CAD_CP) as orders_sales_CAD_CP,
            sum(sales_amount_CAD_CP) as sales_amount_CAD_CP,
            sum(sales_amount_CAD_PP) as sales_amount_CAD_PP,

            sum(Fees_sales_MXN_PP) as Fees_sales_MXN_PP,
            sum(Rebates_sales_MXN_PP) as Rebates_sales_MXN_PP,
            sum(warranties_sales_MXN_PP) as warranties_sales_MXN_PP,
            sum(returns_on_warranties_sales_MXN_PP) as returns_on_warranties_sales_MXN_PP,
            sum(returns_sales_MXN_PP) as returns_sales_MXN_PP,
            sum(noncommercial_sales_MXN_PP) as noncommercial_sales_MXN_PP,
            sum(integration_sales_MXN_PP) as integration_sales_MXN_PP,            
            sum(ifnull(orders_sales_MXN_PP,0)) as orders_sales_MXN_PP,
            sum(orders_sales_MXN_CP) as orders_sales_MXN_CP,
            sum(sales_amount_MXN_CP) as sales_amount_MXN_CP,
            sum(sales_amount_MXN_PP) as sales_amount_MXN_PP,

            sum(Fees_sales_BRL_PP) as Fees_sales_BRL_PP,
            sum(Rebates_sales_BRL_PP) as Rebates_sales_BRL_PP,
            sum(warranties_sales_BRL_PP) as warranties_sales_BRL_PP,
            sum(returns_on_warranties_sales_BRL_PP) as returns_on_warranties_sales_BRL_PP,
            sum(returns_sales_BRL_PP) as returns_sales_BRL_PP,
            sum(noncommercial_sales_BRL_PP) as noncommercial_sales_BRL_PP,
            sum(integration_sales_BRL_PP) as integration_sales_BRL_PP,            
            sum(ifnull(orders_sales_BRL_PP,0)) as orders_sales_BRL_PP,
            sum(orders_sales_BRL_CP) as orders_sales_BRL_CP,
            sum(sales_amount_BRL_CP) as sales_amount_BRL_CP,
            sum(sales_amount_BRL_PP) as sales_amount_BRL_PP,


      --- Cost
            sum(Fees_cost_EUR_PP) as Fees_cost_EUR_PP,
            sum(Rebates_cost_EUR_PP) as Rebates_cost_EUR_PP,
            sum(warranties_cost_EUR_PP) as warranties_cost_EUR_PP,
            sum(returns_on_warranties_cost_EUR_PP) as returns_on_warranties_cost_EUR_PP,
            sum(returns_cost_EUR_PP) as returns_cost_EUR_PP,
            sum(noncommercial_cost_EUR_PP) as noncommercial_cost_EUR_PP,
            sum(integration_cost_EUR_PP) as integration_cost_EUR_PP,            
            sum(ifnull(orders_cost_EUR_PP,0)) as orders_cost_EUR_PP,
            sum(orders_cost_EUR_CP) as orders_cost_EUR_CP,            

            sum(Fees_cost_USD_PP) as Fees_cost_USD_PP,
            sum(Rebates_cost_USD_PP) as Rebates_cost_USD_PP,
            sum(warranties_cost_USD_PP) as warranties_cost_USD_PP,
            sum(returns_on_warranties_cost_USD_PP) as returns_on_warranties_cost_USD_PP,
            sum(returns_cost_USD_PP) as returns_cost_USD_PP,
            sum(noncommercial_cost_USD_PP) as noncommercial_cost_USD_PP,
            sum(integration_cost_USD_PP) as integration_cost_USD_PP,            
            sum(ifnull(orders_cost_USD_PP,0)) as orders_cost_USD_PP,
            sum(orders_cost_USD_CP) as orders_cost_USD_CP, 

            sum(Fees_cost_CAD_PP) as Fees_cost_CAD_PP,
            sum(Rebates_cost_CAD_PP) as Rebates_cost_CAD_PP,
            sum(warranties_cost_CAD_PP) as warranties_cost_CAD_PP,
            sum(returns_on_warranties_cost_CAD_PP) as returns_on_warranties_cost_CAD_PP,
            sum(returns_cost_CAD_PP) as returns_cost_CAD_PP,
            sum(noncommercial_cost_CAD_PP) as noncommercial_cost_CAD_PP,
            sum(integration_cost_CAD_PP) as integration_cost_CAD_PP,            
            sum(ifnull(orders_cost_CAD_PP,0)) as orders_cost_CAD_PP,
            sum(orders_cost_CAD_CP) as orders_cost_CAD_CP, 

            sum(Fees_cost_MXN_PP) as Fees_cost_MXN_PP,
            sum(Rebates_cost_MXN_PP) as Rebates_cost_MXN_PP,
            sum(warranties_cost_MXN_PP) as warranties_cost_MXN_PP,
            sum(returns_on_warranties_cost_MXN_PP) as returns_on_warranties_cost_MXN_PP,
            sum(returns_cost_MXN_PP) as returns_cost_MXN_PP,
            sum(noncommercial_cost_MXN_PP) as noncommercial_cost_MXN_PP,
            sum(integration_cost_MXN_PP) as integration_cost_MXN_PP,            
            sum(ifnull(orders_cost_MXN_PP,0)) as orders_cost_MXN_PP,
            sum(orders_cost_MXN_CP) as orders_cost_MXN_CP, 

            sum(Fees_cost_BRL_PP) as Fees_cost_BRL_PP,
            sum(Rebates_cost_BRL_PP) as Rebates_cost_BRL_PP,
            sum(warranties_cost_BRL_PP) as warranties_cost_BRL_PP,
            sum(returns_on_warranties_cost_BRL_PP) as returns_on_warranties_cost_BRL_PP,
            sum(returns_cost_BRL_PP) as returns_cost_BRL_PP,
            sum(noncommercial_cost_BRL_PP) as noncommercial_cost_BRL_PP,
            sum(integration_cost_BRL_PP) as integration_cost_BRL_PP,            
            sum(ifnull(orders_cost_BRL_PP,0)) as orders_cost_BRL_PP,
            sum(orders_cost_BRL_CP) as orders_cost_BRL_CP, 

      --- Cost landed
            sum(Fees_cost_landed_EUR_PP) as Fees_cost_landed_EUR_PP,
            sum(Rebates_cost_landed_EUR_PP) as Rebates_cost_landed_EUR_PP,
            sum(warranties_cost_landed_EUR_PP) as warranties_cost_landed_EUR_PP,
            sum(returns_on_warranties_cost_landed_EUR_PP) as returns_on_warranties_cost_landed_EUR_PP,
            sum(returns_cost_landed_EUR_PP) as returns_cost_landed_EUR_PP,
            sum(noncommercial_cost_landed_EUR_PP) as noncommercial_cost_laneded_EUR_PP,
            sum(integration_cost_landed_EUR_PP) as integration_cost_laneded_EUR_PP,            
            sum(ifnull(orders_cost_landed_EUR_PP,0)) as orders_cost_landed_EUR_PP,
            sum(orders_cost_landed_EUR_CP) as orders_cost_landed_EUR_CP,  

            sum(Fees_cost_landed_USD_PP) as Fees_cost_landed_USD_PP,
            sum(Rebates_cost_landed_USD_PP) as Rebates_cost_landed_USD_PP,
            sum(warranties_cost_landed_USD_PP) as warranties_cost_landed_USD_PP,
            sum(returns_on_warranties_cost_landed_USD_PP) as returns_on_warranties_cost_landed_USD_PP,
            sum(returns_cost_landed_USD_PP) as returns_cost_landed_USD_PP,
            sum(noncommercial_cost_landed_USD_PP) as noncommercial_cost_laneded_USD_PP,
            sum(integration_cost_landed_USD_PP) as integration_cost_laneded_USD_PP,            
            sum(ifnull(orders_cost_landed_USD_PP,0)) as orders_cost_landed_USD_PP,
            sum(orders_cost_landed_USD_CP) as orders_cost_landed_USD_CP,  

            sum(Fees_cost_landed_CAD_PP) as Fees_cost_landed_CAD_PP,
            sum(Rebates_cost_landed_CAD_PP) as Rebates_cost_landed_CAD_PP,
            sum(warranties_cost_landed_CAD_PP) as warranties_cost_landed_CAD_PP,
            sum(returns_on_warranties_cost_landed_CAD_PP) as returns_on_warranties_cost_landed_CAD_PP,
            sum(returns_cost_landed_CAD_PP) as returns_cost_landed_CAD_PP,
            sum(noncommercial_cost_landed_CAD_PP) as noncommercial_cost_laneded_CAD_PP,
            sum(integration_cost_landed_CAD_PP) as integration_cost_laneded_CAD_PP,            
            sum(ifnull(orders_cost_landed_CAD_PP,0)) as orders_cost_landed_CAD_PP,
            sum(orders_cost_landed_CAD_CP) as orders_cost_landed_CAD_CP,  

            sum(Fees_cost_landed_MXN_PP) as Fees_cost_landed_MXN_PP,
            sum(Rebates_cost_landed_MXN_PP) as Rebates_cost_landed_MXN_PP,
            sum(warranties_cost_landed_MXN_PP) as warranties_cost_landed_MXN_PP,
            sum(returns_on_warranties_cost_landed_MXN_PP) as returns_on_warranties_cost_landed_MXN_PP,
            sum(returns_cost_landed_MXN_PP) as returns_cost_landed_MXN_PP,
            sum(noncommercial_cost_landed_MXN_PP) as noncommercial_cost_laneded_MXN_PP,
            sum(integration_cost_landed_MXN_PP) as integration_cost_laneded_MXN_PP,            
            sum(ifnull(orders_cost_landed_MXN_PP,0)) as orders_cost_landed_MXN_PP,
            sum(orders_cost_landed_MXN_CP) as orders_cost_landed_MXN_CP,  

            sum(Fees_cost_landed_BRL_PP) as Fees_cost_landed_BRL_PP,
            sum(Rebates_cost_landed_BRL_PP) as Rebates_cost_landed_BRL_PP,
            sum(warranties_cost_landed_BRL_PP) as warranties_cost_landed_BRL_PP,
            sum(returns_on_warranties_cost_landed_BRL_PP) as returns_on_warranties_cost_landed_BRL_PP,
            sum(returns_cost_landed_BRL_PP) as returns_cost_landed_BRL_PP,
            sum(noncommercial_cost_landed_BRL_PP) as noncommercial_cost_laneded_BRL_PP,
            sum(integration_cost_landed_BRL_PP) as integration_cost_laneded_BRL_PP,            
            sum(ifnull(orders_cost_landed_BRL_PP,0)) as orders_cost_landed_BRL_PP,
            sum(orders_cost_landed_BRL_CP) as orders_cost_landed_BRL_CP,  
              
      --- Calculate delta for excluded categories (fees, reabates, warranties, return on warranties, returns) + total sales growth
            sum(ifnull(Fees_sales_EUR_CP,0)) - sum(ifnull(Fees_sales_EUR_PP,0)) as Fees_sales_EUR_delta,
            sum(ifnull(Rebates_sales_EUR_CP,0)) - sum(ifnull(Rebates_sales_EUR_PP,0)) as Rebates_sales_EUR_delta,
            sum(ifnull(warranties_sales_EUR_CP,0)) - sum(ifnull(warranties_sales_EUR_PP,0)) as warranties_sales_EUR_delta,
            sum(ifnull(returns_on_warranties_sales_EUR_CP,0)) - sum(ifnull(returns_on_warranties_sales_EUR_PP,0)) as returns_on_warranties_sales_EUR_delta,
            sum(ifnull(returns_sales_EUR_CP,0)) - sum(ifnull(returns_sales_EUR_PP,0)) as returns_sales_EUR_delta,
            sum(ifnull(noncommercial_sales_EUR_CP,0)) - sum(ifnull(noncommercial_sales_EUR_PP,0)) as noncommercial_sales_EUR_delta,
            sum(ifnull(integration_sales_EUR_CP,0)) - sum(ifnull(integration_sales_EUR_PP,0)) as integration_sales_EUR_delta,                     
            sum(ifnull(sales_amount_EUR_CP,0)) - sum(ifnull(sales_amount_EUR_PP,0)) as sales_amount_EUR_delta,    

            sum(ifnull(Fees_sales_USD_CP,0)) - sum(ifnull(Fees_sales_USD_PP,0)) as Fees_sales_USD_delta,
            sum(ifnull(Rebates_sales_USD_CP,0)) - sum(ifnull(Rebates_sales_USD_PP,0)) as Rebates_sales_USD_delta,
            sum(ifnull(warranties_sales_USD_CP,0)) - sum(ifnull(warranties_sales_USD_PP,0)) as warranties_sales_USD_delta,
            sum(ifnull(returns_on_warranties_sales_USD_CP,0)) - sum(ifnull(returns_on_warranties_sales_USD_PP,0)) as returns_on_warranties_sales_USD_delta,
            sum(ifnull(returns_sales_USD_CP,0)) - sum(ifnull(returns_sales_USD_PP,0)) as returns_sales_USD_delta,
            sum(ifnull(noncommercial_sales_USD_CP,0)) - sum(ifnull(noncommercial_sales_USD_PP,0)) as noncommercial_sales_USD_delta,
            sum(ifnull(integration_sales_USD_CP,0)) - sum(ifnull(integration_sales_USD_PP,0)) as integration_sales_USD_delta,                     
            sum(ifnull(sales_amount_USD_CP,0)) - sum(ifnull(sales_amount_USD_PP,0)) as sales_amount_USD_delta,    

            sum(ifnull(Fees_sales_CAD_CP,0)) - sum(ifnull(Fees_sales_CAD_PP,0)) as Fees_sales_CAD_delta,
            sum(ifnull(Rebates_sales_CAD_CP,0)) - sum(ifnull(Rebates_sales_CAD_PP,0)) as Rebates_sales_CAD_delta,
            sum(ifnull(warranties_sales_CAD_CP,0)) - sum(ifnull(warranties_sales_CAD_PP,0)) as warranties_sales_CAD_delta,
            sum(ifnull(returns_on_warranties_sales_CAD_CP,0)) - sum(ifnull(returns_on_warranties_sales_CAD_PP,0)) as returns_on_warranties_sales_CAD_delta,
            sum(ifnull(returns_sales_CAD_CP,0)) - sum(ifnull(returns_sales_CAD_PP,0)) as returns_sales_CAD_delta,
            sum(ifnull(noncommercial_sales_CAD_CP,0)) - sum(ifnull(noncommercial_sales_CAD_PP,0)) as noncommercial_sales_CAD_delta,
            sum(ifnull(integration_sales_CAD_CP,0)) - sum(ifnull(integration_sales_CAD_PP,0)) as integration_sales_CAD_delta,                     
            sum(ifnull(sales_amount_CAD_CP,0)) - sum(ifnull(sales_amount_CAD_PP,0)) as sales_amount_CAD_delta,    

            sum(ifnull(Fees_sales_MXN_CP,0)) - sum(ifnull(Fees_sales_MXN_PP,0)) as Fees_sales_MXN_delta,
            sum(ifnull(Rebates_sales_MXN_CP,0)) - sum(ifnull(Rebates_sales_MXN_PP,0)) as Rebates_sales_MXN_delta,
            sum(ifnull(warranties_sales_MXN_CP,0)) - sum(ifnull(warranties_sales_MXN_PP,0)) as warranties_sales_MXN_delta,
            sum(ifnull(returns_on_warranties_sales_MXN_CP,0)) - sum(ifnull(returns_on_warranties_sales_MXN_PP,0)) as returns_on_warranties_sales_MXN_delta,
            sum(ifnull(returns_sales_MXN_CP,0)) - sum(ifnull(returns_sales_MXN_PP,0)) as returns_sales_MXN_delta,
            sum(ifnull(noncommercial_sales_MXN_CP,0)) - sum(ifnull(noncommercial_sales_MXN_PP,0)) as noncommercial_sales_MXN_delta,
            sum(ifnull(integration_sales_MXN_CP,0)) - sum(ifnull(integration_sales_MXN_PP,0)) as integration_sales_MXN_delta,                     
            sum(ifnull(sales_amount_MXN_CP,0)) - sum(ifnull(sales_amount_MXN_PP,0)) as sales_amount_MXN_delta,    

            sum(ifnull(Fees_sales_BRL_CP,0)) - sum(ifnull(Fees_sales_BRL_PP,0)) as Fees_sales_BRL_delta,
            sum(ifnull(Rebates_sales_BRL_CP,0)) - sum(ifnull(Rebates_sales_BRL_PP,0)) as Rebates_sales_BRL_delta,
            sum(ifnull(warranties_sales_BRL_CP,0)) - sum(ifnull(warranties_sales_BRL_PP,0)) as warranties_sales_BRL_delta,
            sum(ifnull(returns_on_warranties_sales_BRL_CP,0)) - sum(ifnull(returns_on_warranties_sales_BRL_PP,0)) as returns_on_warranties_sales_BRL_delta,
            sum(ifnull(returns_sales_BRL_CP,0)) - sum(ifnull(returns_sales_BRL_PP,0)) as returns_sales_BRL_delta,
            sum(ifnull(noncommercial_sales_BRL_CP,0)) - sum(ifnull(noncommercial_sales_BRL_PP,0)) as noncommercial_sales_BRL_delta,
            sum(ifnull(integration_sales_BRL_CP,0)) - sum(ifnull(integration_sales_BRL_PP,0)) as integration_sales_BRL_delta,                     
            sum(ifnull(sales_amount_BRL_CP,0)) - sum(ifnull(sales_amount_BRL_PP,0)) as sales_amount_BRL_delta,    

      --- Calculate cost delta for excluded categories (fees, reabates, warranties, return on warranties, returns)
            sum(ifnull(Fees_cost_EUR_CP,0)) - sum(ifnull(Fees_cost_EUR_PP,0)) as Fees_cost_EUR_delta,
            sum(ifnull(Rebates_cost_EUR_CP,0)) - sum(ifnull(Rebates_cost_EUR_PP,0)) as Rebates_cost_EUR_delta,
            sum(ifnull(warranties_cost_EUR_CP,0)) - sum(ifnull(warranties_cost_EUR_PP,0)) as warranties_cost_EUR_delta,
            sum(ifnull(returns_on_warranties_cost_EUR_CP,0)) - sum(ifnull(returns_on_warranties_cost_EUR_PP,0)) as returns_on_warranties_cost_EUR_delta,
            sum(ifnull(returns_cost_EUR_CP,0)) - sum(ifnull(returns_cost_EUR_PP,0)) as returns_cost_EUR_delta,
            sum(ifnull(noncommercial_cost_EUR_CP,0)) - sum(ifnull(noncommercial_cost_EUR_PP,0)) as noncommercial_cost_EUR_delta,
            sum(ifnull(integration_cost_EUR_CP,0)) - sum(ifnull(integration_cost_EUR_PP,0)) as integration_cost_EUR_delta,                     

            sum(ifnull(Fees_cost_EUR_CP,0)) 
            + sum(ifnull(Rebates_cost_EUR_CP,0)) 
            + sum(ifnull(warranties_cost_EUR_CP,0)) 
            + sum(ifnull(returns_on_warranties_cost_EUR_CP,0)) 
            + sum(ifnull(returns_cost_EUR_CP,0)) 
            + sum(ifnull(orders_cost_EUR_CP,0)) 
            + sum(ifnull(noncommercial_cost_EUR_CP,0)) 
            + sum(ifnull(integration_cost_EUR_CP,0)) as cost_EUR_CP,

            sum(ifnull(Fees_cost_EUR_PP,0)) 
            + sum(ifnull(Rebates_cost_EUR_PP,0)) 
            + sum(ifnull(warranties_cost_EUR_PP,0)) 
            + sum(ifnull(returns_on_warranties_cost_EUR_PP,0)) 
            + sum(ifnull(returns_cost_EUR_PP,0)) 
            + sum(ifnull(orders_cost_EUR_PP,0)) 
            + sum(ifnull(noncommercial_cost_EUR_PP,0)) 
            + sum(ifnull(integration_cost_EUR_PP,0)) as cost_EUR_PP,           

            sum(ifnull(Fees_cost_USD_CP,0)) - sum(ifnull(Fees_cost_USD_PP,0)) as Fees_cost_USD_delta,
            sum(ifnull(Rebates_cost_USD_CP,0)) - sum(ifnull(Rebates_cost_USD_PP,0)) as Rebates_cost_USD_delta,
            sum(ifnull(warranties_cost_USD_CP,0)) - sum(ifnull(warranties_cost_USD_PP,0)) as warranties_cost_USD_delta,
            sum(ifnull(returns_on_warranties_cost_USD_CP,0)) - sum(ifnull(returns_on_warranties_cost_USD_PP,0)) as returns_on_warranties_cost_USD_delta,
            sum(ifnull(returns_cost_USD_CP,0)) - sum(ifnull(returns_cost_USD_PP,0)) as returns_cost_USD_delta,
            sum(ifnull(noncommercial_cost_USD_CP,0)) - sum(ifnull(noncommercial_cost_USD_PP,0)) as noncommercial_cost_USD_delta,
            sum(ifnull(integration_cost_USD_CP,0)) - sum(ifnull(integration_cost_USD_PP,0)) as integration_cost_USD_delta,                     

            sum(ifnull(Fees_cost_USD_CP,0)) 
            + sum(ifnull(Rebates_cost_USD_CP,0)) 
            + sum(ifnull(warranties_cost_USD_CP,0)) 
            + sum(ifnull(returns_on_warranties_cost_USD_CP,0)) 
            + sum(ifnull(returns_cost_USD_CP,0)) 
            + sum(ifnull(orders_cost_USD_CP,0)) 
            + sum(ifnull(noncommercial_cost_USD_CP,0)) 
            + sum(ifnull(integration_cost_USD_CP,0)) as cost_USD_CP,

            sum(ifnull(Fees_cost_USD_PP,0)) 
            + sum(ifnull(Rebates_cost_USD_PP,0)) 
            + sum(ifnull(warranties_cost_USD_PP,0)) 
            + sum(ifnull(returns_on_warranties_cost_USD_PP,0)) 
            + sum(ifnull(returns_cost_USD_PP,0)) 
            + sum(ifnull(orders_cost_USD_PP,0)) 
            + sum(ifnull(noncommercial_cost_USD_PP,0)) 
            + sum(ifnull(integration_cost_USD_PP,0)) as cost_USD_PP,  

            sum(ifnull(Fees_cost_CAD_CP,0)) - sum(ifnull(Fees_cost_CAD_PP,0)) as Fees_cost_CAD_delta,
            sum(ifnull(Rebates_cost_CAD_CP,0)) - sum(ifnull(Rebates_cost_CAD_PP,0)) as Rebates_cost_CAD_delta,
            sum(ifnull(warranties_cost_CAD_CP,0)) - sum(ifnull(warranties_cost_CAD_PP,0)) as warranties_cost_CAD_delta,
            sum(ifnull(returns_on_warranties_cost_CAD_CP,0)) - sum(ifnull(returns_on_warranties_cost_CAD_PP,0)) as returns_on_warranties_cost_CAD_delta,
            sum(ifnull(returns_cost_CAD_CP,0)) - sum(ifnull(returns_cost_CAD_PP,0)) as returns_cost_CAD_delta,
            sum(ifnull(noncommercial_cost_CAD_CP,0)) - sum(ifnull(noncommercial_cost_CAD_PP,0)) as noncommercial_cost_CAD_delta,
            sum(ifnull(integration_cost_CAD_CP,0)) - sum(ifnull(integration_cost_CAD_PP,0)) as integration_cost_CAD_delta,                     

            sum(ifnull(Fees_cost_CAD_CP,0)) 
            + sum(ifnull(Rebates_cost_CAD_CP,0)) 
            + sum(ifnull(warranties_cost_CAD_CP,0)) 
            + sum(ifnull(returns_on_warranties_cost_CAD_CP,0)) 
            + sum(ifnull(returns_cost_CAD_CP,0)) 
            + sum(ifnull(orders_cost_CAD_CP,0)) 
            + sum(ifnull(noncommercial_cost_CAD_CP,0)) 
            + sum(ifnull(integration_cost_CAD_CP,0)) as cost_CAD_CP,

            sum(ifnull(Fees_cost_CAD_PP,0)) 
            + sum(ifnull(Rebates_cost_CAD_PP,0)) 
            + sum(ifnull(warranties_cost_CAD_PP,0)) 
            + sum(ifnull(returns_on_warranties_cost_CAD_PP,0)) 
            + sum(ifnull(returns_cost_CAD_PP,0)) 
            + sum(ifnull(orders_cost_CAD_PP,0)) 
            + sum(ifnull(noncommercial_cost_CAD_PP,0)) 
            + sum(ifnull(integration_cost_CAD_PP,0)) as cost_CAD_PP,  

            sum(ifnull(Fees_cost_MXN_CP,0)) - sum(ifnull(Fees_cost_MXN_PP,0)) as Fees_cost_MXN_delta,
            sum(ifnull(Rebates_cost_MXN_CP,0)) - sum(ifnull(Rebates_cost_MXN_PP,0)) as Rebates_cost_MXN_delta,
            sum(ifnull(warranties_cost_MXN_CP,0)) - sum(ifnull(warranties_cost_MXN_PP,0)) as warranties_cost_MXN_delta,
            sum(ifnull(returns_on_warranties_cost_MXN_CP,0)) - sum(ifnull(returns_on_warranties_cost_MXN_PP,0)) as returns_on_warranties_cost_MXN_delta,
            sum(ifnull(returns_cost_MXN_CP,0)) - sum(ifnull(returns_cost_MXN_PP,0)) as returns_cost_MXN_delta,
            sum(ifnull(noncommercial_cost_MXN_CP,0)) - sum(ifnull(noncommercial_cost_MXN_PP,0)) as noncommercial_cost_MXN_delta,
            sum(ifnull(integration_cost_MXN_CP,0)) - sum(ifnull(integration_cost_MXN_PP,0)) as integration_cost_MXN_delta,                     

            sum(ifnull(Fees_cost_MXN_CP,0)) 
            + sum(ifnull(Rebates_cost_MXN_CP,0)) 
            + sum(ifnull(warranties_cost_MXN_CP,0)) 
            + sum(ifnull(returns_on_warranties_cost_MXN_CP,0)) 
            + sum(ifnull(returns_cost_MXN_CP,0)) 
            + sum(ifnull(orders_cost_MXN_CP,0)) 
            + sum(ifnull(noncommercial_cost_MXN_CP,0)) 
            + sum(ifnull(integration_cost_MXN_CP,0)) as cost_MXN_CP,

            sum(ifnull(Fees_cost_MXN_PP,0)) 
            + sum(ifnull(Rebates_cost_MXN_PP,0)) 
            + sum(ifnull(warranties_cost_MXN_PP,0)) 
            + sum(ifnull(returns_on_warranties_cost_MXN_PP,0)) 
            + sum(ifnull(returns_cost_MXN_PP,0)) 
            + sum(ifnull(orders_cost_MXN_PP,0)) 
            + sum(ifnull(noncommercial_cost_MXN_PP,0)) 
            + sum(ifnull(integration_cost_MXN_PP,0)) as cost_MXN_PP,  

            sum(ifnull(Fees_cost_BRL_CP,0)) - sum(ifnull(Fees_cost_BRL_PP,0)) as Fees_cost_BRL_delta,
            sum(ifnull(Rebates_cost_BRL_CP,0)) - sum(ifnull(Rebates_cost_BRL_PP,0)) as Rebates_cost_BRL_delta,
            sum(ifnull(warranties_cost_BRL_CP,0)) - sum(ifnull(warranties_cost_BRL_PP,0)) as warranties_cost_BRL_delta,
            sum(ifnull(returns_on_warranties_cost_BRL_CP,0)) - sum(ifnull(returns_on_warranties_cost_BRL_PP,0)) as returns_on_warranties_cost_BRL_delta,
            sum(ifnull(returns_cost_BRL_CP,0)) - sum(ifnull(returns_cost_BRL_PP,0)) as returns_cost_BRL_delta,
            sum(ifnull(noncommercial_cost_BRL_CP,0)) - sum(ifnull(noncommercial_cost_BRL_PP,0)) as noncommercial_cost_BRL_delta,
            sum(ifnull(integration_cost_BRL_CP,0)) - sum(ifnull(integration_cost_BRL_PP,0)) as integration_cost_BRL_delta,                     

            sum(ifnull(Fees_cost_BRL_CP,0)) 
            + sum(ifnull(Rebates_cost_BRL_CP,0)) 
            + sum(ifnull(warranties_cost_BRL_CP,0)) 
            + sum(ifnull(returns_on_warranties_cost_BRL_CP,0)) 
            + sum(ifnull(returns_cost_BRL_CP,0)) 
            + sum(ifnull(orders_cost_BRL_CP,0)) 
            + sum(ifnull(noncommercial_cost_BRL_CP,0)) 
            + sum(ifnull(integration_cost_BRL_CP,0)) as cost_BRL_CP,

            sum(ifnull(Fees_cost_BRL_PP,0)) 
            + sum(ifnull(Rebates_cost_BRL_PP,0)) 
            + sum(ifnull(warranties_cost_BRL_PP,0)) 
            + sum(ifnull(returns_on_warranties_cost_BRL_PP,0)) 
            + sum(ifnull(returns_cost_BRL_PP,0)) 
            + sum(ifnull(orders_cost_BRL_PP,0)) 
            + sum(ifnull(noncommercial_cost_BRL_PP,0)) 
            + sum(ifnull(integration_cost_BRL_PP,0)) as cost_BRL_PP,  

      --- Calculate cost landed delta for excluded categories (fees, reabates, warranties, return on warranties, returns)

            sum(ifnull(Fees_cost_landed_EUR_CP,0)) - sum(ifnull(Fees_cost_landed_EUR_PP,0)) as Fees_cost_landed_EUR_delta,
            sum(ifnull(Rebates_cost_landed_EUR_CP,0)) - sum(ifnull(Rebates_cost_landed_EUR_PP,0)) as Rebates_cost_landed_EUR_delta,
            sum(ifnull(warranties_cost_landed_EUR_CP,0)) - sum(ifnull(warranties_cost_landed_EUR_PP,0)) as warranties_cost_landed_EUR_delta,
            sum(ifnull(returns_on_warranties_cost_landed_EUR_CP,0)) - sum(ifnull(returns_on_warranties_cost_landed_EUR_PP,0)) as returns_on_warranties_cost_landed_EUR_delta,
            sum(ifnull(returns_cost_landed_EUR_CP,0)) - sum(ifnull(returns_cost_landed_EUR_PP,0)) as returns_cost_landed_EUR_delta,
            sum(ifnull(noncommercial_cost_landed_EUR_CP,0)) - sum(ifnull(noncommercial_cost_landed_EUR_PP,0)) as noncommercial_cost_landed_EUR_delta,
            sum(ifnull(integration_cost_landed_EUR_CP,0)) - sum(ifnull(integration_cost_landed_EUR_PP,0)) as integration_cost_landed_EUR_delta,       

            sum(ifnull(Fees_cost_landed_EUR_CP,0)) 
            + sum(ifnull(Rebates_cost_landed_EUR_CP,0)) 
            + sum(ifnull(warranties_cost_landed_EUR_CP,0)) 
            + sum(ifnull(returns_on_warranties_cost_landed_EUR_CP,0)) 
            + sum(ifnull(returns_cost_landed_EUR_CP,0)) 
            + sum(ifnull(orders_cost_landed_EUR_CP,0)) 
            + sum(ifnull(noncommercial_cost_landed_EUR_CP,0)) 
            + sum(ifnull(integration_cost_landed_EUR_CP,0)) as cost_landed_EUR_CP,

            sum(ifnull(Fees_cost_landed_EUR_PP,0)) 
            + sum(ifnull(Rebates_cost_landed_EUR_PP,0)) 
            + sum(ifnull(warranties_cost_landed_EUR_PP,0)) 
            + sum(ifnull(returns_on_warranties_cost_landed_EUR_PP,0)) 
            + sum(ifnull(returns_cost_landed_EUR_PP,0)) 
            + sum(ifnull(orders_cost_landed_EUR_PP,0)) 
            + sum(ifnull(noncommercial_cost_landed_EUR_PP,0)) 
            + sum(ifnull(integration_cost_landed_EUR_PP,0)) as cost_landed_EUR_PP,      

            sum(ifnull(Fees_cost_landed_USD_CP,0)) - sum(ifnull(Fees_cost_landed_USD_PP,0)) as Fees_cost_landed_USD_delta,
            sum(ifnull(Rebates_cost_landed_USD_CP,0)) - sum(ifnull(Rebates_cost_landed_USD_PP,0)) as Rebates_cost_landed_USD_delta,
            sum(ifnull(warranties_cost_landed_USD_CP,0)) - sum(ifnull(warranties_cost_landed_USD_PP,0)) as warranties_cost_landed_USD_delta,
            sum(ifnull(returns_on_warranties_cost_landed_USD_CP,0)) - sum(ifnull(returns_on_warranties_cost_landed_USD_PP,0)) as returns_on_warranties_cost_landed_USD_delta,
            sum(ifnull(returns_cost_landed_USD_CP,0)) - sum(ifnull(returns_cost_landed_USD_PP,0)) as returns_cost_landed_USD_delta,
            sum(ifnull(noncommercial_cost_landed_USD_CP,0)) - sum(ifnull(noncommercial_cost_landed_USD_PP,0)) as noncommercial_cost_landed_USD_delta,
            sum(ifnull(integration_cost_landed_USD_CP,0)) - sum(ifnull(integration_cost_landed_USD_PP,0)) as integration_cost_landed_USD_delta,       

            sum(ifnull(Fees_cost_landed_USD_CP,0)) 
            + sum(ifnull(Rebates_cost_landed_USD_CP,0)) 
            + sum(ifnull(warranties_cost_landed_USD_CP,0)) 
            + sum(ifnull(returns_on_warranties_cost_landed_USD_CP,0)) 
            + sum(ifnull(returns_cost_landed_USD_CP,0)) 
            + sum(ifnull(orders_cost_landed_USD_CP,0)) 
            + sum(ifnull(noncommercial_cost_landed_USD_CP,0)) 
            + sum(ifnull(integration_cost_landed_USD_CP,0)) as cost_landed_USD_CP,

            sum(ifnull(Fees_cost_landed_USD_PP,0)) 
            + sum(ifnull(Rebates_cost_landed_USD_PP,0)) 
            + sum(ifnull(warranties_cost_landed_USD_PP,0)) 
            + sum(ifnull(returns_on_warranties_cost_landed_USD_PP,0)) 
            + sum(ifnull(returns_cost_landed_USD_PP,0)) 
            + sum(ifnull(orders_cost_landed_USD_PP,0)) 
            + sum(ifnull(noncommercial_cost_landed_USD_PP,0)) 
            + sum(ifnull(integration_cost_landed_USD_PP,0)) as cost_landed_USD_PP,   

            sum(ifnull(Fees_cost_landed_CAD_CP,0)) - sum(ifnull(Fees_cost_landed_CAD_PP,0)) as Fees_cost_landed_CAD_delta,
            sum(ifnull(Rebates_cost_landed_CAD_CP,0)) - sum(ifnull(Rebates_cost_landed_CAD_PP,0)) as Rebates_cost_landed_CAD_delta,
            sum(ifnull(warranties_cost_landed_CAD_CP,0)) - sum(ifnull(warranties_cost_landed_CAD_PP,0)) as warranties_cost_landed_CAD_delta,
            sum(ifnull(returns_on_warranties_cost_landed_CAD_CP,0)) - sum(ifnull(returns_on_warranties_cost_landed_CAD_PP,0)) as returns_on_warranties_cost_landed_CAD_delta,
            sum(ifnull(returns_cost_landed_CAD_CP,0)) - sum(ifnull(returns_cost_landed_CAD_PP,0)) as returns_cost_landed_CAD_delta,
            sum(ifnull(noncommercial_cost_landed_CAD_CP,0)) - sum(ifnull(noncommercial_cost_landed_CAD_PP,0)) as noncommercial_cost_landed_CAD_delta,
            sum(ifnull(integration_cost_landed_CAD_CP,0)) - sum(ifnull(integration_cost_landed_CAD_PP,0)) as integration_cost_landed_CAD_delta,       

            sum(ifnull(Fees_cost_landed_CAD_CP,0)) 
            + sum(ifnull(Rebates_cost_landed_CAD_CP,0)) 
            + sum(ifnull(warranties_cost_landed_CAD_CP,0)) 
            + sum(ifnull(returns_on_warranties_cost_landed_CAD_CP,0)) 
            + sum(ifnull(returns_cost_landed_CAD_CP,0)) 
            + sum(ifnull(orders_cost_landed_CAD_CP,0)) 
            + sum(ifnull(noncommercial_cost_landed_CAD_CP,0)) 
            + sum(ifnull(integration_cost_landed_CAD_CP,0)) as cost_landed_CAD_CP,

            sum(ifnull(Fees_cost_landed_CAD_PP,0)) 
            + sum(ifnull(Rebates_cost_landed_CAD_PP,0)) 
            + sum(ifnull(warranties_cost_landed_CAD_PP,0)) 
            + sum(ifnull(returns_on_warranties_cost_landed_CAD_PP,0)) 
            + sum(ifnull(returns_cost_landed_CAD_PP,0)) 
            + sum(ifnull(orders_cost_landed_CAD_PP,0)) 
            + sum(ifnull(noncommercial_cost_landed_CAD_PP,0)) 
            + sum(ifnull(integration_cost_landed_CAD_PP,0)) as cost_landed_CAD_PP,   

            sum(ifnull(Fees_cost_landed_MXN_CP,0)) - sum(ifnull(Fees_cost_landed_MXN_PP,0)) as Fees_cost_landed_MXN_delta,
            sum(ifnull(Rebates_cost_landed_MXN_CP,0)) - sum(ifnull(Rebates_cost_landed_MXN_PP,0)) as Rebates_cost_landed_MXN_delta,
            sum(ifnull(warranties_cost_landed_MXN_CP,0)) - sum(ifnull(warranties_cost_landed_MXN_PP,0)) as warranties_cost_landed_MXN_delta,
            sum(ifnull(returns_on_warranties_cost_landed_MXN_CP,0)) - sum(ifnull(returns_on_warranties_cost_landed_MXN_PP,0)) as returns_on_warranties_cost_landed_MXN_delta,
            sum(ifnull(returns_cost_landed_MXN_CP,0)) - sum(ifnull(returns_cost_landed_MXN_PP,0)) as returns_cost_landed_MXN_delta,
            sum(ifnull(noncommercial_cost_landed_MXN_CP,0)) - sum(ifnull(noncommercial_cost_landed_MXN_PP,0)) as noncommercial_cost_landed_MXN_delta,
            sum(ifnull(integration_cost_landed_MXN_CP,0)) - sum(ifnull(integration_cost_landed_MXN_PP,0)) as integration_cost_landed_MXN_delta,       

            sum(ifnull(Fees_cost_landed_MXN_CP,0)) 
            + sum(ifnull(Rebates_cost_landed_MXN_CP,0)) 
            + sum(ifnull(warranties_cost_landed_MXN_CP,0)) 
            + sum(ifnull(returns_on_warranties_cost_landed_MXN_CP,0)) 
            + sum(ifnull(returns_cost_landed_MXN_CP,0)) 
            + sum(ifnull(orders_cost_landed_MXN_CP,0)) 
            + sum(ifnull(noncommercial_cost_landed_MXN_CP,0)) 
            + sum(ifnull(integration_cost_landed_MXN_CP,0)) as cost_landed_MXN_CP,

            sum(ifnull(Fees_cost_landed_MXN_PP,0)) 
            + sum(ifnull(Rebates_cost_landed_MXN_PP,0)) 
            + sum(ifnull(warranties_cost_landed_MXN_PP,0)) 
            + sum(ifnull(returns_on_warranties_cost_landed_MXN_PP,0)) 
            + sum(ifnull(returns_cost_landed_MXN_PP,0)) 
            + sum(ifnull(orders_cost_landed_MXN_PP,0)) 
            + sum(ifnull(noncommercial_cost_landed_MXN_PP,0)) 
            + sum(ifnull(integration_cost_landed_MXN_PP,0)) as cost_landed_MXN_PP,   

            sum(ifnull(Fees_cost_landed_BRL_CP,0)) - sum(ifnull(Fees_cost_landed_BRL_PP,0)) as Fees_cost_landed_BRL_delta,
            sum(ifnull(Rebates_cost_landed_BRL_CP,0)) - sum(ifnull(Rebates_cost_landed_BRL_PP,0)) as Rebates_cost_landed_BRL_delta,
            sum(ifnull(warranties_cost_landed_BRL_CP,0)) - sum(ifnull(warranties_cost_landed_BRL_PP,0)) as warranties_cost_landed_BRL_delta,
            sum(ifnull(returns_on_warranties_cost_landed_BRL_CP,0)) - sum(ifnull(returns_on_warranties_cost_landed_BRL_PP,0)) as returns_on_warranties_cost_landed_BRL_delta,
            sum(ifnull(returns_cost_landed_BRL_CP,0)) - sum(ifnull(returns_cost_landed_BRL_PP,0)) as returns_cost_landed_BRL_delta,
            sum(ifnull(noncommercial_cost_landed_BRL_CP,0)) - sum(ifnull(noncommercial_cost_landed_BRL_PP,0)) as noncommercial_cost_landed_BRL_delta,
            sum(ifnull(integration_cost_landed_BRL_CP,0)) - sum(ifnull(integration_cost_landed_BRL_PP,0)) as integration_cost_landed_BRL_delta,       

            sum(ifnull(Fees_cost_landed_BRL_CP,0)) 
            + sum(ifnull(Rebates_cost_landed_BRL_CP,0)) 
            + sum(ifnull(warranties_cost_landed_BRL_CP,0)) 
            + sum(ifnull(returns_on_warranties_cost_landed_BRL_CP,0)) 
            + sum(ifnull(returns_cost_landed_BRL_CP,0)) 
            + sum(ifnull(orders_cost_landed_BRL_CP,0)) 
            + sum(ifnull(noncommercial_cost_landed_BRL_CP,0)) 
            + sum(ifnull(integration_cost_landed_BRL_CP,0)) as cost_landed_BRL_CP,

            sum(ifnull(Fees_cost_landed_BRL_PP,0)) 
            + sum(ifnull(Rebates_cost_landed_BRL_PP,0)) 
            + sum(ifnull(warranties_cost_landed_BRL_PP,0)) 
            + sum(ifnull(returns_on_warranties_cost_landed_BRL_PP,0)) 
            + sum(ifnull(returns_cost_landed_BRL_PP,0)) 
            + sum(ifnull(orders_cost_landed_BRL_PP,0)) 
            + sum(ifnull(noncommercial_cost_landed_BRL_PP,0)) 
            + sum(ifnull(integration_cost_landed_BRL_PP,0)) as cost_landed_BRL_PP,   

      --- Calculate sales #New,lost & recurring
              sum(case when evolution_type = 'NEW'  then orders_sales_EUR_CP else NULL end) as sales_amount_new_EUR_CP,
              sum(case when evolution_type = 'LOST' then orders_sales_EUR_PP else NULL end) as sales_amount_lost_EUR_CP, --attention! takes the PP sales to calculate the LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_sales_EUR_CP else NULL end) as orders_sales_recurring_EUR_CP,
              sum(case when evolution_type = 'RECURRING' then orders_sales_EUR_PP else NULL end) as orders_sales_recurring_EUR_PP,

              sum(case when evolution_type = 'NEW'  then orders_sales_USD_CP else NULL end) as sales_amount_new_USD_CP,
              sum(case when evolution_type = 'LOST' then orders_sales_USD_PP else NULL end) as sales_amount_lost_USD_CP, --attention! takes the PP sales to calculate the LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_sales_USD_CP else NULL end) as orders_sales_recurring_USD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_sales_USD_PP else NULL end) as orders_sales_recurring_USD_PP,

              sum(case when evolution_type = 'NEW'  then orders_sales_CAD_CP else NULL end) as sales_amount_new_CAD_CP,
              sum(case when evolution_type = 'LOST' then orders_sales_CAD_PP else NULL end) as sales_amount_lost_CAD_CP, --attention! takes the PP sales to calculate the LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_sales_CAD_CP else NULL end) as orders_sales_recurring_CAD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_sales_CAD_PP else NULL end) as orders_sales_recurring_CAD_PP,

              sum(case when evolution_type = 'NEW'  then orders_sales_MXN_CP else NULL end) as sales_amount_new_MXN_CP,
              sum(case when evolution_type = 'LOST' then orders_sales_MXN_PP else NULL end) as sales_amount_lost_MXN_CP, --attention! takes the PP sales to calculate the LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_sales_MXN_CP else NULL end) as orders_sales_recurring_MXN_CP,
              sum(case when evolution_type = 'RECURRING' then orders_sales_MXN_PP else NULL end) as orders_sales_recurring_MXN_PP,

              sum(case when evolution_type = 'NEW'  then orders_sales_BRL_CP else NULL end) as sales_amount_new_BRL_CP,
              sum(case when evolution_type = 'LOST' then orders_sales_BRL_PP else NULL end) as sales_amount_lost_BRL_CP, --attention! takes the PP sales to calculate the LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_sales_BRL_CP else NULL end) as orders_sales_recurring_BRL_CP,
              sum(case when evolution_type = 'RECURRING' then orders_sales_BRL_PP else NULL end) as orders_sales_recurring_BRL_PP,

      --- Calculate cost #New,lost & recurring
              sum(case when evolution_type = 'NEW'  then orders_cost_EUR_CP else NULL end) as cost_amount_new_EUR_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_EUR_PP else NULL end) as cost_amount_lost_EUR_CP, --attention! it takes the PP sales to calculate the LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_EUR_CP else NULL end) as orders_cost_recurring_EUR_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_EUR_PP else NULL end) as orders_cost_recurring_EUR_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_USD_CP else NULL end) as cost_amount_new_USD_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_USD_PP else NULL end) as cost_amount_lost_USD_CP, --attention! it takes the PP sales to calculate the LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_USD_CP else NULL end) as orders_cost_recurring_USD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_USD_PP else NULL end) as orders_cost_recurring_USD_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_CAD_CP else NULL end) as cost_amount_new_CAD_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_CAD_PP else NULL end) as cost_amount_lost_CAD_CP, --attention! it takes the PP sales to calculate the LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_CAD_CP else NULL end) as orders_cost_recurring_CAD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_CAD_PP else NULL end) as orders_cost_recurring_CAD_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_MXN_CP else NULL end) as cost_amount_new_MXN_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_MXN_PP else NULL end) as cost_amount_lost_MXN_CP, --attention! it takes the PP sales to calculate the LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_MXN_CP else NULL end) as orders_cost_recurring_MXN_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_MXN_PP else NULL end) as orders_cost_recurring_MXN_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_BRL_CP else NULL end) as cost_amount_new_BRL_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_BRL_PP else NULL end) as cost_amount_lost_BRL_CP, --attention! it takes the PP sales to calculate the LOST amount
              sum(case when evolution_type = 'RECURRING' then orders_cost_BRL_CP else NULL end) as orders_cost_recurring_BRL_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_BRL_PP else NULL end) as orders_cost_recurring_BRL_PP,

      --- Calculate cost #New,lost & recurring    
              sum(case when evolution_type = 'NEW'  then orders_cost_landed_EUR_CP else NULL end) as cost_landed_amount_new_EUR_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_landed_EUR_PP else NULL end) as cost_landed_amount_lost_EUR_CP, 
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_EUR_CP else NULL end) as orders_cost_landed_recurring_EUR_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_EUR_PP else NULL end) as orders_cost_landed_recurring_EUR_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_landed_USD_CP else NULL end) as cost_landed_amount_new_USD_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_landed_USD_PP else NULL end) as cost_landed_amount_lost_USD_CP, 
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_USD_CP else NULL end) as orders_cost_landed_recurring_USD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_USD_PP else NULL end) as orders_cost_landed_recurring_USD_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_landed_CAD_CP else NULL end) as cost_landed_amount_new_CAD_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_landed_CAD_PP else NULL end) as cost_landed_amount_lost_CAD_CP, 
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_CAD_CP else NULL end) as orders_cost_landed_recurring_CAD_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_CAD_PP else NULL end) as orders_cost_landed_recurring_CAD_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_landed_MXN_CP else NULL end) as cost_landed_amount_new_MXN_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_landed_MXN_PP else NULL end) as cost_landed_amount_lost_MXN_CP, 
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_MXN_CP else NULL end) as orders_cost_landed_recurring_MXN_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_MXN_PP else NULL end) as orders_cost_landed_recurring_MXN_PP,

              sum(case when evolution_type = 'NEW'  then orders_cost_landed_BRL_CP else NULL end) as cost_landed_amount_new_BRL_CP,
              sum(case when evolution_type = 'LOST' then orders_cost_landed_BRL_PP else NULL end) as cost_landed_amount_lost_BRL_CP, 
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_BRL_CP else NULL end) as orders_cost_landed_recurring_BRL_CP,
              sum(case when evolution_type = 'RECURRING' then orders_cost_landed_BRL_PP else NULL end) as orders_cost_landed_recurring_BRL_PP,
              
      --- Calculate the sales price effect
              sum(case when evolution_type = 'RECURRING' 
              then (average_price_per_unit_EUR_CP_with_fx_rate_PP - average_price_per_unit_EUR_PP) * orders_quantity_CP 
              else 0 end) as sales_price_effect_EUR,

              sum(case when evolution_type = 'RECURRING' 
              then (average_price_per_unit_USD_CP_with_fx_rate_PP - average_price_per_unit_USD_PP) * orders_quantity_CP 
              else 0 end) as sales_price_effect_USD,

              sum(case when evolution_type = 'RECURRING' 
              then (average_price_per_unit_CAD_CP_with_fx_rate_PP - average_price_per_unit_CAD_PP) * orders_quantity_CP 
              else 0 end) as sales_price_effect_CAD,

              sum(case when evolution_type = 'RECURRING' 
              then (average_price_per_unit_MXN_CP_with_fx_rate_PP - average_price_per_unit_MXN_PP) * orders_quantity_CP 
              else 0 end) as sales_price_effect_MXN,

              sum(case when evolution_type = 'RECURRING' 
              then (average_price_per_unit_BRL_CP_with_fx_rate_PP - average_price_per_unit_BRL_PP) * orders_quantity_CP 
              else 0 end) as sales_price_effect_BRL,

      --- Calculate the cost effect
              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_per_unit_EUR_CP_with_fx_rate_PP - average_cost_per_unit_EUR_PP) * orders_quantity_CP 
              else 0 end) as cost_effect_EUR,

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_per_unit_USD_CP_with_fx_rate_PP - average_cost_per_unit_USD_PP) * orders_quantity_CP 
              else 0 end) as cost_effect_USD,

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_per_unit_CAD_CP_with_fx_rate_PP - average_cost_per_unit_CAD_PP) * orders_quantity_CP 
              else 0 end) as cost_effect_CAD,

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_per_unit_MXN_CP_with_fx_rate_PP - average_cost_per_unit_MXN_PP) * orders_quantity_CP 
              else 0 end) as cost_effect_MXN,

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_per_unit_BRL_CP_with_fx_rate_PP - average_cost_per_unit_BRL_PP) * orders_quantity_CP 
              else 0 end) as cost_effect_BRL,

      --- Calculate the cost landed effect
              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_landed_per_unit_EUR_CP_with_fx_rate_PP - average_cost_landed_per_unit_EUR_PP) * orders_quantity_CP 
              else 0 end) as cost_landed_effect_EUR, 

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_landed_per_unit_USD_CP_with_fx_rate_PP - average_cost_landed_per_unit_USD_PP) * orders_quantity_CP 
              else 0 end) as cost_landed_effect_USD, 

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_landed_per_unit_CAD_CP_with_fx_rate_PP - average_cost_landed_per_unit_CAD_PP) * orders_quantity_CP 
              else 0 end) as cost_landed_effect_CAD, 

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_landed_per_unit_MXN_CP_with_fx_rate_PP - average_cost_landed_per_unit_MXN_PP) * orders_quantity_CP 
              else 0 end) as cost_landed_effect_MXN, 

              sum(case when evolution_type = 'RECURRING' 
              then (average_cost_landed_per_unit_BRL_CP_with_fx_rate_PP - average_cost_landed_per_unit_BRL_PP) * orders_quantity_CP 
              else 0 end) as cost_landed_effect_BRL,                           
              
      --- Calculate the quantity / volume effect for sales
              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_price_per_unit_EUR_PP 
                else 0 end) as quantity_effect_sales_EUR,

                sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_price_per_unit_USD_PP 
                else 0 end) as quantity_effect_sales_USD,

                sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_price_per_unit_CAD_PP 
                else 0 end) as quantity_effect_sales_CAD,

                sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_price_per_unit_MXN_PP 
                else 0 end) as quantity_effect_sales_MXN,

                sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_price_per_unit_BRL_PP 
                else 0 end) as quantity_effect_sales_BRL,

      --- Calculate the quantity / volume effect for cost group
              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_per_unit_EUR_PP 
                else 0 end) as quantity_effect_cost_EUR,

                sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_per_unit_USD_PP 
                else 0 end) as quantity_effect_cost_USD,

                sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_per_unit_CAD_PP 
                else 0 end) as quantity_effect_cost_CAD,

                sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_per_unit_MXN_PP 
                else 0 end) as quantity_effect_cost_MXN,

                sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_per_unit_BRL_PP 
                else 0 end) as quantity_effect_cost_BRL,

      --- Calculate the quantity / volume effect for cost group landed
              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_landed_per_unit_EUR_PP 
                else 0 end) as quantity_effect_cost_landed_EUR, 

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_landed_per_unit_USD_PP 
                else 0 end) as quantity_effect_cost_landed_USD, 

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_landed_per_unit_CAD_PP 
                else 0 end) as quantity_effect_cost_landed_CAD, 

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_landed_per_unit_MXN_PP 
                else 0 end) as quantity_effect_cost_landed_MXN, 

              sum(case when evolution_type = 'RECURRING' 
                then (orders_quantity_CP - orders_quantity_PP) * average_cost_landed_per_unit_BRL_PP 
                else 0 end) as quantity_effect_cost_landed_BRL,              
              
      --- Calculate the Fx effect
              sum(case when evolution_type = 'RECURRING' 
                then (average_price_per_unit_EUR_CP - average_price_per_unit_EUR_CP_with_fx_rate_PP) * orders_quantity_CP 
                else 0 end) as fx_effect_sales_EUR,

              sum(case when evolution_type = 'RECURRING' 
                then safe_divide(((average_price_per_unit_EUR_CP - average_price_per_unit_EUR_CP_with_fx_rate_PP) * orders_quantity_CP),orders_sales_EUR_PP) 
                else 0 end) as fx_effect_sales_percentage_EUR,


              sum(case when evolution_type = 'RECURRING' 
                then (average_price_per_unit_USD_CP - average_price_per_unit_USD_CP_with_fx_rate_PP) * orders_quantity_CP 
                else 0 end) as fx_effect_sales_USD,

              sum(case when evolution_type = 'RECURRING' 
                then safe_divide(((average_price_per_unit_USD_CP - average_price_per_unit_USD_CP_with_fx_rate_PP) * orders_quantity_CP),orders_sales_USD_PP) 
                else 0 end) as fx_effect_sales_percentage_USD,


              sum(case when evolution_type = 'RECURRING' 
                then (average_price_per_unit_CAD_CP - average_price_per_unit_CAD_CP_with_fx_rate_PP) * orders_quantity_CP 
                else 0 end) as fx_effect_sales_CAD,

              sum(case when evolution_type = 'RECURRING' 
                then safe_divide(((average_price_per_unit_CAD_CP - average_price_per_unit_CAD_CP_with_fx_rate_PP) * orders_quantity_CP),orders_sales_CAD_PP) 
                else 0 end) as fx_effect_sales_percentage_CAD,


              sum(case when evolution_type = 'RECURRING' 
                then (average_price_per_unit_MXN_CP - average_price_per_unit_MXN_CP_with_fx_rate_PP) * orders_quantity_CP 
                else 0 end) as fx_effect_sales_MXN,

              sum(case when evolution_type = 'RECURRING' 
                then safe_divide(((average_price_per_unit_MXN_CP - average_price_per_unit_MXN_CP_with_fx_rate_PP) * orders_quantity_CP),orders_sales_MXN_PP) 
                else 0 end) as fx_effect_sales_percentage_MXN,


              sum(case when evolution_type = 'RECURRING' 
                then (average_price_per_unit_BRL_CP - average_price_per_unit_BRL_CP_with_fx_rate_PP) * orders_quantity_CP 
                else 0 end) as fx_effect_sales_BRL,

              sum(case when evolution_type = 'RECURRING' 
                then safe_divide(((average_price_per_unit_BRL_CP - average_price_per_unit_BRL_CP_with_fx_rate_PP) * orders_quantity_CP),orders_sales_BRL_PP) 
                else 0 end) as fx_effect_sales_percentage_BRL

      from step4_calculations_on_sku_level_ytm_CP

    group by all

)

    -- STEP 5: Final select for the Growth decomposition year to month

, waterfall_final_output_countries_ytm as (

      select 

        'Link' as source_actuals,
        equipment_market,
        equipment_sub_market,

        Statistic_country,
        Statistic_country_iso,

        product_category,
        product_subcategory,
        product_class,
        product_type,

        brm_grouping,
        brm_grouping_sales_team,

        unit,

        TVH_no_Brand_code,
        TVH_no_Brand_descr,

        Period, 

        # SALES
        sum(orders_sales_recurring_EUR_CP) as orders_sales_recurring_EUR_CP_ytm,
        sum(orders_sales_recurring_EUR_PP) as orders_sales_recurring_EUR_PP_ytm,

        sum(sales_amount_EUR_CP) as sales_amount_EUR_CP_ytm,
        sum(sales_amount_EUR_PP) as sales_amount_EUR_PP_ytm,

        sum(sales_amount_new_EUR_CP) as sales_amount_new_EUR_CP_ytm,
        sum(ifnull(sales_amount_lost_EUR_CP,0)) as sales_amount_lost_EUR_CP_ytm,
        sum(sales_amount_EUR_delta) as sales_amount_EUR_delta_CP_ytm, 

        sum(Fees_sales_EUR_delta) as Fees_sales_EUR_delta_CP_ytm,
        sum(warranties_sales_EUR_delta) as warranties_sales_EUR_delta_CP_ytm,
        sum(returns_on_warranties_sales_EUR_delta) as returns_on_warranties_sales_EUR_delta_CP_ytm,
        sum(Fees_sales_EUR_delta) + sum(Rebates_sales_EUR_delta) + sum(warranties_sales_EUR_delta) + sum(returns_on_warranties_sales_EUR_delta) as F_R_W_sales_EUR_delta_CP_ytm,
        sum(returns_sales_EUR_delta) as returns_sales_EUR_delta_CP_ytm,
        sum(noncommercial_sales_EUR_delta) as noncommercial_sales_EUR_delta_CP_ytm,
        sum(integration_sales_EUR_delta) as integration_sales_EUR_delta_CP_ytm,

        sum(orders_sales_recurring_USD_CP) as orders_sales_recurring_USD_CP_ytm,
        sum(orders_sales_recurring_USD_PP) as orders_sales_recurring_USD_PP_ytm,

        sum(sales_amount_USD_CP) as sales_amount_USD_CP_ytm,
        sum(sales_amount_USD_PP) as sales_amount_USD_PP_ytm,

        sum(sales_amount_new_USD_CP) as sales_amount_new_USD_CP_ytm,
        sum(ifnull(sales_amount_lost_USD_CP,0)) as sales_amount_lost_USD_CP_ytm,
        sum(sales_amount_USD_delta) as sales_amount_USD_delta_CP_ytm, 

        sum(Fees_sales_USD_delta) as Fees_sales_USD_delta_CP_ytm,
        sum(warranties_sales_USD_delta) as warranties_sales_USD_delta_CP_ytm,
        sum(returns_on_warranties_sales_USD_delta) as returns_on_warranties_sales_USD_delta_CP_ytm,
        sum(Fees_sales_USD_delta) + sum(Rebates_sales_USD_delta) + sum(warranties_sales_USD_delta) + sum(returns_on_warranties_sales_USD_delta) as F_R_W_sales_USD_delta_CP_ytm,
        sum(returns_sales_USD_delta) as returns_sales_USD_delta_CP_ytm,
        sum(noncommercial_sales_USD_delta) as noncommercial_sales_USD_delta_CP_ytm,
        sum(integration_sales_USD_delta) as integration_sales_USD_delta_CP_ytm,  

        sum(orders_sales_recurring_CAD_CP) as orders_sales_recurring_CAD_CP_ytm,
        sum(orders_sales_recurring_CAD_PP) as orders_sales_recurring_CAD_PP_ytm,

        sum(sales_amount_CAD_CP) as sales_amount_CAD_CP_ytm,
        sum(sales_amount_CAD_PP) as sales_amount_CAD_PP_ytm,

        sum(sales_amount_new_CAD_CP) as sales_amount_new_CAD_CP_ytm,
        sum(ifnull(sales_amount_lost_CAD_CP,0)) as sales_amount_lost_CAD_CP_ytm,
        sum(sales_amount_CAD_delta) as sales_amount_CAD_delta_CP_ytm, 

        sum(Fees_sales_CAD_delta) as Fees_sales_CAD_delta_CP_ytm,
        sum(warranties_sales_CAD_delta) as warranties_sales_CAD_delta_CP_ytm,
        sum(returns_on_warranties_sales_CAD_delta) as returns_on_warranties_sales_CAD_delta_CP_ytm,
        sum(Fees_sales_CAD_delta) + sum(Rebates_sales_CAD_delta) + sum(warranties_sales_CAD_delta) + sum(returns_on_warranties_sales_CAD_delta) as F_R_W_sales_CAD_delta_CP_ytm,
        sum(returns_sales_CAD_delta) as returns_sales_CAD_delta_CP_ytm,
        sum(noncommercial_sales_CAD_delta) as noncommercial_sales_CAD_delta_CP_ytm,
        sum(integration_sales_CAD_delta) as integration_sales_CAD_delta_CP_ytm,

        sum(orders_sales_recurring_MXN_CP) as orders_sales_recurring_MXN_CP_ytm,
        sum(orders_sales_recurring_MXN_PP) as orders_sales_recurring_MXN_PP_ytm,

        sum(sales_amount_MXN_CP) as sales_amount_MXN_CP_ytm,
        sum(sales_amount_MXN_PP) as sales_amount_MXN_PP_ytm,

        sum(sales_amount_new_MXN_CP) as sales_amount_new_MXN_CP_ytm,
        sum(ifnull(sales_amount_lost_MXN_CP,0)) as sales_amount_lost_MXN_CP_ytm,
        sum(sales_amount_MXN_delta) as sales_amount_MXN_delta_CP_ytm, 

        sum(Fees_sales_MXN_delta) as Fees_sales_MXN_delta_CP_ytm,
        sum(warranties_sales_MXN_delta) as warranties_sales_MXN_delta_CP_ytm,
        sum(returns_on_warranties_sales_MXN_delta) as returns_on_warranties_sales_MXN_delta_CP_ytm,
        sum(Fees_sales_MXN_delta) + sum(Rebates_sales_MXN_delta) + sum(warranties_sales_MXN_delta) + sum(returns_on_warranties_sales_MXN_delta) as F_R_W_sales_MXN_delta_CP_ytm,
        sum(returns_sales_MXN_delta) as returns_sales_MXN_delta_CP_ytm,
        sum(noncommercial_sales_MXN_delta) as noncommercial_sales_MXN_delta_CP_ytm,
        sum(integration_sales_MXN_delta) as integration_sales_MXN_delta_CP_ytm,  

        sum(orders_sales_recurring_BRL_CP) as orders_sales_recurring_BRL_CP_ytm,
        sum(orders_sales_recurring_BRL_PP) as orders_sales_recurring_BRL_PP_ytm,

        sum(sales_amount_BRL_CP) as sales_amount_BRL_CP_ytm,
        sum(sales_amount_BRL_PP) as sales_amount_BRL_PP_ytm,

        sum(sales_amount_new_BRL_CP) as sales_amount_new_BRL_CP_ytm,
        sum(ifnull(sales_amount_lost_BRL_CP,0)) as sales_amount_lost_BRL_CP_ytm,
        sum(sales_amount_BRL_delta) as sales_amount_BRL_delta_CP_ytm, 

        sum(Fees_sales_BRL_delta) as Fees_sales_BRL_delta_CP_ytm,
        sum(warranties_sales_BRL_delta) as warranties_sales_BRL_delta_CP_ytm,
        sum(returns_on_warranties_sales_BRL_delta) as returns_on_warranties_sales_BRL_delta_CP_ytm,
        sum(Fees_sales_BRL_delta) + sum(Rebates_sales_BRL_delta) + sum(warranties_sales_BRL_delta) + sum(returns_on_warranties_sales_BRL_delta) as F_R_W_sales_BRL_delta_CP_ytm,
        sum(returns_sales_BRL_delta) as returns_sales_BRL_delta_CP_ytm,
        sum(noncommercial_sales_BRL_delta) as noncommercial_sales_BRL_delta_CP_ytm,
        sum(integration_sales_BRL_delta) as integration_sales_BRL_delta_CP_ytm,  

        # COST
        sum(cost_EUR_CP) as cost_EUR_CP_ytm,
        sum(cost_EUR_PP) as cost_EUR_PP_ytm,
        sum(orders_cost_EUR_CP) as orders_cost_EUR_CP_ytm,
        sum(orders_cost_EUR_PP) as orders_cost_EUR_PP_ytm,
        sum(orders_cost_recurring_EUR_CP) as orders_cost_recurring_EUR_CP_ytm,
        sum(orders_cost_recurring_EUR_PP) as orders_cost_recurring_EUR_PP_ytm,
        sum(cost_amount_new_EUR_CP) as cost_amount_new_EUR_CP_ytm,
        sum(ifnull(cost_amount_lost_EUR_CP,0)) as cost_amount_lost_EUR_CP_ytm,
        sum(Fees_cost_EUR_delta) as Fees_cost_EUR_delta_CP_ytm,
        sum(warranties_cost_EUR_delta) as warranties_cost_EUR_delta_CP_ytm,
        sum(returns_on_warranties_cost_EUR_delta) as returns_on_warranties_cost_EUR_delta_CP_ytm,
        sum(Fees_cost_EUR_delta) + sum(Rebates_cost_EUR_delta) + sum(warranties_cost_EUR_delta) + sum(returns_on_warranties_cost_EUR_delta) as F_R_W_cost_EUR_delta_CP_ytm,
        sum(returns_cost_EUR_delta) as returns_cost_EUR_delta_CP_ytm,
        sum(noncommercial_cost_EUR_delta) as noncommercial_cost_EUR_delta_CP_ytm,
        sum(integration_cost_EUR_delta) as integration_cost_EUR_delta_CP_ytm, 

        sum(cost_USD_CP) as cost_USD_CP_ytm,
        sum(cost_USD_PP) as cost_USD_PP_ytm,
        sum(orders_cost_USD_CP) as orders_cost_USD_CP_ytm,
        sum(orders_cost_USD_PP) as orders_cost_USD_PP_ytm,
        sum(orders_cost_recurring_USD_CP) as orders_cost_recurring_USD_CP_ytm,
        sum(orders_cost_recurring_USD_PP) as orders_cost_recurring_USD_PP_ytm,
        sum(cost_amount_new_USD_CP) as cost_amount_new_USD_CP_ytm,
        sum(ifnull(cost_amount_lost_USD_CP,0)) as cost_amount_lost_USD_CP_ytm,
        sum(Fees_cost_USD_delta) as Fees_cost_USD_delta_CP_ytm,
        sum(warranties_cost_USD_delta) as warranties_cost_USD_delta_CP_ytm,
        sum(returns_on_warranties_cost_USD_delta) as returns_on_warranties_cost_USD_delta_CP_ytm,
        sum(Fees_cost_USD_delta) + sum(Rebates_cost_USD_delta) + sum(warranties_cost_USD_delta) + sum(returns_on_warranties_cost_USD_delta) as F_R_W_cost_USD_delta_CP_ytm,
        sum(returns_cost_USD_delta) as returns_cost_USD_delta_CP_ytm,
        sum(noncommercial_cost_USD_delta) as noncommercial_cost_USD_delta_CP_ytm,
        sum(integration_cost_USD_delta) as integration_cost_USD_delta_CP_ytm, 

        sum(cost_CAD_CP) as cost_CAD_CP_ytm,
        sum(cost_CAD_PP) as cost_CAD_PP_ytm,
        sum(orders_cost_CAD_CP) as orders_cost_CAD_CP_ytm,
        sum(orders_cost_CAD_PP) as orders_cost_CAD_PP_ytm,
        sum(orders_cost_recurring_CAD_CP) as orders_cost_recurring_CAD_CP_ytm,
        sum(orders_cost_recurring_CAD_PP) as orders_cost_recurring_CAD_PP_ytm,
        sum(cost_amount_new_CAD_CP) as cost_amount_new_CAD_CP_ytm,
        sum(ifnull(cost_amount_lost_CAD_CP,0)) as cost_amount_lost_CAD_CP_ytm,
        sum(Fees_cost_CAD_delta) as Fees_cost_CAD_delta_CP_ytm,
        sum(warranties_cost_CAD_delta) as warranties_cost_CAD_delta_CP_ytm,
        sum(returns_on_warranties_cost_CAD_delta) as returns_on_warranties_cost_CAD_delta_CP_ytm,
        sum(Fees_cost_CAD_delta) + sum(Rebates_cost_CAD_delta) + sum(warranties_cost_CAD_delta) + sum(returns_on_warranties_cost_CAD_delta) as F_R_W_cost_CAD_delta_CP_ytm,
        sum(returns_cost_CAD_delta) as returns_cost_CAD_delta_CP_ytm,
        sum(noncommercial_cost_CAD_delta) as noncommercial_cost_CAD_delta_CP_ytm,
        sum(integration_cost_CAD_delta) as integration_cost_CAD_delta_CP_ytm, 

        sum(cost_MXN_CP) as cost_MXN_CP_ytm,
        sum(cost_MXN_PP) as cost_MXN_PP_ytm,
        sum(orders_cost_MXN_CP) as orders_cost_MXN_CP_ytm,
        sum(orders_cost_MXN_PP) as orders_cost_MXN_PP_ytm,
        sum(orders_cost_recurring_MXN_CP) as orders_cost_recurring_MXN_CP_ytm,
        sum(orders_cost_recurring_MXN_PP) as orders_cost_recurring_MXN_PP_ytm,
        sum(cost_amount_new_MXN_CP) as cost_amount_new_MXN_CP_ytm,
        sum(ifnull(cost_amount_lost_MXN_CP,0)) as cost_amount_lost_MXN_CP_ytm,
        sum(Fees_cost_MXN_delta) as Fees_cost_MXN_delta_CP_ytm,
        sum(warranties_cost_MXN_delta) as warranties_cost_MXN_delta_CP_ytm,
        sum(returns_on_warranties_cost_MXN_delta) as returns_on_warranties_cost_MXN_delta_CP_ytm,
        sum(Fees_cost_MXN_delta) + sum(Rebates_cost_MXN_delta) + sum(warranties_cost_MXN_delta) + sum(returns_on_warranties_cost_MXN_delta) as F_R_W_cost_MXN_delta_CP_ytm,
        sum(returns_cost_MXN_delta) as returns_cost_MXN_delta_CP_ytm,
        sum(noncommercial_cost_MXN_delta) as noncommercial_cost_MXN_delta_CP_ytm,
        sum(integration_cost_MXN_delta) as integration_cost_MXN_delta_CP_ytm, 

        sum(cost_BRL_CP) as cost_BRL_CP_ytm,
        sum(cost_BRL_PP) as cost_BRL_PP_ytm,
        sum(orders_cost_BRL_CP) as orders_cost_BRL_CP_ytm,
        sum(orders_cost_BRL_PP) as orders_cost_BRL_PP_ytm,
        sum(orders_cost_recurring_BRL_CP) as orders_cost_recurring_BRL_CP_ytm,
        sum(orders_cost_recurring_BRL_PP) as orders_cost_recurring_BRL_PP_ytm,
        sum(cost_amount_new_BRL_CP) as cost_amount_new_BRL_CP_ytm,
        sum(ifnull(cost_amount_lost_BRL_CP,0)) as cost_amount_lost_BRL_CP_ytm,
        sum(Fees_cost_BRL_delta) as Fees_cost_BRL_delta_CP_ytm,
        sum(warranties_cost_BRL_delta) as warranties_cost_BRL_delta_CP_ytm,
        sum(returns_on_warranties_cost_BRL_delta) as returns_on_warranties_cost_BRL_delta_CP_ytm,
        sum(Fees_cost_BRL_delta) + sum(Rebates_cost_BRL_delta) + sum(warranties_cost_BRL_delta) + sum(returns_on_warranties_cost_BRL_delta) as F_R_W_cost_BRL_delta_CP_ytm,
        sum(returns_cost_BRL_delta) as returns_cost_BRL_delta_CP_ytm,
        sum(noncommercial_cost_BRL_delta) as noncommercial_cost_BRL_delta_CP_ytm,
        sum(integration_cost_BRL_delta) as integration_cost_BRL_delta_CP_ytm, 

        # COST LANDED
        sum(cost_landed_EUR_CP) as cost_landed_EUR_CP_ytm,
        sum(cost_landed_EUR_PP) as cost_landed_EUR_PP_ytm,
        sum(orders_cost_landed_EUR_CP) as orders_cost_landed_EUR_CP_ytm,
        sum(orders_cost_landed_EUR_PP) as orders_cost_landed_EUR_PP_ytm,
        sum(orders_cost_landed_recurring_EUR_CP) as orders_cost_landed_recurring_EUR_CP_ytm,
        sum(orders_cost_landed_recurring_EUR_PP) as orders_cost_landed_recurring_EUR_PP_ytm,
        sum(cost_landed_amount_new_EUR_CP) as cost_landed_amount_new_EUR_CP_ytm,
        sum(ifnull(cost_landed_amount_lost_EUR_CP,0)) as cost_landed_amount_lost_EUR_CP_ytm,
        sum(Fees_cost_landed_EUR_delta) as Fees_cost_landed_EUR_delta_CP_ytm,
        sum(warranties_cost_landed_EUR_delta) as warranties_cost_landed_EUR_delta_CP_ytm,
        sum(returns_on_warranties_cost_landed_EUR_delta) as returns_on_warranties_cost_landed_EUR_delta_CP_ytm,
        sum(Fees_cost_landed_EUR_delta) + sum(Rebates_cost_landed_EUR_delta) + sum(warranties_cost_landed_EUR_delta) + sum(returns_on_warranties_cost_landed_EUR_delta) as F_R_W_cost_landed_EUR_delta_CP_ytm,
        sum(returns_cost_landed_EUR_delta) as returns_cost_landed_EUR_delta_CP_ytm,
        sum(noncommercial_cost_landed_EUR_delta) as noncommercial_cost_landed_EUR_delta_CP_ytm,
        sum(integration_cost_landed_EUR_delta) as integration_cost_landed_EUR_delta_CP_ytm,

        sum(cost_landed_USD_CP) as cost_landed_USD_CP_ytm,
        sum(cost_landed_USD_PP) as cost_landed_USD_PP_ytm,
        sum(orders_cost_landed_USD_CP) as orders_cost_landed_USD_CP_ytm,
        sum(orders_cost_landed_USD_PP) as orders_cost_landed_USD_PP_ytm,
        sum(orders_cost_landed_recurring_USD_CP) as orders_cost_landed_recurring_USD_CP_ytm,
        sum(orders_cost_landed_recurring_USD_PP) as orders_cost_landed_recurring_USD_PP_ytm,
        sum(cost_landed_amount_new_USD_CP) as cost_landed_amount_new_USD_CP_ytm,
        sum(ifnull(cost_landed_amount_lost_USD_CP,0)) as cost_landed_amount_lost_USD_CP_ytm,
        sum(Fees_cost_landed_USD_delta) as Fees_cost_landed_USD_delta_CP_ytm,
        sum(warranties_cost_landed_USD_delta) as warranties_cost_landed_USD_delta_CP_ytm,
        sum(returns_on_warranties_cost_landed_USD_delta) as returns_on_warranties_cost_landed_USD_delta_CP_ytm,
        sum(Fees_cost_landed_USD_delta) + sum(Rebates_cost_landed_USD_delta) + sum(warranties_cost_landed_USD_delta) + sum(returns_on_warranties_cost_landed_USD_delta) as F_R_W_cost_landed_USD_delta_CP_ytm,
        sum(returns_cost_landed_USD_delta) as returns_cost_landed_USD_delta_CP_ytm,
        sum(noncommercial_cost_landed_USD_delta) as noncommercial_cost_landed_USD_delta_CP_ytm,
        sum(integration_cost_landed_USD_delta) as integration_cost_landed_USD_delta_CP_ytm,


        sum(cost_landed_CAD_CP) as cost_landed_CAD_CP_ytm,
        sum(cost_landed_CAD_PP) as cost_landed_CAD_PP_ytm,
        sum(orders_cost_landed_CAD_CP) as orders_cost_landed_CAD_CP_ytm,
        sum(orders_cost_landed_CAD_PP) as orders_cost_landed_CAD_PP_ytm,
        sum(orders_cost_landed_recurring_CAD_CP) as orders_cost_landed_recurring_CAD_CP_ytm,
        sum(orders_cost_landed_recurring_CAD_PP) as orders_cost_landed_recurring_CAD_PP_ytm,
        sum(cost_landed_amount_new_CAD_CP) as cost_landed_amount_new_CAD_CP_ytm,
        sum(ifnull(cost_landed_amount_lost_CAD_CP,0)) as cost_landed_amount_lost_CAD_CP_ytm,
        sum(Fees_cost_landed_CAD_delta) as Fees_cost_landed_CAD_delta_CP_ytm,
        sum(warranties_cost_landed_CAD_delta) as warranties_cost_landed_CAD_delta_CP_ytm,
        sum(returns_on_warranties_cost_landed_CAD_delta) as returns_on_warranties_cost_landed_CAD_delta_CP_ytm,
        sum(Fees_cost_landed_CAD_delta) + sum(Rebates_cost_landed_CAD_delta) + sum(warranties_cost_landed_CAD_delta) + sum(returns_on_warranties_cost_landed_CAD_delta) as F_R_W_cost_landed_CAD_delta_CP_ytm,
        sum(returns_cost_landed_CAD_delta) as returns_cost_landed_CAD_delta_CP_ytm,
        sum(noncommercial_cost_landed_CAD_delta) as noncommercial_cost_landed_CAD_delta_CP_ytm,
        sum(integration_cost_landed_CAD_delta) as integration_cost_landed_CAD_delta_CP_ytm,

        sum(cost_landed_MXN_CP) as cost_landed_MXN_CP_ytm,
        sum(cost_landed_MXN_PP) as cost_landed_MXN_PP_ytm,
        sum(orders_cost_landed_MXN_CP) as orders_cost_landed_MXN_CP_ytm,
        sum(orders_cost_landed_MXN_PP) as orders_cost_landed_MXN_PP_ytm,
        sum(orders_cost_landed_recurring_MXN_CP) as orders_cost_landed_recurring_MXN_CP_ytm,
        sum(orders_cost_landed_recurring_MXN_PP) as orders_cost_landed_recurring_MXN_PP_ytm,
        sum(cost_landed_amount_new_MXN_CP) as cost_landed_amount_new_MXN_CP_ytm,
        sum(ifnull(cost_landed_amount_lost_MXN_CP,0)) as cost_landed_amount_lost_MXN_CP_ytm,
        sum(Fees_cost_landed_MXN_delta) as Fees_cost_landed_MXN_delta_CP_ytm,
        sum(warranties_cost_landed_MXN_delta) as warranties_cost_landed_MXN_delta_CP_ytm,
        sum(returns_on_warranties_cost_landed_MXN_delta) as returns_on_warranties_cost_landed_MXN_delta_CP_ytm,
        sum(Fees_cost_landed_MXN_delta) + sum(Rebates_cost_landed_MXN_delta) + sum(warranties_cost_landed_MXN_delta) + sum(returns_on_warranties_cost_landed_MXN_delta) as F_R_W_cost_landed_MXN_delta_CP_ytm,
        sum(returns_cost_landed_MXN_delta) as returns_cost_landed_MXN_delta_CP_ytm,
        sum(noncommercial_cost_landed_MXN_delta) as noncommercial_cost_landed_MXN_delta_CP_ytm,
        sum(integration_cost_landed_MXN_delta) as integration_cost_landed_MXN_delta_CP_ytm,

        sum(cost_landed_BRL_CP) as cost_landed_BRL_CP_ytm,
        sum(cost_landed_BRL_PP) as cost_landed_BRL_PP_ytm,
        sum(orders_cost_landed_BRL_CP) as orders_cost_landed_BRL_CP_ytm,
        sum(orders_cost_landed_BRL_PP) as orders_cost_landed_BRL_PP_ytm,
        sum(orders_cost_landed_recurring_BRL_CP) as orders_cost_landed_recurring_BRL_CP_ytm,
        sum(orders_cost_landed_recurring_BRL_PP) as orders_cost_landed_recurring_BRL_PP_ytm,
        sum(cost_landed_amount_new_BRL_CP) as cost_landed_amount_new_BRL_CP_ytm,
        sum(ifnull(cost_landed_amount_lost_BRL_CP,0)) as cost_landed_amount_lost_BRL_CP_ytm,
        sum(Fees_cost_landed_BRL_delta) as Fees_cost_landed_BRL_delta_CP_ytm,
        sum(warranties_cost_landed_BRL_delta) as warranties_cost_landed_BRL_delta_CP_ytm,
        sum(returns_on_warranties_cost_landed_BRL_delta) as returns_on_warranties_cost_landed_BRL_delta_CP_ytm,
        sum(Fees_cost_landed_BRL_delta) + sum(Rebates_cost_landed_BRL_delta) + sum(warranties_cost_landed_BRL_delta) + sum(returns_on_warranties_cost_landed_BRL_delta) as F_R_W_cost_landed_BRL_delta_CP_ytm,
        sum(returns_cost_landed_BRL_delta) as returns_cost_landed_BRL_delta_CP_ytm,
        sum(noncommercial_cost_landed_BRL_delta) as noncommercial_cost_landed_BRL_delta_CP_ytm,
        sum(integration_cost_landed_BRL_delta) as integration_cost_landed_BRL_delta_CP_ytm,


        # EFFECTS
        sum(sales_price_effect_EUR) as sales_price_effect_recurring_EUR_CP_ytm,
        sum(quantity_effect_sales_EUR) as quantity_effect_sales_recurring_EUR_CP_ytm,
        sum(quantity_effect_cost_EUR) as quantity_effect_cost_recurring_EUR_CP_ytm,
        sum(quantity_effect_cost_landed_EUR) as quantity_effect_cost_landed_recurring_EUR_CP_ytm,       
        sum(fx_effect_sales_EUR) as fx_effect_sales_recurring_EUR_CP_ytm,
        sum(cost_effect_EUR) as cost_effect_recurring_EUR_CP_ytm,
        sum(cost_landed_effect_EUR) as cost_landed_effect_recurring_EUR_CP_ytm,

        sum(sales_price_effect_USD) as sales_price_effect_recurring_USD_CP_ytm,
        sum(quantity_effect_sales_USD) as quantity_effect_sales_recurring_USD_CP_ytm,
        sum(quantity_effect_cost_USD) as quantity_effect_cost_recurring_USD_CP_ytm,
        sum(quantity_effect_cost_landed_USD) as quantity_effect_cost_landed_recurring_USD_CP_ytm,       
        sum(fx_effect_sales_USD) as fx_effect_sales_recurring_USD_CP_ytm,
        sum(cost_effect_USD) as cost_effect_recurring_USD_CP_ytm,
        sum(cost_landed_effect_USD) as cost_landed_effect_recurring_USD_CP_ytm,

        sum(sales_price_effect_CAD) as sales_price_effect_recurring_CAD_CP_ytm,
        sum(quantity_effect_sales_CAD) as quantity_effect_sales_recurring_CAD_CP_ytm,
        sum(quantity_effect_cost_CAD) as quantity_effect_cost_recurring_CAD_CP_ytm,
        sum(quantity_effect_cost_landed_CAD) as quantity_effect_cost_landed_recurring_CAD_CP_ytm,       
        sum(fx_effect_sales_CAD) as fx_effect_sales_recurring_CAD_CP_ytm,
        sum(cost_effect_CAD) as cost_effect_recurring_CAD_CP_ytm,
        sum(cost_landed_effect_CAD) as cost_landed_effect_recurring_CAD_CP_ytm,

        sum(sales_price_effect_MXN) as sales_price_effect_recurring_MXN_CP_ytm,
        sum(quantity_effect_sales_MXN) as quantity_effect_sales_recurring_MXN_CP_ytm,
        sum(quantity_effect_cost_MXN) as quantity_effect_cost_recurring_MXN_CP_ytm,
        sum(quantity_effect_cost_landed_MXN) as quantity_effect_cost_landed_recurring_MXN_CP_ytm,       
        sum(fx_effect_sales_MXN) as fx_effect_sales_recurring_MXN_CP_ytm,
        sum(cost_effect_MXN) as cost_effect_recurring_MXN_CP_ytm,
        sum(cost_landed_effect_MXN) as cost_landed_effect_recurring_MXN_CP_ytm,

        sum(sales_price_effect_BRL) as sales_price_effect_recurring_BRL_CP_ytm,
        sum(quantity_effect_sales_BRL) as quantity_effect_sales_recurring_BRL_CP_ytm,
        sum(quantity_effect_cost_BRL) as quantity_effect_cost_recurring_BRL_CP_ytm,
        sum(quantity_effect_cost_landed_BRL) as quantity_effect_cost_landed_recurring_BRL_CP_ytm,       
        sum(fx_effect_sales_BRL) as fx_effect_sales_recurring_BRL_CP_ytm,
        sum(cost_effect_BRL) as cost_effect_recurring_BRL_CP_ytm,
        sum(cost_landed_effect_BRL) as cost_landed_effect_recurring_BRL_CP_ytm,

      from step5_further_calculations_on_sku_level_and_aggregation_ytm_CP base
      group by all

),

-- GROWTH DECOMPOSITION | MoM and YTM values into one table (actuals and growth decomp values) ---------------------------------------------------------------------------------------------

growth_decomp_actuals_link as (

        select 

            'Actual' as record_source,
            mom.source_actuals,
            mom.equipment_market,
            mom.equipment_sub_market,
            mom.statistic_country,
            mom.statistic_country_iso,
            mom.product_category,
            mom.product_subcategory,
            mom.product_class,
            mom.product_type,
            mom.brm_grouping,
            mom.brm_grouping_sales_team,
            mom.TVH_no_Brand_code,
            mom.TVH_no_Brand_descr,
            mom.unit,
            mom.period,

            --- Sales
            orders_sales_recurring_EUR_CP_mom,
            orders_sales_recurring_EUR_PP_mom,
            sales_amount_EUR_CP_mom,
            sales_amount_EUR_PP_mom,
            sales_amount_new_EUR_CP_mom,
            sales_amount_lost_EUR_CP_mom,
            F_R_W_sales_EUR_delta_CP_mom,
            returns_sales_EUR_delta_CP_mom,
            noncommercial_sales_EUR_delta_CP_mom,
            integration_sales_EUR_delta_CP_mom,
            sales_price_effect_recurring_EUR_CP_mom,
            quantity_effect_sales_recurring_EUR_CP_mom,
            fx_effect_sales_recurring_EUR_CP_mom,
            orders_sales_recurring_EUR_CP_ytm,
            orders_sales_recurring_EUR_PP_ytm,
            sales_amount_EUR_CP_ytm,
            sales_amount_EUR_PP_ytm,
            sales_amount_new_EUR_CP_ytm,
            sales_amount_lost_EUR_CP_ytm,           
            F_R_W_sales_EUR_delta_CP_ytm,
            returns_sales_EUR_delta_CP_ytm,
            noncommercial_sales_EUR_delta_CP_ytm,
            integration_sales_EUR_delta_CP_ytm,          
            sales_price_effect_recurring_EUR_CP_ytm,
            quantity_effect_sales_recurring_EUR_CP_ytm,
            fx_effect_sales_recurring_EUR_CP_ytm,

            orders_sales_recurring_USD_CP_mom,
            orders_sales_recurring_USD_PP_mom,
            sales_amount_USD_CP_mom,
            sales_amount_USD_PP_mom,
            sales_amount_new_USD_CP_mom,
            sales_amount_lost_USD_CP_mom,
            F_R_W_sales_USD_delta_CP_mom,
            returns_sales_USD_delta_CP_mom,
            noncommercial_sales_USD_delta_CP_mom,
            integration_sales_USD_delta_CP_mom,
            sales_price_effect_recurring_USD_CP_mom,
            quantity_effect_sales_recurring_USD_CP_mom,
            fx_effect_sales_recurring_USD_CP_mom,
            orders_sales_recurring_USD_CP_ytm,
            orders_sales_recurring_USD_PP_ytm,
            sales_amount_USD_CP_ytm,
            sales_amount_USD_PP_ytm,
            sales_amount_new_USD_CP_ytm,
            sales_amount_lost_USD_CP_ytm,           
            F_R_W_sales_USD_delta_CP_ytm,
            returns_sales_USD_delta_CP_ytm,
            noncommercial_sales_USD_delta_CP_ytm,
            integration_sales_USD_delta_CP_ytm,          
            sales_price_effect_recurring_USD_CP_ytm,
            quantity_effect_sales_recurring_USD_CP_ytm,
            fx_effect_sales_recurring_USD_CP_ytm,

            orders_sales_recurring_CAD_CP_mom,
            orders_sales_recurring_CAD_PP_mom,
            sales_amount_CAD_CP_mom,
            sales_amount_CAD_PP_mom,
            sales_amount_new_CAD_CP_mom,
            sales_amount_lost_CAD_CP_mom,
            F_R_W_sales_CAD_delta_CP_mom,
            returns_sales_CAD_delta_CP_mom,
            noncommercial_sales_CAD_delta_CP_mom,
            integration_sales_CAD_delta_CP_mom,
            sales_price_effect_recurring_CAD_CP_mom,
            quantity_effect_sales_recurring_CAD_CP_mom,
            fx_effect_sales_recurring_CAD_CP_mom,
            orders_sales_recurring_CAD_CP_ytm,
            orders_sales_recurring_CAD_PP_ytm,
            sales_amount_CAD_CP_ytm,
            sales_amount_CAD_PP_ytm,
            sales_amount_new_CAD_CP_ytm,
            sales_amount_lost_CAD_CP_ytm,           
            F_R_W_sales_CAD_delta_CP_ytm,
            returns_sales_CAD_delta_CP_ytm,
            noncommercial_sales_CAD_delta_CP_ytm,
            integration_sales_CAD_delta_CP_ytm,          
            sales_price_effect_recurring_CAD_CP_ytm,
            quantity_effect_sales_recurring_CAD_CP_ytm,
            fx_effect_sales_recurring_CAD_CP_ytm,

            orders_sales_recurring_MXN_CP_mom,
            orders_sales_recurring_MXN_PP_mom,
            sales_amount_MXN_CP_mom,
            sales_amount_MXN_PP_mom,
            sales_amount_new_MXN_CP_mom,
            sales_amount_lost_MXN_CP_mom,
            F_R_W_sales_MXN_delta_CP_mom,
            returns_sales_MXN_delta_CP_mom,
            noncommercial_sales_MXN_delta_CP_mom,
            integration_sales_MXN_delta_CP_mom,
            sales_price_effect_recurring_MXN_CP_mom,
            quantity_effect_sales_recurring_MXN_CP_mom,
            fx_effect_sales_recurring_MXN_CP_mom,
            orders_sales_recurring_MXN_CP_ytm,
            orders_sales_recurring_MXN_PP_ytm,
            sales_amount_MXN_CP_ytm,
            sales_amount_MXN_PP_ytm,
            sales_amount_new_MXN_CP_ytm,
            sales_amount_lost_MXN_CP_ytm,           
            F_R_W_sales_MXN_delta_CP_ytm,
            returns_sales_MXN_delta_CP_ytm,
            noncommercial_sales_MXN_delta_CP_ytm,
            integration_sales_MXN_delta_CP_ytm,          
            sales_price_effect_recurring_MXN_CP_ytm,
            quantity_effect_sales_recurring_MXN_CP_ytm,
            fx_effect_sales_recurring_MXN_CP_ytm,

            orders_sales_recurring_BRL_CP_mom,
            orders_sales_recurring_BRL_PP_mom,
            sales_amount_BRL_CP_mom,
            sales_amount_BRL_PP_mom,
            sales_amount_new_BRL_CP_mom,
            sales_amount_lost_BRL_CP_mom,
            F_R_W_sales_BRL_delta_CP_mom,
            returns_sales_BRL_delta_CP_mom,
            noncommercial_sales_BRL_delta_CP_mom,
            integration_sales_BRL_delta_CP_mom,
            sales_price_effect_recurring_BRL_CP_mom,
            quantity_effect_sales_recurring_BRL_CP_mom,
            fx_effect_sales_recurring_BRL_CP_mom,
            orders_sales_recurring_BRL_CP_ytm,
            orders_sales_recurring_BRL_PP_ytm,
            sales_amount_BRL_CP_ytm,
            sales_amount_BRL_PP_ytm,
            sales_amount_new_BRL_CP_ytm,
            sales_amount_lost_BRL_CP_ytm,           
            F_R_W_sales_BRL_delta_CP_ytm,
            returns_sales_BRL_delta_CP_ytm,
            noncommercial_sales_BRL_delta_CP_ytm,
            integration_sales_BRL_delta_CP_ytm,          
            sales_price_effect_recurring_BRL_CP_ytm,
            quantity_effect_sales_recurring_BRL_CP_ytm,
            fx_effect_sales_recurring_BRL_CP_ytm,

            --- Cost (group)
            cost_EUR_CP_mom,
            cost_EUR_PP_mom,
            orders_cost_EUR_CP_mom,
            orders_cost_EUR_PP_mom,                      
            orders_cost_recurring_EUR_CP_mom,
            orders_cost_recurring_EUR_PP_mom,
            cost_amount_new_EUR_CP_mom,
            cost_amount_lost_EUR_CP_mom,
            F_R_W_cost_EUR_delta_CP_mom,
            returns_cost_EUR_delta_CP_mom,
            noncommercial_cost_EUR_delta_CP_mom,
            integration_cost_EUR_delta_CP_mom,          
            quantity_effect_cost_recurring_EUR_CP_mom,      
            cost_effect_recurring_EUR_CP_mom,
            cost_EUR_CP_ytm,
            cost_EUR_PP_ytm,
            orders_cost_EUR_CP_ytm,
            orders_cost_EUR_PP_ytm,          
            orders_cost_recurring_EUR_CP_ytm,
            orders_cost_recurring_EUR_PP_ytm,
            cost_amount_new_EUR_CP_ytm,
            cost_amount_lost_EUR_CP_ytm,
            F_R_W_cost_EUR_delta_CP_ytm,
            returns_cost_EUR_delta_CP_ytm,
            noncommercial_cost_EUR_delta_CP_ytm,
            integration_cost_EUR_delta_CP_ytm,           
            quantity_effect_cost_recurring_EUR_CP_ytm,         
            cost_effect_recurring_EUR_CP_ytm,

            cost_USD_CP_mom,
            cost_USD_PP_mom,
            orders_cost_USD_CP_mom,
            orders_cost_USD_PP_mom,                      
            orders_cost_recurring_USD_CP_mom,
            orders_cost_recurring_USD_PP_mom,
            cost_amount_new_USD_CP_mom,
            cost_amount_lost_USD_CP_mom,
            F_R_W_cost_USD_delta_CP_mom,
            returns_cost_USD_delta_CP_mom,
            noncommercial_cost_USD_delta_CP_mom,
            integration_cost_USD_delta_CP_mom,          
            quantity_effect_cost_recurring_USD_CP_mom,      
            cost_effect_recurring_USD_CP_mom,
            cost_USD_CP_ytm,
            cost_USD_PP_ytm,
            orders_cost_USD_CP_ytm,
            orders_cost_USD_PP_ytm,          
            orders_cost_recurring_USD_CP_ytm,
            orders_cost_recurring_USD_PP_ytm,
            cost_amount_new_USD_CP_ytm,
            cost_amount_lost_USD_CP_ytm,
            F_R_W_cost_USD_delta_CP_ytm,
            returns_cost_USD_delta_CP_ytm,
            noncommercial_cost_USD_delta_CP_ytm,
            integration_cost_USD_delta_CP_ytm,           
            quantity_effect_cost_recurring_USD_CP_ytm,         
            cost_effect_recurring_USD_CP_ytm,

            cost_CAD_CP_mom,
            cost_CAD_PP_mom,
            orders_cost_CAD_CP_mom,
            orders_cost_CAD_PP_mom,                      
            orders_cost_recurring_CAD_CP_mom,
            orders_cost_recurring_CAD_PP_mom,
            cost_amount_new_CAD_CP_mom,
            cost_amount_lost_CAD_CP_mom,
            F_R_W_cost_CAD_delta_CP_mom,
            returns_cost_CAD_delta_CP_mom,
            noncommercial_cost_CAD_delta_CP_mom,
            integration_cost_CAD_delta_CP_mom,          
            quantity_effect_cost_recurring_CAD_CP_mom,      
            cost_effect_recurring_CAD_CP_mom,
            cost_CAD_CP_ytm,
            cost_CAD_PP_ytm,
            orders_cost_CAD_CP_ytm,
            orders_cost_CAD_PP_ytm,          
            orders_cost_recurring_CAD_CP_ytm,
            orders_cost_recurring_CAD_PP_ytm,
            cost_amount_new_CAD_CP_ytm,
            cost_amount_lost_CAD_CP_ytm,
            F_R_W_cost_CAD_delta_CP_ytm,
            returns_cost_CAD_delta_CP_ytm,
            noncommercial_cost_CAD_delta_CP_ytm,
            integration_cost_CAD_delta_CP_ytm,           
            quantity_effect_cost_recurring_CAD_CP_ytm,         
            cost_effect_recurring_CAD_CP_ytm,

            cost_MXN_CP_mom,
            cost_MXN_PP_mom,
            orders_cost_MXN_CP_mom,
            orders_cost_MXN_PP_mom,                      
            orders_cost_recurring_MXN_CP_mom,
            orders_cost_recurring_MXN_PP_mom,
            cost_amount_new_MXN_CP_mom,
            cost_amount_lost_MXN_CP_mom,
            F_R_W_cost_MXN_delta_CP_mom,
            returns_cost_MXN_delta_CP_mom,
            noncommercial_cost_MXN_delta_CP_mom,
            integration_cost_MXN_delta_CP_mom,          
            quantity_effect_cost_recurring_MXN_CP_mom,      
            cost_effect_recurring_MXN_CP_mom,
            cost_MXN_CP_ytm,
            cost_MXN_PP_ytm,
            orders_cost_MXN_CP_ytm,
            orders_cost_MXN_PP_ytm,          
            orders_cost_recurring_MXN_CP_ytm,
            orders_cost_recurring_MXN_PP_ytm,
            cost_amount_new_MXN_CP_ytm,
            cost_amount_lost_MXN_CP_ytm,
            F_R_W_cost_MXN_delta_CP_ytm,
            returns_cost_MXN_delta_CP_ytm,
            noncommercial_cost_MXN_delta_CP_ytm,
            integration_cost_MXN_delta_CP_ytm,           
            quantity_effect_cost_recurring_MXN_CP_ytm,         
            cost_effect_recurring_MXN_CP_ytm,

            cost_BRL_CP_mom,
            cost_BRL_PP_mom,
            orders_cost_BRL_CP_mom,
            orders_cost_BRL_PP_mom,                      
            orders_cost_recurring_BRL_CP_mom,
            orders_cost_recurring_BRL_PP_mom,
            cost_amount_new_BRL_CP_mom,
            cost_amount_lost_BRL_CP_mom,
            F_R_W_cost_BRL_delta_CP_mom,
            returns_cost_BRL_delta_CP_mom,
            noncommercial_cost_BRL_delta_CP_mom,
            integration_cost_BRL_delta_CP_mom,          
            quantity_effect_cost_recurring_BRL_CP_mom,      
            cost_effect_recurring_BRL_CP_mom,
            cost_BRL_CP_ytm,
            cost_BRL_PP_ytm,
            orders_cost_BRL_CP_ytm,
            orders_cost_BRL_PP_ytm,          
            orders_cost_recurring_BRL_CP_ytm,
            orders_cost_recurring_BRL_PP_ytm,
            cost_amount_new_BRL_CP_ytm,
            cost_amount_lost_BRL_CP_ytm,
            F_R_W_cost_BRL_delta_CP_ytm,
            returns_cost_BRL_delta_CP_ytm,
            noncommercial_cost_BRL_delta_CP_ytm,
            integration_cost_BRL_delta_CP_ytm,           
            quantity_effect_cost_recurring_BRL_CP_ytm,         
            cost_effect_recurring_BRL_CP_ytm,

            --- Cost (group landed)
            cost_landed_EUR_CP_mom,
            cost_landed_EUR_PP_mom,
            orders_cost_landed_EUR_CP_mom,
            orders_cost_landed_EUR_PP_mom,
            orders_cost_landed_recurring_EUR_CP_mom,
            orders_cost_landed_recurring_EUR_PP_mom,
            cost_landed_amount_new_EUR_CP_mom,
            cost_landed_amount_lost_EUR_CP_mom,
            F_R_W_cost_landed_EUR_delta_CP_mom,
            returns_cost_landed_EUR_delta_CP_mom,
            noncommercial_cost_landed_EUR_delta_CP_mom,
            integration_cost_landed_EUR_delta_CP_mom,          
            quantity_effect_cost_landed_recurring_EUR_CP_mom,       
            cost_landed_effect_recurring_EUR_CP_mom,
            cost_landed_EUR_CP_ytm,
            cost_landed_EUR_PP_ytm,
            orders_cost_landed_EUR_CP_ytm,
            orders_cost_landed_EUR_PP_ytm,           
            orders_cost_landed_recurring_EUR_CP_ytm,
            orders_cost_landed_recurring_EUR_PP_ytm,
            cost_landed_amount_new_EUR_CP_ytm,
            cost_landed_amount_lost_EUR_CP_ytm,
            F_R_W_cost_landed_EUR_delta_CP_ytm,
            returns_cost_landed_EUR_delta_CP_ytm,
            noncommercial_cost_landed_EUR_delta_CP_ytm,
            integration_cost_landed_EUR_delta_CP_ytm,          
            quantity_effect_cost_landed_recurring_EUR_CP_ytm,         
            cost_landed_effect_recurring_EUR_CP_ytm,

            cost_landed_USD_CP_mom,
            cost_landed_USD_PP_mom,
            orders_cost_landed_USD_CP_mom,
            orders_cost_landed_USD_PP_mom,
            orders_cost_landed_recurring_USD_CP_mom,
            orders_cost_landed_recurring_USD_PP_mom,
            cost_landed_amount_new_USD_CP_mom,
            cost_landed_amount_lost_USD_CP_mom,
            F_R_W_cost_landed_USD_delta_CP_mom,
            returns_cost_landed_USD_delta_CP_mom,
            noncommercial_cost_landed_USD_delta_CP_mom,
            integration_cost_landed_USD_delta_CP_mom,          
            quantity_effect_cost_landed_recurring_USD_CP_mom,       
            cost_landed_effect_recurring_USD_CP_mom,
            cost_landed_USD_CP_ytm,
            cost_landed_USD_PP_ytm,
            orders_cost_landed_USD_CP_ytm,
            orders_cost_landed_USD_PP_ytm,           
            orders_cost_landed_recurring_USD_CP_ytm,
            orders_cost_landed_recurring_USD_PP_ytm,
            cost_landed_amount_new_USD_CP_ytm,
            cost_landed_amount_lost_USD_CP_ytm,
            F_R_W_cost_landed_USD_delta_CP_ytm,
            returns_cost_landed_USD_delta_CP_ytm,
            noncommercial_cost_landed_USD_delta_CP_ytm,
            integration_cost_landed_USD_delta_CP_ytm,          
            quantity_effect_cost_landed_recurring_USD_CP_ytm,         
            cost_landed_effect_recurring_USD_CP_ytm,

            cost_landed_CAD_CP_mom,
            cost_landed_CAD_PP_mom,
            orders_cost_landed_CAD_CP_mom,
            orders_cost_landed_CAD_PP_mom,
            orders_cost_landed_recurring_CAD_CP_mom,
            orders_cost_landed_recurring_CAD_PP_mom,
            cost_landed_amount_new_CAD_CP_mom,
            cost_landed_amount_lost_CAD_CP_mom,
            F_R_W_cost_landed_CAD_delta_CP_mom,
            returns_cost_landed_CAD_delta_CP_mom,
            noncommercial_cost_landed_CAD_delta_CP_mom,
            integration_cost_landed_CAD_delta_CP_mom,          
            quantity_effect_cost_landed_recurring_CAD_CP_mom,       
            cost_landed_effect_recurring_CAD_CP_mom,
            cost_landed_CAD_CP_ytm,
            cost_landed_CAD_PP_ytm,
            orders_cost_landed_CAD_CP_ytm,
            orders_cost_landed_CAD_PP_ytm,           
            orders_cost_landed_recurring_CAD_CP_ytm,
            orders_cost_landed_recurring_CAD_PP_ytm,
            cost_landed_amount_new_CAD_CP_ytm,
            cost_landed_amount_lost_CAD_CP_ytm,
            F_R_W_cost_landed_CAD_delta_CP_ytm,
            returns_cost_landed_CAD_delta_CP_ytm,
            noncommercial_cost_landed_CAD_delta_CP_ytm,
            integration_cost_landed_CAD_delta_CP_ytm,          
            quantity_effect_cost_landed_recurring_CAD_CP_ytm,         
            cost_landed_effect_recurring_CAD_CP_ytm,

            cost_landed_MXN_CP_mom,
            cost_landed_MXN_PP_mom,
            orders_cost_landed_MXN_CP_mom,
            orders_cost_landed_MXN_PP_mom,
            orders_cost_landed_recurring_MXN_CP_mom,
            orders_cost_landed_recurring_MXN_PP_mom,
            cost_landed_amount_new_MXN_CP_mom,
            cost_landed_amount_lost_MXN_CP_mom,
            F_R_W_cost_landed_MXN_delta_CP_mom,
            returns_cost_landed_MXN_delta_CP_mom,
            noncommercial_cost_landed_MXN_delta_CP_mom,
            integration_cost_landed_MXN_delta_CP_mom,          
            quantity_effect_cost_landed_recurring_MXN_CP_mom,       
            cost_landed_effect_recurring_MXN_CP_mom,
            cost_landed_MXN_CP_ytm,
            cost_landed_MXN_PP_ytm,
            orders_cost_landed_MXN_CP_ytm,
            orders_cost_landed_MXN_PP_ytm,           
            orders_cost_landed_recurring_MXN_CP_ytm,
            orders_cost_landed_recurring_MXN_PP_ytm,
            cost_landed_amount_new_MXN_CP_ytm,
            cost_landed_amount_lost_MXN_CP_ytm,
            F_R_W_cost_landed_MXN_delta_CP_ytm,
            returns_cost_landed_MXN_delta_CP_ytm,
            noncommercial_cost_landed_MXN_delta_CP_ytm,
            integration_cost_landed_MXN_delta_CP_ytm,          
            quantity_effect_cost_landed_recurring_MXN_CP_ytm,         
            cost_landed_effect_recurring_MXN_CP_ytm,

            cost_landed_BRL_CP_mom,
            cost_landed_BRL_PP_mom,
            orders_cost_landed_BRL_CP_mom,
            orders_cost_landed_BRL_PP_mom,
            orders_cost_landed_recurring_BRL_CP_mom,
            orders_cost_landed_recurring_BRL_PP_mom,
            cost_landed_amount_new_BRL_CP_mom,
            cost_landed_amount_lost_BRL_CP_mom,
            F_R_W_cost_landed_BRL_delta_CP_mom,
            returns_cost_landed_BRL_delta_CP_mom,
            noncommercial_cost_landed_BRL_delta_CP_mom,
            integration_cost_landed_BRL_delta_CP_mom,          
            quantity_effect_cost_landed_recurring_BRL_CP_mom,       
            cost_landed_effect_recurring_BRL_CP_mom,
            cost_landed_BRL_CP_ytm,
            cost_landed_BRL_PP_ytm,
            orders_cost_landed_BRL_CP_ytm,
            orders_cost_landed_BRL_PP_ytm,           
            orders_cost_landed_recurring_BRL_CP_ytm,
            orders_cost_landed_recurring_BRL_PP_ytm,
            cost_landed_amount_new_BRL_CP_ytm,
            cost_landed_amount_lost_BRL_CP_ytm,
            F_R_W_cost_landed_BRL_delta_CP_ytm,
            returns_cost_landed_BRL_delta_CP_ytm,
            noncommercial_cost_landed_BRL_delta_CP_ytm,
            integration_cost_landed_BRL_delta_CP_ytm,          
            quantity_effect_cost_landed_recurring_BRL_CP_ytm,         
            cost_landed_effect_recurring_BRL_CP_ytm,

        from waterfall_final_output_countries_mom mom

            left join waterfall_final_output_countries_ytm ytm
              on mom.Period = ytm.Period
              and mom.equipment_sub_market = ytm.equipment_sub_market
              and mom.Statistic_country_iso = ytm.Statistic_country_iso
              and mom.product_subcategory = ytm.product_subcategory
              and mom.product_category = ytm.product_category
              and mom.product_class = ytm.product_class
              and mom.product_type = ytm.product_type
              and mom.brm_grouping = ytm.brm_grouping
              and mom.brm_grouping_sales_team = ytm.brm_grouping_sales_team
              and mom.TVH_no_Brand_code = ytm.TVH_no_Brand_code
              and mom.TVH_no_Brand_descr = ytm.TVH_no_Brand_descr
              and mom.unit = ytm.unit

)

-- FINAL SELECT | Adding geo hierarchy to the table, wordkays and the manual country grouping from the beginning ---------------------------------------------------------------------------------------------

  select 

      a.*,
      b.sls_super_region as Super_region,
      b.sls_macro_region as Macro_region,
      b.sls_region as Region,
      b.sls_sub_region as Sub_region,
      cm.Statistic_country_new as Statistic_country_budget,
      wd.workdays_month,
      brm.brm_grouping_sales_team as brm_grouping_sales_team_new,
      brm.brm_grouping_region,
      brm.brm_grouping_super_region,
      brm.brm_grouping_macro_region,
      brm.brm_grouping_macro_region_ext

  from growth_decomp_actuals_link a

    left join {{ref('stg_countries')}} b
    on a.statistic_country_iso = b.country_iso2code

    left join country_mapping cm
    on a.statistic_country_iso = cm.statistic_country_iso

    left join {{ref('stg_country_holiday')}} wd
    on  a.statistic_country_iso = wd.country_iso2code
    and a.period = wd.calendar_date

    left join
    (
      select
        distinct
        brm_grouping_sales_team_calc,
        brm_grouping_sales_team,
        brm_grouping_region,
        brm_grouping_super_region,
        brm_grouping_macro_region,
        brm_grouping_macro_region_ext
      from {{ref('int_brm_structure')}}
      where source_actuals = 'Link'
    ) brm
      on brm.brm_grouping_sales_team_calc = a.brm_grouping_sales_team






