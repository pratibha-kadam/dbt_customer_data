{{ config(
    materialized='table',
    partition_by={
      "field": "period",
      "data_type": "date",
      "granularity": "month"
    },
    cluster_by="sub_region"
) }}
-- int_actuals_and_budget_union.sql
with main as (
    select * from {{ ref('int_comal_actuals') }}
    union all
    select * from {{ ref('int_comal_budget') }}
)

select
    main.*,
    fx.budget_rate_eur_cy, fx.budget_rate_usd_cy, fx.budget_rate_brl_cy, fx.budget_rate_cad_cy, fx.budget_rate_mxn_cy,
    fx.budget_rate_eur_py, fx.budget_rate_usd_py, fx.budget_rate_brl_py, fx.budget_rate_cad_py, fx.budget_rate_mxn_py
from main
left join {{ ref('int_fx_budget_rates_cy_py') }} fx
    on main.currency_transaction = fx.currency_from


