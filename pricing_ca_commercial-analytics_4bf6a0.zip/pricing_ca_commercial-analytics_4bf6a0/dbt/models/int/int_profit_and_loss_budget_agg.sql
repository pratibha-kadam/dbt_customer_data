{#-
    Reporting currencies. BigQuery identifiers are case-insensitive, so lowercase
    here resolves against the mixed-case column definitions upstream
    (e.g. freight_expense_budget_EUR, budget_gaupl_link_EUR).
-#}
{%- set currencies = ['eur', 'usd', 'brl', 'cad', 'mxn'] -%}

{%- set effects = [
    'budget_price_effect',
    'budget_volume_effect',
    'budget_workday_effect',
    'budget_integration_effect',
    'budget_workday_effect_profit',
    'budget_volume_effect_profit',
    'budget_integration_effect_profit',
    'budget_cost_effect_profit',
    'budget_cost_landed_effect_profit'
] -%}

{%- set dimensions = [
    'period',
    'macro_region',
    'super_region',
    'region',
    'sub_region',
    'equipment_market',
    'equipment_sub_market',
    'statistic_country',
    'statistic_country_iso',
    'sales_channel_code',
    'sales_channel_description',
    'territory_for_sales_teams',
    'brm_grouping_sales_team_calc'
] -%}

with reporting_measures as (

 select "Net parts sales - LINK" as reporting_measure union all
 select "Net parts sales - NON LINK" as reporting_measure union all
 select "Net parts sales" as reporting_measure union all
 select "Operational freight income" as reporting_measure union all
 select "Total sales" as reporting_measure union all
 select "Group AUP" as reporting_measure union all
 select "Landed" as reporting_measure union all
 select "Group AUP Landed" as reporting_measure union all
 select "Adjusted gross profit" as reporting_measure union all
 select "Operational freight out" as reporting_measure union all
 select "Adjusted net gross profit" as reporting_measure union all
 select "Commercial profit" as reporting_measure union all
 select "Commercial margin" as reporting_measure union all
 select "Operational freight reclaim" as reporting_measure

),

expanded_structure as (

select * from {{ ref('int_profit_and_loss_budget') }}
cross join
reporting_measures

),

first_level as (
  select

    -- DIMENSIONS
    reporting_measure,
    source_actuals,
    {{ dimensions | join(',\n    ') }},

    -- MEASURES
{%- set fl = [] -%}
{%- for cur in currencies -%}
  {%- do fl.append("IF(source_actuals = 'Link', sum(ifnull(sales_budget_amount_" ~ cur ~ ", 0)), 0) as sales_budget_amount_link_" ~ cur) -%}
{%- endfor -%}
{%- for cur in currencies -%}
  {%- do fl.append("IF(source_actuals = 'Non-Link', sum(ifnull(sales_budget_amount_" ~ cur ~ ", 0)), 0) as sales_budget_amount_non_link_" ~ cur) -%}
{%- endfor -%}
{%- for col in ['freight_income_budget', 'freight_expense_budget', 'budget_gaupl'] -%}
  {%- for cur in currencies -%}
    {%- do fl.append("sum(ifnull(" ~ col ~ "_" ~ cur ~ ", 0)) as " ~ col ~ "_" ~ cur) -%}
  {%- endfor -%}
{%- endfor -%}
{%- for cur in currencies -%}
  {%- do fl.append("IF(source_actuals = 'Link', sum(ifnull(budget_gaupl_" ~ cur ~ ", 0)), 0) as budget_gaupl_link_" ~ cur) -%}
{%- endfor -%}
{%- for e in effects -%}
  {%- for cur in currencies -%}
    {%- do fl.append("sum(ifnull(" ~ e ~ "_" ~ cur ~ ", 0)) as " ~ e ~ "_" ~ cur) -%}
  {%- endfor -%}
{%- endfor %}
    {{ fl | join(',\n    ') }}

  from expanded_structure
  group by
    reporting_measure,
    source_actuals,
    {{ dimensions | join(',\n    ') }}
),

other_levels as (
  select
    -- DIMENSIONS
    reporting_measure,
    {{ dimensions | join(',\n    ') }},

    -- MEASURES 1ST LEVEL
{%- set ol = [] -%}
{%- for col in [
      'sales_budget_amount_link',
      'sales_budget_amount_non_link',
      'freight_income_budget',
      'freight_expense_budget',
      'budget_gaupl',
      'budget_gaupl_link'
    ] -%}
  {%- for cur in currencies -%}
    {%- do ol.append("sum(" ~ col ~ "_" ~ cur ~ ") as " ~ col ~ "_" ~ cur) -%}
  {%- endfor -%}
{%- endfor -%}
{%- for e in effects -%}
  {%- for cur in currencies -%}
    {%- do ol.append("sum(" ~ e ~ "_" ~ cur ~ ") as " ~ e ~ "_" ~ cur) -%}
  {%- endfor -%}
{%- endfor %}
    {{ ol | join(',\n    ') }},

    -- MEASURES 2ND LEVEL
{%- set l2 = [] -%}
{%- for cur in currencies -%}
  {%- do l2.append("sum(sales_budget_amount_link_" ~ cur ~ " + sales_budget_amount_non_link_" ~ cur ~ ") as net_parts_sales_budget_" ~ cur) -%}
{%- endfor -%}
{#-
    NOTE: commercial_profit_landed_budget_* is not selected downstream and uses a
    third GAUPL base (link sales - total GAUPL), agreeing with neither the source
    nor the final CASE. Left unchanged here so this refactor stays behaviour-
    identical; removal tracked separately. [TICKET]
-#}
{%- for cur in currencies -%}
  {%- do l2.append("sum(sales_budget_amount_link_" ~ cur ~ " - budget_gaupl_" ~ cur ~ ") as commercial_profit_landed_budget_" ~ cur) -%}
{%- endfor %}
    {{ l2 | join(',\n    ') }},

    -- MEASURES 3RD LEVEL
{%- set l3 = [] -%}
{%- for cur in currencies -%}
  {%- do l3.append("sum(sales_budget_amount_link_" ~ cur ~ " + sales_budget_amount_non_link_" ~ cur ~ " + freight_income_budget_" ~ cur ~ ") as total_sales_budget_" ~ cur) -%}
{%- endfor %}
    {{ l3 | join(',\n    ') }},

    -- MEASURES 4TH LEVEL
{%- set l4 = [] -%}
{%- for cur in currencies -%}
  {%- do l4.append("sum(sales_budget_amount_link_" ~ cur ~ " + sales_budget_amount_non_link_" ~ cur ~ " + freight_income_budget_" ~ cur ~ " - budget_gaupl_" ~ cur ~ ") as adjusted_gross_profit_budget_" ~ cur) -%}
{%- endfor %}
    {{ l4 | join(',\n    ') }},

    -- MEASURES 5TH LEVEL
{%- set l5 = [] -%}
{%- for cur in currencies -%}
  {%- do l5.append("sum(sales_budget_amount_link_" ~ cur ~ " + sales_budget_amount_non_link_" ~ cur ~ " + freight_income_budget_" ~ cur ~ " - budget_gaupl_" ~ cur ~ " - freight_expense_budget_" ~ cur ~ ") as adjusted_net_gross_profit_budget_" ~ cur) -%}
{%- endfor %}
    {{ l5 | join(',\n    ') }}

  from first_level
  group by
    reporting_measure,
    {{ dimensions | join(',\n    ') }}
)

select
  reporting_measure,
  {{ dimensions | join(',\n  ') }},

-- REPORTED BUDGET

{%- set nulls = [] -%}
{%- for prefix in ['reported', 'fx_neutral'] -%}
  {%- for cur in currencies -%}
    {%- do nulls.append("null as " ~ prefix ~ "_" ~ cur) -%}
  {%- endfor -%}
{%- endfor %}
  {{ nulls | join(',\n  ') }},

{% for cur in currencies %}
  case reporting_measure
    when 'Net parts sales - LINK' then sum(sales_budget_amount_link_{{ cur }})
    when 'Net parts sales - NON LINK' then sum(sales_budget_amount_non_link_{{ cur }})
    when 'Net parts sales' then sum(sales_budget_amount_link_{{ cur }}) + sum(sales_budget_amount_non_link_{{ cur }})
    when 'Operational freight income' then sum(freight_income_budget_{{ cur }})
    when 'Total sales' then sum(freight_income_budget_{{ cur }}) + sum(sales_budget_amount_link_{{ cur }}) + sum(sales_budget_amount_non_link_{{ cur }})
    when 'Group AUP' then null
    when 'Landed' then null

--        GAUPL is link-only. Matches budget_commercial_profit_* in
--        stg_financial_sales_budget and the link-only Commercial profit line.
--        Non-link GAUPL (TVPMO / TVH Parts Morocco only) is excluded. [TICKET]
  
    when 'Group AUP Landed' then sum(budget_gaupl_link_{{ cur }})
    when 'Adjusted gross profit' then sum(freight_income_budget_{{ cur }}) + sum(sales_budget_amount_link_{{ cur }}) + sum(sales_budget_amount_non_link_{{ cur }}) - sum(budget_gaupl_link_{{ cur }})
    when 'Operational freight out' then sum(freight_expense_budget_{{ cur }})
    when 'Adjusted net gross profit' then sum(freight_income_budget_{{ cur }}) + sum(sales_budget_amount_link_{{ cur }}) + sum(sales_budget_amount_non_link_{{ cur }}) - sum(budget_gaupl_link_{{ cur }}) - sum(freight_expense_budget_{{ cur }})
    when 'Commercial profit' then sum(sales_budget_amount_link_{{ cur }}) - sum(budget_gaupl_link_{{ cur }})
    when 'Commercial margin' then null -- It's a divison, has to be calculated in Tableau
    when 'Operational freight reclaim' then null -- It's a divison, has to be calculated in Tableau
  end as budget_{{ cur }},
{% endfor %}

{%- set final_effects = [] -%}
{%- for e in effects -%}
  {%- for cur in currencies -%}
    {%- do final_effects.append("sum(" ~ e ~ "_" ~ cur ~ ") as " ~ e ~ "_" ~ cur) -%}
  {%- endfor -%}
{%- endfor %}
  {{ final_effects | join(',\n  ') }}

from other_levels
where period >= '2026-01-01'
group by
  reporting_measure,
  {{ dimensions | join(',\n  ') }}