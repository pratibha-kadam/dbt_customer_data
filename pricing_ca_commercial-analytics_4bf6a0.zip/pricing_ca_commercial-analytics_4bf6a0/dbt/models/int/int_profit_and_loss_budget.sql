with sales_and_cost_budget as (

        select

          source_actuals,
          'Sales and cost budget' as data_type,
          budget_period as period,
          macro_region,
          super_region,
          region,
          sub_region,
          equipment_market,
          equipment_sub_market,
          statistic_country,
          statistic_country_iso,
          division,
          company_description,
          company_code,
          sales_channel_code,
          sales_channel_description,

          case
            when sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB') then sales_channel_description
            when sales_channel_code in ('TVH BE','BEPCO LA','SML') then statistic_country_iso
            when (source_actuals != 'Link' and company_code in ('GMPBE','UH','A7')) then 'PNS'
            else sub_region
          end as brm_grouping_sales_team_calc,       

          -- stg_financial_sales_budget carries no territory_code, so the key
          -- resolves on the company / ISO branches only. Link actuals CAN key
          -- on territory -- that divergence is documented in the ticket.
          {{ territory_for_sales_teams('cast(null as string)', 'company_code', 'statistic_country_iso') }}
              as territory_for_sales_teams,

          null as sales_amount_EUR,
          null as sales_amount_USD,
          null as sales_amount_BRL,
          null as sales_amount_CAD,
          null as sales_amount_MXN,

          null as sales_amount_fx_neutral_EUR,
          null as sales_amount_fx_neutral_USD,
          null as sales_amount_fx_neutral_BRL,
          null as sales_amount_fx_neutral_CAD,
          null as sales_amount_fx_neutral_MXN,                    

          null as freight_income_EUR,
          null as freight_income_USD,
          null as freight_income_BRL,
          null as freight_income_CAD,
          null as freight_income_MXN,

          null as freight_income_fx_neutral_EUR,
          null as freight_income_fx_neutral_USD,
          null as freight_income_fx_neutral_BRL,
          null as freight_income_fx_neutral_CAD,
          null as freight_income_fx_neutral_MXN,          

          null as freight_expense_system_EUR,
          null as freight_expense_system_USD,
          null as freight_expense_system_BRL,
          null as freight_expense_system_CAD,
          null as freight_expense_system_MXN,

          null as freight_expense_system_fx_neutral_EUR,
          null as freight_expense_system_fx_neutral_USD,
          null as freight_expense_system_fx_neutral_BRL,
          null as freight_expense_system_fx_neutral_CAD,
          null as freight_expense_system_fx_neutral_MXN,         

          null as cost_landed_EUR,
          null as cost_landed_USD,
          null as cost_landed_BRL,
          null as cost_landed_CAD,
          null as cost_landed_MXN,

          null as cost_landed_fx_neutral_EUR,
          null as cost_landed_fx_neutral_USD,
          null as cost_landed_fx_neutral_BRL,
          null as cost_landed_fx_neutral_CAD,
          null as cost_landed_fx_neutral_MXN,

          null as cost_EUR,
          null as cost_USD,
          null as cost_BRL,
          null as cost_CAD,
          null as cost_MXN,

          null as cost_fx_neutral_EUR,
          null as cost_fx_neutral_USD,
          null as cost_fx_neutral_BRL,
          null as cost_fx_neutral_CAD,
          null as cost_fx_neutral_MXN,

          budget_amount_EUR as sales_budget_amount_EUR,
          budget_amount_USD as sales_budget_amount_USD,
          budget_amount_BRL as sales_budget_amount_BRL,
          budget_amount_CAD as sales_budget_amount_CAD,
          budget_amount_MXN as sales_budget_amount_MXN,

          budget_commercial_profit_EUR as budget_profit_EUR,
          budget_commercial_profit_USD as budget_profit_USD,
          budget_commercial_profit_BRL as budget_profit_BRL,
          budget_commercial_profit_CAD as budget_profit_CAD,
          budget_commercial_profit_MXN as budget_profit_MXN,

          budget_gaupl_EUR as budget_gaupl_EUR,
          budget_gaupl_USD as budget_gaupl_USD,
          budget_gaupl_BRL as budget_gaupl_BRL,
          budget_gaupl_CAD as budget_gaupl_CAD,
          budget_gaupl_MXN as budget_gaupl_MXN,

          null as freight_income_budget_EUR,
          null as freight_income_budget_USD,
          null as freight_income_budget_BRL,
          null as freight_income_budget_CAD,
          null as freight_income_budget_MXN,

          null as freight_expense_budget_EUR,
          null as freight_expense_budget_USD,
          null as freight_expense_budget_BRL,
          null as freight_expense_budget_CAD,
          null as freight_expense_budget_MXN,               

          -- Price Effect
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, p_contribution_eur) as budget_price_effect_EUR,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, p_contribution_usd) as budget_price_effect_USD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, p_contribution_brl) as budget_price_effect_BRL,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, p_contribution_cad) as budget_price_effect_CAD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, p_contribution_mxn) as budget_price_effect_MXN,

          -- Volume Effect
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, q_contribution_eur) as budget_volume_effect_EUR,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, q_contribution_usd) as budget_volume_effect_USD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, q_contribution_brl) as budget_volume_effect_BRL,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, q_contribution_cad) as budget_volume_effect_CAD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, q_contribution_mxn) as budget_volume_effect_MXN,

          -- Workday Effect
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, wd_contribution_eur) as budget_workday_effect_EUR,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, wd_contribution_usd) as budget_workday_effect_USD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, wd_contribution_brl) as budget_workday_effect_BRL,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, wd_contribution_cad) as budget_workday_effect_CAD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, wd_contribution_mxn) as budget_workday_effect_MXN,

          -- Integration Effect
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, sales_integrations_effect_eur) as budget_integration_effect_EUR,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, sales_integrations_effect_usd) as budget_integration_effect_USD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, sales_integrations_effect_brl) as budget_integration_effect_BRL,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, sales_integrations_effect_cad) as budget_integration_effect_CAD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, sales_integrations_effect_mxn) as budget_integration_effect_MXN,

          -- Profit Workday Effect
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_wd_contribution_eur) as budget_workday_effect_profit_EUR,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_wd_contribution_usd) as budget_workday_effect_profit_USD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_wd_contribution_brl) as budget_workday_effect_profit_BRL,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_wd_contribution_cad) as budget_workday_effect_profit_CAD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_wd_contribution_mxn) as budget_workday_effect_profit_MXN,

          -- Profit Volume Effect
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_volume_effect_eur) as budget_volume_effect_profit_EUR,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_volume_effect_usd) as budget_volume_effect_profit_USD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_volume_effect_brl) as budget_volume_effect_profit_BRL,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_volume_effect_cad) as budget_volume_effect_profit_CAD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_volume_effect_mxn) as budget_volume_effect_profit_MXN,

          -- Profit Integration Effect
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_integrations_effect_eur) as budget_integration_effect_profit_EUR,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_integrations_effect_usd) as budget_integration_effect_profit_USD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_integrations_effect_brl) as budget_integration_effect_profit_BRL,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_integrations_effect_cad) as budget_integration_effect_profit_CAD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_integrations_effect_mxn) as budget_integration_effect_profit_MXN,

          -- Profit GAUP (Cost) Effect
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_gaup_effect_eur) as budget_cost_effect_profit_EUR,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_gaup_effect_usd) as budget_cost_effect_profit_USD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_gaup_effect_brl) as budget_cost_effect_profit_BRL,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_gaup_effect_cad) as budget_cost_effect_profit_CAD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_gaup_effect_mxn) as budget_cost_effect_profit_MXN,

          -- Profit Landed Cost Effect
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_landed_effect_eur) as budget_cost_landed_effect_profit_EUR,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_landed_effect_usd) as budget_cost_landed_effect_profit_USD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_landed_effect_brl) as budget_cost_landed_effect_profit_BRL,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_landed_effect_cad) as budget_cost_landed_effect_profit_CAD,
          IF(is_cab_glazing OR statistic_country_iso = 'MA' or source_actuals !='Link', 0, profit_landed_effect_mxn) as budget_cost_landed_effect_profit_MXN   

        from {{ref('stg_financial_sales_budget')}}
        where extract (year from budget_period) = 2026

),

freight_budget as (

        select

          cast(null as string) as source_actuals,
          'Freight budget' as data_type,
          budget_period as period,
          sls_macro_region as macro_region,
          sls_super_region as super_region,
          sls_region as region,
          sub_region,
          cast(null as string) as equipment_market,
          cast(null as string) as equipment_sub_market,
          cast(null as string) as statistic_country,
          cast(null as string) as statistic_country_iso,
          cast(null as string) as division,
          cast(null as string) as company_description,
          cast(null as string) as company_code,
          sales_channel_code as sales_channel_code,
          sales_channel_description as sales_channel_description,
          
          case
            when sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB','SML','TVH BE','BEPCO LA') then sales_channel_description
            else sub_region
          end as brm_grouping_sales_team_calc,                   

          -- statistic_country_iso and company_code are both NULL in this CTE,
          -- so the key is unavoidably NULL: freight budget cannot carry a
          -- sales team, freight actuals can. Pre-existing asymmetry (the same
          -- is already true of country); it now shows on this dimension too.
          cast(null as string) as territory_for_sales_teams,

          null as sales_amount_EUR,
          null as sales_amount_USD,
          null as sales_amount_BRL,
          null as sales_amount_CAD,
          null as sales_amount_MXN,

          null as sales_amount_fx_neutral_EUR,
          null as sales_amount_fx_neutral_USD,
          null as sales_amount_fx_neutral_BRL,
          null as sales_amount_fx_neutral_CAD,
          null as sales_amount_fx_neutral_MXN,                    

          null as freight_income_EUR,
          null as freight_income_USD,
          null as freight_income_BRL,
          null as freight_income_CAD,
          null as freight_income_MXN,

          null as freight_income_fx_neutral_EUR,
          null as freight_income_fx_neutral_USD,
          null as freight_income_fx_neutral_BRL,
          null as freight_income_fx_neutral_CAD,
          null as freight_income_fx_neutral_MXN,          

          null as freight_expense_system_EUR,
          null as freight_expense_system_USD,
          null as freight_expense_system_BRL,
          null as freight_expense_system_CAD,
          null as freight_expense_system_MXN,

          null as freight_expense_system_fx_neutral_EUR,
          null as freight_expense_system_fx_neutral_USD,
          null as freight_expense_system_fx_neutral_BRL,
          null as freight_expense_system_fx_neutral_CAD,
          null as freight_expense_system_fx_neutral_MXN,         

          null as cost_landed_EUR,
          null as cost_landed_USD,
          null as cost_landed_BRL,
          null as cost_landed_CAD,
          null as cost_landed_MXN,

          null as cost_landed_fx_neutral_EUR,
          null as cost_landed_fx_neutral_USD,
          null as cost_landed_fx_neutral_BRL,
          null as cost_landed_fx_neutral_CAD,
          null as cost_landed_fx_neutral_MXN,

          null as cost_EUR,
          null as cost_USD,
          null as cost_BRL,
          null as cost_CAD,
          null as cost_MXN,

          null as cost_fx_neutral_EUR,
          null as cost_fx_neutral_USD,
          null as cost_fx_neutral_BRL,
          null as cost_fx_neutral_CAD,
          null as cost_fx_neutral_MXN,

          null as sales_budget_amount_EUR,
          null as sales_budget_amount_USD,
          null as sales_budget_amount_BRL,
          null as sales_budget_amount_CAD,
          null as sales_budget_amount_MXN,

          null as budget_profit_EUR,
          null as budget_profit_USD,
          null as budget_profit_BRL,
          null as budget_profit_CAD,
          null as budget_profit_MXN,

          null as budget_gaupl_EUR,
          null as budget_gaupl_USD,
          null as budget_gaupl_BRL,
          null as budget_gaupl_CAD,
          null as budget_gaupl_MXN,

          freight_income_eur as freight_income_budget_EUR,
          freight_income_usd as freight_income_budget_USD,
          freight_income_brl as freight_income_budget_BRL,
          freight_income_cad as freight_income_budget_CAD,
          freight_income_mxn as freight_income_budget_MXN,

          freight_expense_eur as freight_expense_budget_EUR,
          freight_expense_usd as freight_expense_budget_USD,
          freight_expense_brl as freight_expense_budget_BRL,
          freight_expense_cad as freight_expense_budget_CAD,
          freight_expense_mxn as freight_expense_budget_MXN,           


          -- Price Effect
          NULL AS budget_price_effect_EUR,
          NULL AS budget_price_effect_USD,
          NULL AS budget_price_effect_BRL,
          NULL AS budget_price_effect_CAD,
          NULL AS budget_price_effect_MXN,

          -- Volume Effect
          NULL AS budget_volume_effect_EUR,
          NULL AS budget_volume_effect_USD,
          NULL AS budget_volume_effect_BRL,
          NULL AS budget_volume_effect_CAD,
          NULL AS budget_volume_effect_MXN,

          -- Workday Effect
          NULL AS budget_workday_effect_EUR,
          NULL AS budget_workday_effect_USD,
          NULL AS budget_workday_effect_BRL,
          NULL AS budget_workday_effect_CAD,
          NULL AS budget_workday_effect_MXN,

          -- Integration Effect
          NULL AS budget_integration_effect_EUR,
          NULL AS budget_integration_effect_USD,
          NULL AS budget_integration_effect_BRL,
          NULL AS budget_integration_effect_CAD,
          NULL AS budget_integration_effect_MXN,

          -- Profit Workday Effect
          NULL AS budget_workday_effect_profit_EUR,
          NULL AS budget_workday_effect_profit_USD,
          NULL AS budget_workday_effect_profit_BRL,
          NULL AS budget_workday_effect_profit_CAD,
          NULL AS budget_workday_effect_profit_MXN,

          -- Profit Volume Effect
          NULL AS budget_volume_effect_profit_EUR,
          NULL AS budget_volume_effect_profit_USD,
          NULL AS budget_volume_effect_profit_BRL,
          NULL AS budget_volume_effect_profit_CAD,
          NULL AS budget_volume_effect_profit_MXN,

          -- Profit Integration Effect
          NULL AS budget_integration_effect_profit_EUR,
          NULL AS budget_integration_effect_profit_USD,
          NULL AS budget_integration_effect_profit_BRL,
          NULL AS budget_integration_effect_profit_CAD,
          NULL AS budget_integration_effect_profit_MXN,

          -- Profit GAUP (Cost) Effect
          NULL AS budget_cost_effect_profit_EUR,
          NULL AS budget_cost_effect_profit_USD,
          NULL AS budget_cost_effect_profit_BRL,
          NULL AS budget_cost_effect_profit_CAD,
          NULL AS budget_cost_effect_profit_MXN,

          -- Profit Landed Cost Effect
          NULL AS budget_cost_landed_effect_profit_EUR,
          NULL AS budget_cost_landed_effect_profit_USD,
          NULL AS budget_cost_landed_effect_profit_BRL,
          NULL AS budget_cost_landed_effect_profit_CAD,
          NULL AS budget_cost_landed_effect_profit_MXN

        from {{ref('stg_operational_freight_budget')}}
        where extract (year from budget_period) = 2026

)

select * from sales_and_cost_budget
union all
select * from freight_budget