### https://docs.getdbt.com/docs/collaborate/documentation#using-docs-blocks

{% docs int_<table_name> %}

description of int\_<table_name> dfsdf

{% enddocs %}

{% docs fct_<table_name> %}

description of a fact table fct\_<table_name>

{% enddocs %}

{% docs dim_<table_name> %}

description of a dimension table dim\_<table_name>

{% enddocs %}
