{{ config(
    materialized='table',
    partition_by={
      "field": "period",
      "data_type": "date",
      "granularity": "month"
    },
    cluster_by="sub_region"
) }}

with freight_actuals as (

select 

          source_actuals,
          data_type,
          period,
          macro_region,
          super_region,
          region,
          sub_region,
          statistic_country,
          statistic_country_iso,
          sales_channel_code,
          sales_channel_description,

          brm_grouping_sales_team_calc,
          territory_for_sales_teams,

          freight_income_EUR,
          freight_income_USD,
          freight_income_BRL,
          freight_income_CAD,
          freight_income_MXN,

          freight_income_fx_neutral_EUR,
          freight_income_fx_neutral_USD,
          freight_income_fx_neutral_BRL,
          freight_income_fx_neutral_CAD,
          freight_income_fx_neutral_MXN,          

          freight_expense_system_EUR,
          freight_expense_system_USD,
          freight_expense_system_BRL,
          freight_expense_system_CAD,
          freight_expense_system_MXN,

          freight_expense_system_fx_neutral_EUR,
          freight_expense_system_fx_neutral_USD,
          freight_expense_system_fx_neutral_BRL,
          freight_expense_system_fx_neutral_CAD,
          freight_expense_system_fx_neutral_MXN,

          null as freight_income_budget_EUR,
          null as freight_income_budget_USD,
          null as freight_income_budget_BRL,
          null as freight_income_budget_CAD,
          null as freight_income_budget_MXN,

          null as freight_expense_budget_EUR,
          null as freight_expense_budget_USD,
          null as freight_expense_budget_BRL,
          null as freight_expense_budget_CAD,
          null as freight_expense_budget_MXN                    

FROM {{ref('int_profit_and_loss')}}
where (freight_income_EUR is not null or freight_expense_system_EUR is not null)

),

freight_budget as (

select

          source_actuals,
          data_type,
          period,
          macro_region,
          super_region,
          region,
          sub_region,
          statistic_country,
          statistic_country_iso,
          sales_channel_code,
          sales_channel_description,

          brm_grouping_sales_team_calc,
          territory_for_sales_teams,

          null as freight_income_EUR,
          null as freight_income_USD,
          null as freight_income_BRL,
          null as freight_income_CAD,
          null as freight_income_MXN,

          null as freight_income_fx_neutral_EUR,
          null as freight_income_fx_neutral_USD,
          null as freight_income_fx_neutral_BRL,
          null as freight_income_fx_neutral_CAD,
          null as freight_income_fx_neutral_MXN,          

          null as freight_expense_system_EUR,
          null as freight_expense_system_USD,
          null as freight_expense_system_BRL,
          null as freight_expense_system_CAD,
          null as freight_expense_system_MXN,

          null as freight_expense_system_fx_neutral_EUR,
          null as freight_expense_system_fx_neutral_USD,
          null as freight_expense_system_fx_neutral_BRL,
          null as freight_expense_system_fx_neutral_CAD,
          null as freight_expense_system_fx_neutral_MXN,

          freight_income_budget_EUR,
          freight_income_budget_USD,
          freight_income_budget_BRL,
          freight_income_budget_CAD,
          freight_income_budget_MXN,

          freight_expense_budget_EUR,
          freight_expense_budget_USD,
          freight_expense_budget_BRL,
          freight_expense_budget_CAD,
          freight_expense_budget_MXN          

from {{ref('int_profit_and_loss_budget')}}
where data_type = 'Freight budget'

),

main as (

select * from freight_actuals
union all
select * from freight_budget

)

select
      main.*,
      brm.brm_grouping_sales_team,
      brm.brm_grouping_region,
      brm.brm_grouping_super_region,
      brm.brm_grouping_macro_region,
      brm.brm_grouping_macro_region_ext,
      {{ sales_team_columns('stt') }}
from main

    left join
    (
      select
        distinct
        brm_grouping_sales_team_calc,
        brm_grouping_sales_team,
        brm_grouping_region,
        brm_grouping_super_region,
        brm_grouping_macro_region,
        brm_grouping_macro_region_ext
      from {{ref('int_brm_structure')}}
    ) brm
      on brm.brm_grouping_sales_team_calc = main.brm_grouping_sales_team_calc
    left join {{ ref('stg_territory_sales_teams') }} stt
      on stt.territory_for_salesteams_code = main.territory_for_sales_teams