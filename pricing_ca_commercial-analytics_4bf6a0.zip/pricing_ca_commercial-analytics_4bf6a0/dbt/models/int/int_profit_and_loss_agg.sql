with reporting_measures as (

 select "Net parts sales - LINK" as reporting_measure union all
 select "Net parts sales - NON LINK" as reporting_measure union all
 select "Net parts sales" as reporting_measure union all
 select "Operational freight income" as reporting_measure union all
 select "Total sales" as reporting_measure union all
 select "Group AUP" as reporting_measure union all
 select "Landed" as reporting_measure union all
 select "Group AUP Landed" as reporting_measure union all
 select "Adjusted gross profit" as reporting_measure union all
 select "Operational freight out" as reporting_measure union all
 select "Adjusted net gross profit" as reporting_measure union all
 select "Commercial profit" as reporting_measure union all
 select "Commercial margin" as reporting_measure union all
 select "Operational freight reclaim" as reporting_measure

),

expanded_structure as (

select * from {{ref('int_profit_and_loss')}}
cross join
reporting_measures

),

first_level as (
  select
    -- DIMENSIONS
    reporting_measure,
    source_actuals,
    period,
    macro_region,
    super_region,
    region,
    sub_region,
    equipment_market,
    equipment_sub_market,
    statistic_country,
    statistic_country_iso,
    sales_channel_code,
    sales_channel_description,
    territory_for_sales_teams,
    brm_grouping_sales_team_calc,

    -- MEASURES
    IF(source_actuals = 'Link', sum(ifnull(sales_amount_EUR, 0)), 0) as net_parts_sales_link_eur,
    IF(source_actuals = 'Link', sum(ifnull(sales_amount_USD, 0)), 0) as net_parts_sales_link_usd,
    IF(source_actuals = 'Link', sum(ifnull(sales_amount_BRL, 0)), 0) as net_parts_sales_link_brl,
    IF(source_actuals = 'Link', sum(ifnull(sales_amount_CAD, 0)), 0) as net_parts_sales_link_cad,
    IF(source_actuals = 'Link', sum(ifnull(sales_amount_MXN, 0)), 0) as net_parts_sales_link_mxn,

    IF(source_actuals = 'Link', sum(ifnull(sales_amount_fx_neutral_EUR, 0)), 0) as net_parts_sales_link_fx_neutral_eur,
    IF(source_actuals = 'Link', sum(ifnull(sales_amount_fx_neutral_USD, 0)), 0) as net_parts_sales_link_fx_neutral_usd,
    IF(source_actuals = 'Link', sum(ifnull(sales_amount_fx_neutral_BRL, 0)), 0) as net_parts_sales_link_fx_neutral_brl,
    IF(source_actuals = 'Link', sum(ifnull(sales_amount_fx_neutral_CAD, 0)), 0) as net_parts_sales_link_fx_neutral_cad,
    IF(source_actuals = 'Link', sum(ifnull(sales_amount_fx_neutral_MXN, 0)), 0) as net_parts_sales_link_fx_neutral_mxn,

    IF(source_actuals = 'Non-Link', sum(ifnull(sales_amount_EUR, 0)), 0) as net_parts_sales_non_link_eur,
    IF(source_actuals = 'Non-Link', sum(ifnull(sales_amount_USD, 0)), 0) as net_parts_sales_non_link_usd,
    IF(source_actuals = 'Non-Link', sum(ifnull(sales_amount_BRL, 0)), 0) as net_parts_sales_non_link_brl,
    IF(source_actuals = 'Non-Link', sum(ifnull(sales_amount_CAD, 0)), 0) as net_parts_sales_non_link_cad,
    IF(source_actuals = 'Non-Link', sum(ifnull(sales_amount_MXN, 0)), 0) as net_parts_sales_non_link_mxn,

    IF(source_actuals = 'Non-Link', sum(ifnull(sales_amount_fx_neutral_EUR, 0)), 0) as net_parts_sales_non_link_fx_neutral_eur,
    IF(source_actuals = 'Non-Link', sum(ifnull(sales_amount_fx_neutral_USD, 0)), 0) as net_parts_sales_non_link_fx_neutral_usd,
    IF(source_actuals = 'Non-Link', sum(ifnull(sales_amount_fx_neutral_BRL, 0)), 0) as net_parts_sales_non_link_fx_neutral_brl,
    IF(source_actuals = 'Non-Link', sum(ifnull(sales_amount_fx_neutral_CAD, 0)), 0) as net_parts_sales_non_link_fx_neutral_cad,
    IF(source_actuals = 'Non-Link', sum(ifnull(sales_amount_fx_neutral_MXN, 0)), 0) as net_parts_sales_non_link_fx_neutral_mxn,

    sum(ifnull(freight_income_EUR, 0)) as operational_freight_income_eur,
    sum(ifnull(freight_income_USD, 0)) as operational_freight_income_usd,
    sum(ifnull(freight_income_BRL, 0)) as operational_freight_income_brl,
    sum(ifnull(freight_income_CAD, 0)) as operational_freight_income_cad,
    sum(ifnull(freight_income_MXN, 0)) as operational_freight_income_mxn,

    sum(ifnull(freight_income_fx_neutral_EUR, 0)) as operational_freight_income_fx_neutral_eur,
    sum(ifnull(freight_income_fx_neutral_USD, 0)) as operational_freight_income_fx_neutral_usd,
    sum(ifnull(freight_income_fx_neutral_BRL, 0)) as operational_freight_income_fx_neutral_brl,
    sum(ifnull(freight_income_fx_neutral_CAD, 0)) as operational_freight_income_fx_neutral_cad,
    sum(ifnull(freight_income_fx_neutral_MXN, 0)) as operational_freight_income_fx_neutral_mxn,

    sum(ifnull(cost_EUR, 0)) as group_aup_eur,
    sum(ifnull(cost_USD, 0)) as group_aup_usd,
    sum(ifnull(cost_BRL, 0)) as group_aup_brl,
    sum(ifnull(cost_CAD, 0)) as group_aup_cad,
    sum(ifnull(cost_MXN, 0)) as group_aup_mxn,

    sum(ifnull(cost_fx_neutral_EUR, 0)) as group_aup_fx_neutral_eur,
    sum(ifnull(cost_fx_neutral_USD, 0)) as group_aup_fx_neutral_usd,
    sum(ifnull(cost_fx_neutral_BRL, 0)) as group_aup_fx_neutral_brl,
    sum(ifnull(cost_fx_neutral_CAD, 0)) as group_aup_fx_neutral_cad,
    sum(ifnull(cost_fx_neutral_MXN, 0)) as group_aup_fx_neutral_mxn,

    sum(ifnull(cost_landed_EUR, 0)) as group_aup_landed_eur,
    sum(ifnull(cost_landed_USD, 0)) as group_aup_landed_usd,
    sum(ifnull(cost_landed_BRL, 0)) as group_aup_landed_brl,
    sum(ifnull(cost_landed_CAD, 0)) as group_aup_landed_cad,
    sum(ifnull(cost_landed_MXN, 0)) as group_aup_landed_mxn,

    sum(ifnull(cost_landed_fx_neutral_EUR, 0)) as group_aup_landed_fx_neutral_eur,
    sum(ifnull(cost_landed_fx_neutral_USD, 0)) as group_aup_landed_fx_neutral_usd,
    sum(ifnull(cost_landed_fx_neutral_BRL, 0)) as group_aup_landed_fx_neutral_brl,
    sum(ifnull(cost_landed_fx_neutral_CAD, 0)) as group_aup_landed_fx_neutral_cad,
    sum(ifnull(cost_landed_fx_neutral_MXN, 0)) as group_aup_landed_fx_neutral_mxn, 

    sum(ifnull(freight_expense_system_EUR, 0)) as operational_freight_out_eur,
    sum(ifnull(freight_expense_system_USD, 0)) as operational_freight_out_usd,
    sum(ifnull(freight_expense_system_BRL, 0)) as operational_freight_out_brl,
    sum(ifnull(freight_expense_system_CAD, 0)) as operational_freight_out_cad,
    sum(ifnull(freight_expense_system_MXN, 0)) as operational_freight_out_mxn,

    sum(ifnull(freight_expense_system_fx_neutral_EUR, 0)) as operational_freight_out_fx_neutral_eur,
    sum(ifnull(freight_expense_system_fx_neutral_USD, 0)) as operational_freight_out_fx_neutral_usd,
    sum(ifnull(freight_expense_system_fx_neutral_BRL, 0)) as operational_freight_out_fx_neutral_brl,
    sum(ifnull(freight_expense_system_fx_neutral_CAD, 0)) as operational_freight_out_fx_neutral_cad,
    sum(ifnull(freight_expense_system_fx_neutral_MXN, 0)) as operational_freight_out_fx_neutral_mxn,
  from `expanded_structure`
  group by all
),

other_levels as (
  select
    -- DIMENSIONS
    reporting_measure,          
    period,
    macro_region,
    super_region,
    region,
    sub_region,
    equipment_market,
    equipment_sub_market,
    statistic_country,
    statistic_country_iso,
    sales_channel_code,
    sales_channel_description,
    territory_for_sales_teams,
    brm_grouping_sales_team_calc,

    -- MEASURES 1ST LEVEL
    sum(net_parts_sales_link_eur) as net_parts_sales_link_eur,
    sum(net_parts_sales_link_usd) as net_parts_sales_link_usd,
    sum(net_parts_sales_link_brl) as net_parts_sales_link_brl,
    sum(net_parts_sales_link_cad) as net_parts_sales_link_cad,
    sum(net_parts_sales_link_mxn) as net_parts_sales_link_mxn,

    sum(net_parts_sales_link_fx_neutral_eur) as net_parts_sales_link_fx_neutral_eur,
    sum(net_parts_sales_link_fx_neutral_usd) as net_parts_sales_link_fx_neutral_usd,
    sum(net_parts_sales_link_fx_neutral_brl) as net_parts_sales_link_fx_neutral_brl,
    sum(net_parts_sales_link_fx_neutral_cad) as net_parts_sales_link_fx_neutral_cad,
    sum(net_parts_sales_link_fx_neutral_mxn) as net_parts_sales_link_fx_neutral_mxn,

    sum(net_parts_sales_non_link_eur) as net_parts_sales_non_link_eur,
    sum(net_parts_sales_non_link_usd) as net_parts_sales_non_link_usd,
    sum(net_parts_sales_non_link_brl) as net_parts_sales_non_link_brl,
    sum(net_parts_sales_non_link_cad) as net_parts_sales_non_link_cad,
    sum(net_parts_sales_non_link_mxn) as net_parts_sales_non_link_mxn,

    sum(net_parts_sales_non_link_fx_neutral_eur) as net_parts_sales_non_link_fx_neutral_eur,
    sum(net_parts_sales_non_link_fx_neutral_usd) as net_parts_sales_non_link_fx_neutral_usd,
    sum(net_parts_sales_non_link_fx_neutral_brl) as net_parts_sales_non_link_fx_neutral_brl,
    sum(net_parts_sales_non_link_fx_neutral_cad) as net_parts_sales_non_link_fx_neutral_cad,
    sum(net_parts_sales_non_link_fx_neutral_mxn) as net_parts_sales_non_link_fx_neutral_mxn,

    sum(operational_freight_income_eur) as operational_freight_income_eur,
    sum(operational_freight_income_usd) as operational_freight_income_usd,
    sum(operational_freight_income_brl) as operational_freight_income_brl,
    sum(operational_freight_income_cad) as operational_freight_income_cad,
    sum(operational_freight_income_mxn) as operational_freight_income_mxn,

    sum(operational_freight_income_fx_neutral_eur) as operational_freight_income_fx_neutral_eur,
    sum(operational_freight_income_fx_neutral_usd) as operational_freight_income_fx_neutral_usd,
    sum(operational_freight_income_fx_neutral_brl) as operational_freight_income_fx_neutral_brl,
    sum(operational_freight_income_fx_neutral_cad) as operational_freight_income_fx_neutral_cad,
    sum(operational_freight_income_fx_neutral_mxn) as operational_freight_income_fx_neutral_mxn,

    sum(group_aup_eur) as group_aup_eur,
    sum(group_aup_usd) as group_aup_usd,
    sum(group_aup_brl) as group_aup_brl,
    sum(group_aup_cad) as group_aup_cad,
    sum(group_aup_mxn) as group_aup_mxn,

    sum(group_aup_fx_neutral_eur) as group_aup_fx_neutral_eur,
    sum(group_aup_fx_neutral_usd) as group_aup_fx_neutral_usd,
    sum(group_aup_fx_neutral_brl) as group_aup_fx_neutral_brl,
    sum(group_aup_fx_neutral_cad) as group_aup_fx_neutral_cad,
    sum(group_aup_fx_neutral_mxn) as group_aup_fx_neutral_mxn,

    sum(group_aup_landed_eur) as group_aup_landed_eur,
    sum(group_aup_landed_usd) as group_aup_landed_usd,
    sum(group_aup_landed_brl) as group_aup_landed_brl,
    sum(group_aup_landed_cad) as group_aup_landed_cad,
    sum(group_aup_landed_mxn) as group_aup_landed_mxn,

    sum(group_aup_landed_fx_neutral_eur) as group_aup_landed_fx_neutral_eur,
    sum(group_aup_landed_fx_neutral_usd) as group_aup_landed_fx_neutral_usd,
    sum(group_aup_landed_fx_neutral_brl) as group_aup_landed_fx_neutral_brl,
    sum(group_aup_landed_fx_neutral_cad) as group_aup_landed_fx_neutral_cad,
    sum(group_aup_landed_fx_neutral_mxn) as group_aup_landed_fx_neutral_mxn, 

    sum(operational_freight_out_eur) as operational_freight_out_eur,
    sum(operational_freight_out_usd) as operational_freight_out_usd,
    sum(operational_freight_out_brl) as operational_freight_out_brl,
    sum(operational_freight_out_cad) as operational_freight_out_cad,
    sum(operational_freight_out_mxn) as operational_freight_out_mxn,

    sum(operational_freight_out_fx_neutral_eur) as operational_freight_out_fx_neutral_eur,
    sum(operational_freight_out_fx_neutral_usd) as operational_freight_out_fx_neutral_usd,
    sum(operational_freight_out_fx_neutral_brl) as operational_freight_out_fx_neutral_brl,
    sum(operational_freight_out_fx_neutral_cad) as operational_freight_out_fx_neutral_cad,
    sum(operational_freight_out_fx_neutral_mxn) as operational_freight_out_fx_neutral_mxn,
         
    -- MEASURES 2ND LEVEL  
    sum(net_parts_sales_link_eur + net_parts_sales_non_link_eur) as net_parts_sales_eur,
    sum(net_parts_sales_link_usd + net_parts_sales_non_link_usd) as net_parts_sales_usd,
    sum(net_parts_sales_link_brl + net_parts_sales_non_link_brl) as net_parts_sales_brl,
    sum(net_parts_sales_link_cad + net_parts_sales_non_link_cad) as net_parts_sales_cad,
    sum(net_parts_sales_link_mxn + net_parts_sales_non_link_mxn) as net_parts_sales_mxn,

    sum(net_parts_sales_link_fx_neutral_eur + net_parts_sales_non_link_fx_neutral_eur) as net_parts_sales_fx_neutral_eur,
    sum(net_parts_sales_link_fx_neutral_usd + net_parts_sales_non_link_fx_neutral_usd) as net_parts_sales_fx_neutral_usd,
    sum(net_parts_sales_link_fx_neutral_brl + net_parts_sales_non_link_fx_neutral_brl) as net_parts_sales_fx_neutral_brl,
    sum(net_parts_sales_link_fx_neutral_cad + net_parts_sales_non_link_fx_neutral_cad) as net_parts_sales_fx_neutral_cad,
    sum(net_parts_sales_link_fx_neutral_mxn + net_parts_sales_non_link_fx_neutral_mxn) as net_parts_sales_fx_neutral_mxn,

    sum(group_aup_landed_eur - group_aup_eur) as landed_eur,
    sum(group_aup_landed_usd - group_aup_usd) as landed_usd,
    sum(group_aup_landed_brl - group_aup_brl) as landed_brl,
    sum(group_aup_landed_cad - group_aup_cad) as landed_cad,
    sum(group_aup_landed_mxn - group_aup_mxn) as landed_mxn, 

    sum(group_aup_landed_fx_neutral_eur - group_aup_fx_neutral_eur) as landed_fx_neutral_eur,
    sum(group_aup_landed_fx_neutral_usd - group_aup_fx_neutral_usd) as landed_fx_neutral_usd,
    sum(group_aup_landed_fx_neutral_brl - group_aup_fx_neutral_brl) as landed_fx_neutral_brl,
    sum(group_aup_landed_fx_neutral_cad - group_aup_fx_neutral_cad) as landed_fx_neutral_cad,
    sum(group_aup_landed_fx_neutral_mxn - group_aup_fx_neutral_mxn) as landed_fx_neutral_mxn,

    sum(net_parts_sales_link_eur - group_aup_landed_eur) as commercial_profit_landed_eur,
    sum(net_parts_sales_link_usd - group_aup_landed_usd) as commercial_profit_landed_usd,
    sum(net_parts_sales_link_brl - group_aup_landed_brl) as commercial_profit_landed_brl,
    sum(net_parts_sales_link_cad - group_aup_landed_cad) as commercial_profit_landed_cad,
    sum(net_parts_sales_link_mxn - group_aup_landed_mxn) as commercial_profit_landed_mxn, 

    sum(net_parts_sales_link_fx_neutral_eur - group_aup_landed_fx_neutral_eur) as commercial_profit_landed_fx_neutral_eur,
    sum(net_parts_sales_link_fx_neutral_usd - group_aup_landed_fx_neutral_usd) as commercial_profit_landed_fx_neutral_usd,
    sum(net_parts_sales_link_fx_neutral_brl - group_aup_landed_fx_neutral_brl) as commercial_profit_landed_fx_neutral_brl,
    sum(net_parts_sales_link_fx_neutral_cad - group_aup_landed_fx_neutral_cad) as commercial_profit_landed_fx_neutral_cad,
    sum(net_parts_sales_link_fx_neutral_mxn - group_aup_landed_fx_neutral_mxn) as commercial_profit_landed_fx_neutral_mxn,                                       
    
    -- MEASURES 3RD LEVEL                                               
    sum(net_parts_sales_link_eur + net_parts_sales_non_link_eur + operational_freight_income_eur) as total_sales_eur,
    sum(net_parts_sales_link_usd + net_parts_sales_non_link_usd + operational_freight_income_usd) as total_sales_usd, 
    sum(net_parts_sales_link_brl + net_parts_sales_non_link_brl + operational_freight_income_brl) as total_sales_brl, 
    sum(net_parts_sales_link_cad + net_parts_sales_non_link_cad + operational_freight_income_cad) as total_sales_cad, 
    sum(net_parts_sales_link_mxn + net_parts_sales_non_link_mxn + operational_freight_income_mxn) as total_sales_mxn, 

    sum(net_parts_sales_link_fx_neutral_eur + net_parts_sales_non_link_fx_neutral_eur + operational_freight_income_fx_neutral_eur) as total_sales_fx_neutral_eur,
    sum(net_parts_sales_link_fx_neutral_usd + net_parts_sales_non_link_fx_neutral_usd + operational_freight_income_fx_neutral_usd) as total_sales_fx_neutral_usd, 
    sum(net_parts_sales_link_fx_neutral_brl + net_parts_sales_non_link_fx_neutral_brl + operational_freight_income_fx_neutral_brl) as total_sales_fx_neutral_brl, 
    sum(net_parts_sales_link_fx_neutral_cad + net_parts_sales_non_link_fx_neutral_cad + operational_freight_income_fx_neutral_cad) as total_sales_fx_neutral_cad, 
    sum(net_parts_sales_link_fx_neutral_mxn + net_parts_sales_non_link_fx_neutral_mxn + operational_freight_income_fx_neutral_mxn) as total_sales_fx_neutral_mxn,

    -- MEASURES 4TH LEVEL
    sum(net_parts_sales_link_eur + net_parts_sales_non_link_eur + operational_freight_income_eur - group_aup_landed_eur) as adjusted_gross_profit_eur,
    sum(net_parts_sales_link_usd + net_parts_sales_non_link_usd + operational_freight_income_usd - group_aup_landed_usd) as adjusted_gross_profit_usd,
    sum(net_parts_sales_link_brl + net_parts_sales_non_link_brl + operational_freight_income_brl - group_aup_landed_brl) as adjusted_gross_profit_brl,
    sum(net_parts_sales_link_cad + net_parts_sales_non_link_cad + operational_freight_income_cad - group_aup_landed_cad) as adjusted_gross_profit_cad,
    sum(net_parts_sales_link_mxn + net_parts_sales_non_link_mxn + operational_freight_income_mxn - group_aup_landed_mxn) as adjusted_gross_profit_mxn,

    sum(net_parts_sales_link_fx_neutral_eur + net_parts_sales_non_link_fx_neutral_eur + operational_freight_income_fx_neutral_eur - group_aup_landed_fx_neutral_eur) as adjusted_gross_profit_fx_neutral_eur,
    sum(net_parts_sales_link_fx_neutral_usd + net_parts_sales_non_link_fx_neutral_usd + operational_freight_income_fx_neutral_usd - group_aup_landed_fx_neutral_usd) as adjusted_gross_profit_fx_neutral_usd,
    sum(net_parts_sales_link_fx_neutral_brl + net_parts_sales_non_link_fx_neutral_brl + operational_freight_income_fx_neutral_brl - group_aup_landed_fx_neutral_brl) as adjusted_gross_profit_fx_neutral_brl,
    sum(net_parts_sales_link_fx_neutral_cad + net_parts_sales_non_link_fx_neutral_cad + operational_freight_income_fx_neutral_cad - group_aup_landed_fx_neutral_cad) as adjusted_gross_profit_fx_neutral_cad,
    sum(net_parts_sales_link_fx_neutral_mxn + net_parts_sales_non_link_fx_neutral_mxn + operational_freight_income_fx_neutral_mxn - group_aup_landed_fx_neutral_mxn) as adjusted_gross_profit_fx_neutral_mxn,

    -- MEASURES 5TH LEVEL    
    sum(net_parts_sales_link_eur + net_parts_sales_non_link_eur + operational_freight_income_eur - group_aup_landed_eur - operational_freight_out_eur) as adjusted_net_gross_profit_eur,
    sum(net_parts_sales_link_usd + net_parts_sales_non_link_usd + operational_freight_income_usd - group_aup_landed_usd - operational_freight_out_usd) as adjusted_net_gross_profit_usd,
    sum(net_parts_sales_link_brl + net_parts_sales_non_link_brl + operational_freight_income_brl - group_aup_landed_brl - operational_freight_out_brl) as adjusted_net_gross_profit_brl,
    sum(net_parts_sales_link_cad + net_parts_sales_non_link_cad + operational_freight_income_cad - group_aup_landed_cad - operational_freight_out_cad) as adjusted_net_gross_profit_cad,
    sum(net_parts_sales_link_mxn + net_parts_sales_non_link_mxn + operational_freight_income_mxn - group_aup_landed_mxn - operational_freight_out_mxn) as adjusted_net_gross_profit_mxn,

    sum(net_parts_sales_link_fx_neutral_eur + net_parts_sales_non_link_fx_neutral_eur + operational_freight_income_fx_neutral_eur - group_aup_landed_fx_neutral_eur - operational_freight_out_fx_neutral_eur) as adjusted_net_gross_profit_fx_neutral_eur,
    sum(net_parts_sales_link_fx_neutral_usd + net_parts_sales_non_link_fx_neutral_usd + operational_freight_income_fx_neutral_usd - group_aup_landed_fx_neutral_usd - operational_freight_out_fx_neutral_usd) as adjusted_net_gross_profit_fx_neutral_usd,
    sum(net_parts_sales_link_fx_neutral_brl + net_parts_sales_non_link_fx_neutral_brl + operational_freight_income_fx_neutral_brl - group_aup_landed_fx_neutral_brl - operational_freight_out_fx_neutral_brl) as adjusted_net_gross_profit_fx_neutral_brl,
    sum(net_parts_sales_link_fx_neutral_cad + net_parts_sales_non_link_fx_neutral_cad + operational_freight_income_fx_neutral_cad - group_aup_landed_fx_neutral_cad - operational_freight_out_fx_neutral_cad) as adjusted_net_gross_profit_fx_neutral_cad,
    sum(net_parts_sales_link_fx_neutral_mxn + net_parts_sales_non_link_fx_neutral_mxn + operational_freight_income_fx_neutral_mxn - group_aup_landed_fx_neutral_mxn - operational_freight_out_fx_neutral_mxn) as adjusted_net_gross_profit_fx_neutral_mxn,

  from first_level
  group by all
)

select 
  reporting_measure,         
  period,
  macro_region,
  super_region,
  region,
  sub_region,
  equipment_market,
  equipment_sub_market,
  statistic_country,
  statistic_country_iso,
  sales_channel_code,
  sales_channel_description,
  territory_for_sales_teams,
  brm_grouping_sales_team_calc,

-- REPORTED MEASURES

  case reporting_measure
    when 'Net parts sales - LINK' then sum(net_parts_sales_link_eur)
    when 'Net parts sales - NON LINK' then sum(net_parts_sales_non_link_eur)
    when 'Net parts sales' then sum(net_parts_sales_link_eur) + sum(net_parts_sales_non_link_eur)
    when 'Operational freight income' then sum(operational_freight_income_eur)
    when 'Total sales' then sum(operational_freight_income_eur) + sum(net_parts_sales_link_eur) + sum(net_parts_sales_non_link_eur)
    when 'Group AUP' then sum(group_aup_eur)
    when 'Landed' then sum(group_aup_landed_eur) - sum(group_aup_eur)
    when 'Group AUP Landed' then sum(group_aup_landed_eur)
    when 'Adjusted gross profit' then sum(operational_freight_income_eur) + sum(net_parts_sales_link_eur) + sum(net_parts_sales_non_link_eur) - sum(group_aup_landed_eur)
    when 'Operational freight out' then sum(operational_freight_out_eur)
    when 'Adjusted net gross profit' then sum(operational_freight_income_eur) + sum(net_parts_sales_link_eur) + sum(net_parts_sales_non_link_eur) - sum(group_aup_landed_eur) - sum(operational_freight_out_eur)
    when 'Commercial profit' then sum(net_parts_sales_link_eur) - sum(group_aup_landed_eur)
    when 'Commercial margin' then null -- It's a divison, has to be calculated in Tableau
    when 'Operational freight reclaim' then null -- It's a divison, has to be calculated in Tableau
  end as reported_eur,

  case reporting_measure
    when 'Net parts sales - LINK' then sum(net_parts_sales_link_usd)
    when 'Net parts sales - NON LINK' then sum(net_parts_sales_non_link_usd)
    when 'Net parts sales' then sum(net_parts_sales_link_usd) + sum(net_parts_sales_non_link_usd)
    when 'Operational freight income' then sum(operational_freight_income_usd)
    when 'Total sales' then sum(operational_freight_income_usd) + sum(net_parts_sales_link_usd) + sum(net_parts_sales_non_link_usd)
    when 'Group AUP' then sum(group_aup_usd)
    when 'Landed' then sum(group_aup_landed_usd) - sum(group_aup_usd)
    when 'Group AUP Landed' then sum(group_aup_landed_usd)
    when 'Adjusted gross profit' then sum(operational_freight_income_usd) + sum(net_parts_sales_link_usd) + sum(net_parts_sales_non_link_usd) - sum(group_aup_landed_usd)
    when 'Operational freight out' then sum(operational_freight_out_usd)
    when 'Adjusted net gross profit' then sum(operational_freight_income_usd) + sum(net_parts_sales_link_usd) + sum(net_parts_sales_non_link_usd) - sum(group_aup_landed_usd) - sum(operational_freight_out_usd)
    when 'Commercial profit' then sum(net_parts_sales_link_usd) - sum(group_aup_landed_usd)
    when 'Commercial margin' then null -- It's a divison, has to be calculated in Tableau
    when 'Operational freight reclaim' then null -- It's a divison, has to be calculated in Tableau
  end as reported_usd,

  case reporting_measure
    when 'Net parts sales - LINK' then sum(net_parts_sales_link_brl)
    when 'Net parts sales - NON LINK' then sum(net_parts_sales_non_link_brl)
    when 'Net parts sales' then sum(net_parts_sales_link_brl) + sum(net_parts_sales_non_link_brl)
    when 'Operational freight income' then sum(operational_freight_income_brl)
    when 'Total sales' then sum(operational_freight_income_brl) + sum(net_parts_sales_link_brl) + sum(net_parts_sales_non_link_brl)
    when 'Group AUP' then sum(group_aup_brl)
    when 'Landed' then sum(group_aup_landed_brl) - sum(group_aup_brl)
    when 'Group AUP Landed' then sum(group_aup_landed_brl)
    when 'Adjusted gross profit' then sum(operational_freight_income_brl) + sum(net_parts_sales_link_brl) + sum(net_parts_sales_non_link_brl) - sum(group_aup_landed_brl)
    when 'Operational freight out' then sum(operational_freight_out_brl)
    when 'Adjusted net gross profit' then sum(operational_freight_income_brl) + sum(net_parts_sales_link_brl) + sum(net_parts_sales_non_link_brl) - sum(group_aup_landed_brl) - sum(operational_freight_out_brl)
    when 'Commercial profit' then sum(net_parts_sales_link_brl) - sum(group_aup_landed_brl)
    when 'Commercial margin' then null -- It's a divison, has to be calculated in Tableau
    when 'Operational freight reclaim' then null -- It's a divison, has to be calculated in Tableau
  end as reported_brl,

  case reporting_measure
    when 'Net parts sales - LINK' then sum(net_parts_sales_link_cad)
    when 'Net parts sales - NON LINK' then sum(net_parts_sales_non_link_cad)
    when 'Net parts sales' then sum(net_parts_sales_link_cad) + sum(net_parts_sales_non_link_cad)
    when 'Operational freight income' then sum(operational_freight_income_cad)
    when 'Total sales' then sum(operational_freight_income_cad) + sum(net_parts_sales_link_cad) + sum(net_parts_sales_non_link_cad)
    when 'Group AUP' then sum(group_aup_cad)
    when 'Landed' then sum(group_aup_landed_cad) - sum(group_aup_cad)
    when 'Group AUP Landed' then sum(group_aup_landed_cad)
    when 'Adjusted gross profit' then sum(operational_freight_income_cad) + sum(net_parts_sales_link_cad) + sum(net_parts_sales_non_link_cad) - sum(group_aup_landed_cad)
    when 'Operational freight out' then sum(operational_freight_out_cad)
    when 'Adjusted net gross profit' then sum(operational_freight_income_cad) + sum(net_parts_sales_link_cad) + sum(net_parts_sales_non_link_cad) - sum(group_aup_landed_cad) - sum(operational_freight_out_cad)
    when 'Commercial profit' then sum(net_parts_sales_link_cad) - sum(group_aup_landed_cad)
    when 'Commercial margin' then null -- It's a divison, has to be calculated in Tableau
    when 'Operational freight reclaim' then null -- It's a divison, has to be calculated in Tableau
  end as reported_cad,

  case reporting_measure
    when 'Net parts sales - LINK' then sum(net_parts_sales_link_mxn)
    when 'Net parts sales - NON LINK' then sum(net_parts_sales_non_link_mxn)
    when 'Net parts sales' then sum(net_parts_sales_link_mxn) + sum(net_parts_sales_non_link_mxn)
    when 'Operational freight income' then sum(operational_freight_income_mxn)
    when 'Total sales' then sum(operational_freight_income_mxn) + sum(net_parts_sales_link_mxn) + sum(net_parts_sales_non_link_mxn)
    when 'Group AUP' then sum(group_aup_mxn)
    when 'Landed' then sum(group_aup_landed_mxn) - sum(group_aup_mxn)
    when 'Group AUP Landed' then sum(group_aup_landed_mxn)
    when 'Adjusted gross profit' then sum(operational_freight_income_mxn) + sum(net_parts_sales_link_mxn) + sum(net_parts_sales_non_link_mxn) - sum(group_aup_landed_mxn)
    when 'Operational freight out' then sum(operational_freight_out_mxn)
    when 'Adjusted net gross profit' then sum(operational_freight_income_mxn) + sum(net_parts_sales_link_mxn) + sum(net_parts_sales_non_link_mxn) - sum(group_aup_landed_mxn) - sum(operational_freight_out_mxn)
    when 'Commercial profit' then sum(net_parts_sales_link_mxn) - sum(group_aup_landed_mxn)
    when 'Commercial margin' then null -- It's a divison, has to be calculated in Tableau
    when 'Operational freight reclaim' then null -- It's a divison, has to be calculated in Tableau
  end as reported_mxn,        

-- FX NEUTRAL MEASURES

  case reporting_measure
    when 'Net parts sales - LINK' then sum(net_parts_sales_link_fx_neutral_eur)
    when 'Net parts sales - NON LINK' then sum(net_parts_sales_non_link_fx_neutral_eur)
    when 'Net parts sales' then sum(net_parts_sales_link_fx_neutral_eur) + sum(net_parts_sales_non_link_fx_neutral_eur)
    when 'Operational freight income' then sum(operational_freight_income_fx_neutral_eur)
    when 'Total sales' then sum(operational_freight_income_fx_neutral_eur) + sum(net_parts_sales_link_fx_neutral_eur) + sum(net_parts_sales_non_link_fx_neutral_eur)
    when 'Group AUP' then sum(group_aup_fx_neutral_eur)
    when 'Landed' then sum(group_aup_landed_fx_neutral_eur) - sum(group_aup_fx_neutral_eur)
    when 'Group AUP Landed' then sum(group_aup_landed_fx_neutral_eur)
    when 'Adjusted gross profit' then sum(operational_freight_income_fx_neutral_eur) + sum(net_parts_sales_link_fx_neutral_eur) + sum(net_parts_sales_non_link_fx_neutral_eur) - sum(group_aup_landed_fx_neutral_eur)
    when 'Operational freight out' then sum(operational_freight_out_fx_neutral_eur)
    when 'Adjusted net gross profit' then sum(operational_freight_income_fx_neutral_eur) + sum(net_parts_sales_link_fx_neutral_eur) + sum(net_parts_sales_non_link_fx_neutral_eur) - sum(group_aup_landed_fx_neutral_eur) - sum(operational_freight_out_fx_neutral_eur)
    when 'Commercial profit' then sum(net_parts_sales_link_fx_neutral_eur) - sum(group_aup_landed_fx_neutral_eur)
    when 'Commercial margin' then null -- It's a divison, has to be calculated in Tableau
    when 'Operational freight reclaim' then null -- It's a divison, has to be calculated in Tableau
  end as fx_neutral_eur,

  case reporting_measure
    when 'Net parts sales - LINK' then sum(net_parts_sales_link_fx_neutral_usd)
    when 'Net parts sales - NON LINK' then sum(net_parts_sales_non_link_fx_neutral_usd)
    when 'Net parts sales' then sum(net_parts_sales_link_fx_neutral_usd) + sum(net_parts_sales_non_link_fx_neutral_usd)
    when 'Operational freight income' then sum(operational_freight_income_fx_neutral_usd)
    when 'Total sales' then sum(operational_freight_income_fx_neutral_usd) + sum(net_parts_sales_link_fx_neutral_usd) + sum(net_parts_sales_non_link_fx_neutral_usd)
    when 'Group AUP' then sum(group_aup_fx_neutral_usd)
    when 'Landed' then sum(group_aup_landed_fx_neutral_usd) - sum(group_aup_fx_neutral_usd)
    when 'Group AUP Landed' then sum(group_aup_landed_fx_neutral_usd)
    when 'Adjusted gross profit' then sum(operational_freight_income_fx_neutral_usd) + sum(net_parts_sales_link_fx_neutral_usd) + sum(net_parts_sales_non_link_fx_neutral_usd) - sum(group_aup_landed_fx_neutral_usd)
    when 'Operational freight out' then sum(operational_freight_out_fx_neutral_usd)
    when 'Adjusted net gross profit' then sum(operational_freight_income_fx_neutral_usd) + sum(net_parts_sales_link_fx_neutral_usd) + sum(net_parts_sales_non_link_fx_neutral_usd) - sum(group_aup_landed_fx_neutral_usd) - sum(operational_freight_out_fx_neutral_usd)
    when 'Commercial profit' then sum(net_parts_sales_link_fx_neutral_usd) - sum(group_aup_landed_fx_neutral_usd)
    when 'Commercial margin' then null -- It's a divison, has to be calculated in Tableau
    when 'Operational freight reclaim' then null -- It's a divison, has to be calculated in Tableau
  end as fx_neutral_usd, 

  case reporting_measure
    when 'Net parts sales - LINK' then sum(net_parts_sales_link_fx_neutral_brl)
    when 'Net parts sales - NON LINK' then sum(net_parts_sales_non_link_fx_neutral_brl)
    when 'Net parts sales' then sum(net_parts_sales_link_fx_neutral_brl) + sum(net_parts_sales_non_link_fx_neutral_brl)
    when 'Operational freight income' then sum(operational_freight_income_fx_neutral_brl)
    when 'Total sales' then sum(operational_freight_income_fx_neutral_brl) + sum(net_parts_sales_link_fx_neutral_brl) + sum(net_parts_sales_non_link_fx_neutral_brl)
    when 'Group AUP' then sum(group_aup_fx_neutral_brl)
    when 'Landed' then sum(group_aup_landed_fx_neutral_brl) - sum(group_aup_fx_neutral_brl)
    when 'Group AUP Landed' then sum(group_aup_landed_fx_neutral_brl)
    when 'Adjusted gross profit' then sum(operational_freight_income_fx_neutral_brl) + sum(net_parts_sales_link_fx_neutral_brl) + sum(net_parts_sales_non_link_fx_neutral_brl) - sum(group_aup_landed_fx_neutral_brl)
    when 'Operational freight out' then sum(operational_freight_out_fx_neutral_brl)
    when 'Adjusted net gross profit' then sum(operational_freight_income_fx_neutral_brl) + sum(net_parts_sales_link_fx_neutral_brl) + sum(net_parts_sales_non_link_fx_neutral_brl) - sum(group_aup_landed_fx_neutral_brl) - sum(operational_freight_out_fx_neutral_brl)
    when 'Commercial profit' then sum(net_parts_sales_link_fx_neutral_brl) - sum(group_aup_landed_fx_neutral_brl)
    when 'Commercial margin' then null -- It's a divison, has to be calculated in Tableau
    when 'Operational freight reclaim' then null -- It's a divison, has to be calculated in Tableau
  end as fx_neutral_brl, 

  case reporting_measure
    when 'Net parts sales - LINK' then sum(net_parts_sales_link_fx_neutral_cad)
    when 'Net parts sales - NON LINK' then sum(net_parts_sales_non_link_fx_neutral_cad)
    when 'Net parts sales' then sum(net_parts_sales_link_fx_neutral_cad) + sum(net_parts_sales_non_link_fx_neutral_cad)
    when 'Operational freight income' then sum(operational_freight_income_fx_neutral_cad)
    when 'Total sales' then sum(operational_freight_income_fx_neutral_cad) + sum(net_parts_sales_link_fx_neutral_cad) + sum(net_parts_sales_non_link_fx_neutral_cad)
    when 'Group AUP' then sum(group_aup_fx_neutral_cad)
    when 'Landed' then sum(group_aup_landed_fx_neutral_cad) - sum(group_aup_fx_neutral_cad)
    when 'Group AUP Landed' then sum(group_aup_landed_fx_neutral_cad)
    when 'Adjusted gross profit' then sum(operational_freight_income_fx_neutral_cad) + sum(net_parts_sales_link_fx_neutral_cad) + sum(net_parts_sales_non_link_fx_neutral_cad) - sum(group_aup_landed_fx_neutral_cad)
    when 'Operational freight out' then sum(operational_freight_out_fx_neutral_cad)
    when 'Adjusted net gross profit' then sum(operational_freight_income_fx_neutral_cad) + sum(net_parts_sales_link_fx_neutral_cad) + sum(net_parts_sales_non_link_fx_neutral_cad) - sum(group_aup_landed_fx_neutral_cad) - sum(operational_freight_out_fx_neutral_cad)
    when 'Commercial profit' then sum(net_parts_sales_link_fx_neutral_cad) - sum(group_aup_landed_fx_neutral_cad)
    when 'Commercial margin' then null -- It's a divison, has to be calculated in Tableau
    when 'Operational freight reclaim' then null -- It's a divison, has to be calculated in Tableau
  end as fx_neutral_cad, 

  case reporting_measure
    when 'Net parts sales - LINK' then sum(net_parts_sales_link_fx_neutral_mxn)
    when 'Net parts sales - NON LINK' then sum(net_parts_sales_non_link_fx_neutral_mxn)
    when 'Net parts sales' then sum(net_parts_sales_link_fx_neutral_mxn) + sum(net_parts_sales_non_link_fx_neutral_mxn)
    when 'Operational freight income' then sum(operational_freight_income_fx_neutral_mxn)
    when 'Total sales' then sum(operational_freight_income_fx_neutral_mxn) + sum(net_parts_sales_link_fx_neutral_mxn) + sum(net_parts_sales_non_link_fx_neutral_mxn)
    when 'Group AUP' then sum(group_aup_fx_neutral_mxn)
    when 'Landed' then sum(group_aup_landed_fx_neutral_mxn) - sum(group_aup_fx_neutral_mxn)
    when 'Group AUP Landed' then sum(group_aup_landed_fx_neutral_mxn)
    when 'Adjusted gross profit' then sum(operational_freight_income_fx_neutral_mxn) + sum(net_parts_sales_link_fx_neutral_mxn) + sum(net_parts_sales_non_link_fx_neutral_mxn) - sum(group_aup_landed_fx_neutral_mxn)
    when 'Operational freight out' then sum(operational_freight_out_fx_neutral_mxn)
    when 'Adjusted net gross profit' then sum(operational_freight_income_fx_neutral_mxn) + sum(net_parts_sales_link_fx_neutral_mxn) + sum(net_parts_sales_non_link_fx_neutral_mxn) - sum(group_aup_landed_fx_neutral_mxn) - sum(operational_freight_out_fx_neutral_mxn)
    when 'Commercial profit' then sum(net_parts_sales_link_fx_neutral_mxn) - sum(group_aup_landed_fx_neutral_mxn)
    when 'Commercial margin' then null -- It's a divison, has to be calculated in Tableau
    when 'Operational freight reclaim' then null -- It's a divison, has to be calculated in Tableau
  end as fx_neutral_mxn,    

  null as budget_eur,
  null as budget_usd,
  null as budget_brl,
  null as budget_cad,
  null as budget_mxn,

  null as budget_price_effect_EUR,
  null as budget_price_effect_USD,
  null as budget_price_effect_BRL,
  null as budget_price_effect_CAD,
  null as budget_price_effect_MXN,

  null as budget_volume_effect_EUR,
  null as budget_volume_effect_USD,
  null as budget_volume_effect_BRL,
  null as budget_volume_effect_CAD,
  null as budget_volume_effect_MXN,

  null as budget_workday_effect_EUR,
  null as budget_workday_effect_USD,
  null as budget_workday_effect_BRL,
  null as budget_workday_effect_CAD,
  null as budget_workday_effect_MXN,
  
  null as budget_integration_effect_EUR,
  null as budget_integration_effect_USD,
  null as budget_integration_effect_BRL,
  null as budget_integration_effect_CAD,
  null as budget_integration_effect_MXN,

  null as budget_workday_effect_profit_EUR,
  null as budget_workday_effect_profit_USD,
  null as budget_workday_effect_profit_BRL,
  null as budget_workday_effect_profit_CAD,
  null as budget_workday_effect_profit_MXN,

  null as budget_volume_effect_profit_EUR,
  null as budget_volume_effect_profit_USD,
  null as budget_volume_effect_profit_BRL,
  null as budget_volume_effect_profit_CAD,
  null as budget_volume_effect_profit_MXN,

  null as budget_integration_effect_profit_EUR,
  null as budget_integration_effect_profit_USD,
  null as budget_integration_effect_profit_BRL,
  null as budget_integration_effect_profit_CAD,
  null as budget_integration_effect_profit_MXN,

  null as budget_cost_effect_profit_EUR,
  null as budget_cost_effect_profit_USD,
  null as budget_cost_effect_profit_BRL,
  null as budget_cost_effect_profit_CAD,
  null as budget_cost_effect_profit_MXN,
  
  null as budget_cost_landed_effect_profit_EUR,
  null as budget_cost_landed_effect_profit_USD,
  null as budget_cost_landed_effect_profit_BRL,
  null as budget_cost_landed_effect_profit_CAD,
  null as budget_cost_landed_effect_profit_MXN,

from other_levels
where period >= '2025-01-01'
group by all