with margin_budget as (

        select

          source_actuals,
          'Margin budget' as data_type,
          budget_period as period,
          cast(null as string) as currency_transaction,
          macro_region,
          super_region,
          region,
          sub_region,
          equipment_market,
          equipment_sub_market,
          statistic_country,
          statistic_country_iso,
          division,
          company_description,
          company_code,
          sales_channel_code,
          sales_channel_description,
          industry,

          is_cab_glazing,

          cast(null as string) as territory_code,
          cast(null as string) as territory_description,
          cast(null as string) as product_category,
          cast(null as string) as product_sub_category,


          null as sales_amount_transaction_currency,
          null as sales_amount_EUR,
          null as sales_amount_USD,
          null as sales_amount_BRL,            
          null as sales_amount_CAD,
          null as sales_amount_MXN,          

          null as sales_amount_margin_transaction_currency,
          null as sales_amount_margin_EUR,
          null as sales_amount_margin_USD,
          null as sales_amount_margin_BRL,            
          null as sales_amount_margin_CAD,
          null as sales_amount_margin_MXN,

          null as Fees_sales_transaction_currency,
          null as Fees_sales_EUR,
          null as Fees_sales_USD,
          null as Fees_sales_BRL,
          null as Fees_sales_CAD,
          null as Fees_sales_MXN,

          null as Rebates_sales_transaction_currency,
          null as Rebates_sales_EUR,
          null as Rebates_sales_USD,
          null as Rebates_sales_BRL,
          null as Rebates_sales_CAD,
          null as Rebates_sales_MXN,

          null as warranties_sales_transaction_currency,
          null as warranties_sales_EUR,
          null as warranties_sales_USD,
          null as warranties_sales_BRL,
          null as warranties_sales_CAD,
          null as warranties_sales_MXN,

          null as returns_on_warranties_sales_transaction_currency,
          null as returns_on_warranties_sales_EUR,
          null as returns_on_warranties_sales_USD,
          null as returns_on_warranties_sales_BRL,
          null as returns_on_warranties_sales_CAD,
          null as returns_on_warranties_sales_MXN,

          null as returns_sales_transaction_currency,
          null as returns_sales_EUR,
          null as returns_sales_USD,
          null as returns_sales_BRL,
          null as returns_sales_CAD,
          null as returns_sales_MXN,

          null as orders_sales_EUR,
          null as orders_sales_USD,
          null as orders_sales_BRL,
          null as orders_sales_CAD,
          null as orders_sales_MXN,
          null as orders_sales_transaction_currency,

          null as orders_quantity,

          null as orders_cost_landed_transaction_currency,
          null as orders_cost_landed_EUR,
          null as orders_cost_landed_USD,
          null as orders_cost_landed_BRL,
          null as orders_cost_landed_CAD,
          null as orders_cost_landed_MXN,

          null as fess_cost_landed_transaction_currency,
          null as fees_cost_landed_EUR,
          null as fees_cost_landed_USD,
          null as fees_cost_landed_BRL,
          null as fees_cost_landed_CAD,
          null as fees_cost_landed_MXN,

          null as warranties_cost_landed_transaction_currency,
          null as warranties_cost_landed_EUR,
          null as warranties_cost_landed_USD,
          null as warranties_cost_landed_BRL,
          null as warranties_cost_landed_CAD,
          null as warranties_cost_landed_MXN,

          null as returns_on_warranties_cost_landed_transaction_currency,
          null as returns_on_warranties_cost_landed_EUR,
          null as returns_on_warranties_cost_landed_USD,
          null as returns_on_warranties_cost_landed_BRL,
          null as returns_on_warranties_cost_landed_CAD,
          null as returns_on_warranties_cost_landed_MXN,

          null as returns_cost_landed_transaction_currency,
          null as returns_cost_landed_EUR,
          null as returns_cost_landed_USD,
          null as returns_cost_landed_BRL,
          null as returns_cost_landed_CAD,
          null as returns_cost_landed_MXN,

          null as Noncommercial_cost_landed_transaction_currency,
          null as Noncommercial_cost_landed_EUR,
          null as Noncommercial_cost_landed_USD,
          null as Noncommercial_cost_landed_BRL,
          null as Noncommercial_cost_landed_CAD,
          null as Noncommercial_cost_landed_MXN,            

          budget_amount_EUR as sales_budget_amount_EUR,
          budget_amount_USD as sales_budget_amount_USD,
          budget_amount_BRL as sales_budget_amount_BRL,
          budget_amount_CAD as sales_budget_amount_CAD,
          budget_amount_MXN as sales_budget_amount_MXN,

          budget_commercial_profit_EUR as budget_profit_EUR,
          budget_commercial_profit_USD as budget_profit_USD,
          budget_commercial_profit_BRL as budget_profit_BRL,
          budget_commercial_profit_CAD as budget_profit_CAD,
          budget_commercial_profit_MXN as budget_profit_MXN,

          null as budget_rate_eur,
          null as budget_rate_usd,
          null as budget_rate_brl,
          null as budget_rate_cad,
          null as budget_rate_mxn,

          -- Workday Effect
          wd_contribution_eur as budget_workday_effect_EUR,
          wd_contribution_usd as budget_workday_effect_USD,
          wd_contribution_brl as budget_workday_effect_BRL,
          wd_contribution_cad as budget_workday_effect_CAD,
          wd_contribution_mxn as budget_workday_effect_MXN,

          -- Price Effect
          p_contribution_eur as budget_price_effect_EUR,
          p_contribution_usd as budget_price_effect_USD,
          p_contribution_brl as budget_price_effect_BRL,
          p_contribution_cad as budget_price_effect_CAD,
          p_contribution_mxn as budget_price_effect_MXN,

          -- Volume Effect
          q_contribution_eur as budget_volume_effect_EUR,
          q_contribution_usd as budget_volume_effect_USD,
          q_contribution_brl as budget_volume_effect_BRL,
          q_contribution_cad as budget_volume_effect_CAD,
          q_contribution_mxn as budget_volume_effect_MXN,

          -- Integration Effect
          sales_integrations_effect_eur as budget_integration_effect_EUR,
          sales_integrations_effect_usd as budget_integration_effect_USD,
          sales_integrations_effect_brl as budget_integration_effect_BRL,
          sales_integrations_effect_cad as budget_integration_effect_CAD,
          sales_integrations_effect_mxn as budget_integration_effect_MXN,

          -- Profit Workday Effect
          profit_wd_contribution_eur as budget_workday_effect_profit_EUR,
          profit_wd_contribution_usd as budget_workday_effect_profit_USD,
          profit_wd_contribution_brl as budget_workday_effect_profit_BRL,
          profit_wd_contribution_cad as budget_workday_effect_profit_CAD,
          profit_wd_contribution_mxn as budget_workday_effect_profit_MXN,

          -- Profit Volume Effect
          profit_volume_effect_eur as budget_volume_effect_profit_EUR,
          profit_volume_effect_usd as budget_volume_effect_profit_USD,
          profit_volume_effect_brl as budget_volume_effect_profit_BRL,
          profit_volume_effect_cad as budget_volume_effect_profit_CAD,
          profit_volume_effect_mxn as budget_volume_effect_profit_MXN,

          -- Profit Integration Effect
          profit_integrations_effect_eur as budget_integration_effect_profit_EUR,
          profit_integrations_effect_usd as budget_integration_effect_profit_USD,
          profit_integrations_effect_brl as budget_integration_effect_profit_BRL,
          profit_integrations_effect_cad as budget_integration_effect_profit_CAD,
          profit_integrations_effect_mxn as budget_integration_effect_profit_MXN,

          -- Profit GAUP (Cost) Effect
          profit_gaup_effect_eur as budget_cost_effect_profit_EUR,
          profit_gaup_effect_usd as budget_cost_effect_profit_USD,
          profit_gaup_effect_brl as budget_cost_effect_profit_BRL,
          profit_gaup_effect_cad as budget_cost_effect_profit_CAD,
          profit_gaup_effect_mxn as budget_cost_effect_profit_MXN,

          -- Profit Landed Cost Effect
          profit_landed_effect_eur as budget_cost_landed_effect_profit_EUR,
          profit_landed_effect_usd as budget_cost_landed_effect_profit_USD,
          profit_landed_effect_brl as budget_cost_landed_effect_profit_BRL,
          profit_landed_effect_cad as budget_cost_landed_effect_profit_CAD,
          profit_landed_effect_mxn as budget_cost_landed_effect_profit_MXN        
 

        from {{ref('stg_financial_sales_budget')}}
        where source_actuals = 'Link'
        and extract (year from budget_period) = 2026

),

sales_budget as (

       select

          source_actuals,
          'Sales budget' as data_type,
          budget_period as period,
          cast(null as string) as currency_transaction,
          macro_region,
          super_region,
          region,
          sub_region,
          equipment_market,
          equipment_sub_market,
          statistic_country,
          statistic_country_iso,
          division,
          company_description,
          company_code,
          sales_channel_code,
          sales_channel_description,
          industry,

          is_cab_glazing,

          cast(null as string) as territory_code,
          cast(null as string) as territory_description,
          cast(null as string) as product_category,
          cast(null as string) as product_sub_category,       

          null as sales_amount_transaction_currency,
          null as sales_amount_EUR,
          null as sales_amount_USD,
          null as sales_amount_BRL,            
          null as sales_amount_CAD,
          null as sales_amount_MXN,          

          null as sales_amount_margin_transaction_currency,
          null as sales_amount_margin_EUR,
          null as sales_amount_margin_USD,
          null as sales_amount_margin_BRL,            
          null as sales_amount_margin_CAD,
          null as sales_amount_margin_MXN,

          null as Fees_sales_transaction_currency,
          null as Fees_sales_EUR,
          null as Fees_sales_USD,
          null as Fees_sales_BRL,
          null as Fees_sales_CAD,
          null as Fees_sales_MXN,

          null as Rebates_sales_transaction_currency,
          null as Rebates_sales_EUR,
          null as Rebates_sales_USD,
          null as Rebates_sales_BRL,
          null as Rebates_sales_CAD,
          null as Rebates_sales_MXN,

          null as warranties_sales_transaction_currency,
          null as warranties_sales_EUR,
          null as warranties_sales_USD,
          null as warranties_sales_BRL,
          null as warranties_sales_CAD,
          null as warranties_sales_MXN,

          null as returns_on_warranties_sales_transaction_currency,
          null as returns_on_warranties_sales_EUR,
          null as returns_on_warranties_sales_USD,
          null as returns_on_warranties_sales_BRL,
          null as returns_on_warranties_sales_CAD,
          null as returns_on_warranties_sales_MXN,

          null as returns_sales_transaction_currency,
          null as returns_sales_EUR,
          null as returns_sales_USD,
          null as returns_sales_BRL,
          null as returns_sales_CAD,
          null as returns_sales_MXN,

          null as orders_sales_EUR,
          null as orders_sales_USD,
          null as orders_sales_BRL,
          null as orders_sales_CAD,
          null as orders_sales_MXN,
          null as orders_sales_transaction_currency,

          null as orders_quantity,

          null as orders_cost_landed_transaction_currency,
          null as orders_cost_landed_EUR,
          null as orders_cost_landed_USD,
          null as orders_cost_landed_BRL,
          null as orders_cost_landed_CAD,
          null as orders_cost_landed_MXN,

          null as fess_cost_landed_transaction_currency,
          null as fees_cost_landed_EUR,
          null as fees_cost_landed_USD,
          null as fees_cost_landed_BRL,
          null as fees_cost_landed_CAD,
          null as fees_cost_landed_MXN,

          null as warranties_cost_landed_transaction_currency,
          null as warranties_cost_landed_EUR,
          null as warranties_cost_landed_USD,
          null as warranties_cost_landed_BRL,
          null as warranties_cost_landed_CAD,
          null as warranties_cost_landed_MXN,

          null as returns_on_warranties_cost_landed_transaction_currency,
          null as returns_on_warranties_cost_landed_EUR,
          null as returns_on_warranties_cost_landed_USD,
          null as returns_on_warranties_cost_landed_BRL,
          null as returns_on_warranties_cost_landed_CAD,
          null as returns_on_warranties_cost_landed_MXN,

          null as returns_cost_landed_transaction_currency,
          null as returns_cost_landed_EUR,
          null as returns_cost_landed_USD,
          null as returns_cost_landed_BRL,
          null as returns_cost_landed_CAD,
          null as returns_cost_landed_MXN,

          null as Noncommercial_cost_landed_transaction_currency,
          null as Noncommercial_cost_landed_EUR,
          null as Noncommercial_cost_landed_USD,
          null as Noncommercial_cost_landed_BRL,
          null as Noncommercial_cost_landed_CAD,
          null as Noncommercial_cost_landed_MXN,            

          sum(budget_amount_EUR) as sales_budget_amount_EUR,
          sum(budget_amount_USD) as sales_budget_amount_USD,
          sum(budget_amount_BRL) as sales_budget_amount_BRL,
          sum(budget_amount_CAD) as sales_budget_amount_CAD,
          sum(budget_amount_MXN) as sales_budget_amount_MXN,

          SUM(budget_commercial_profit_EUR) as budget_profit_EUR,
          SUM(budget_commercial_profit_USD) as budget_profit_USD,
          SUM(budget_commercial_profit_BRL) as budget_profit_BRL,
          SUM(budget_commercial_profit_CAD) as budget_profit_CAD,
          SUM(budget_commercial_profit_MXN) as budget_profit_MXN,

          null as budget_rate_eur,
          null as budget_rate_usd,
          null as budget_rate_brl,
          null as budget_rate_cad,
          null as budget_rate_mxn,


          SUM(wd_contribution_eur) as budget_workday_effect_EUR,
          SUM(wd_contribution_usd) as budget_workday_effect_USD,
          SUM(wd_contribution_brl) as budget_workday_effect_BRL,
          SUM(wd_contribution_cad) as budget_workday_effect_CAD,
          SUM(wd_contribution_mxn) as budget_workday_effect_MXN,

          -- Price Effect
          SUM(p_contribution_eur) as budget_price_effect_EUR,
          SUM(p_contribution_usd) as budget_price_effect_USD,
          SUM(p_contribution_brl) as budget_price_effect_BRL,
          SUM(p_contribution_cad) as budget_price_effect_CAD,
          SUM(p_contribution_mxn) as budget_price_effect_MXN,

          -- Volume Effect
          SUM(q_contribution_eur) as budget_volume_effect_EUR,
          SUM(q_contribution_usd) as budget_volume_effect_USD,
          SUM(q_contribution_brl) as budget_volume_effect_BRL,
          SUM(q_contribution_cad) as budget_volume_effect_CAD,
          SUM(q_contribution_mxn) as budget_volume_effect_MXN,

          -- Integration Effect
          SUM(sales_integrations_effect_eur) as budget_integration_effect_EUR,
          SUM(sales_integrations_effect_usd) as budget_integration_effect_USD,
          SUM(sales_integrations_effect_brl) as budget_integration_effect_BRL,
          SUM(sales_integrations_effect_cad) as budget_integration_effect_CAD,
          SUM(sales_integrations_effect_mxn) as budget_integration_effect_MXN,

          -- Profit Workday Effect
          SUM(profit_wd_contribution_eur) as budget_workday_effect_profit_EUR,
          SUM(profit_wd_contribution_usd) as budget_workday_effect_profit_USD,
          SUM(profit_wd_contribution_brl) as budget_workday_effect_profit_BRL,
          SUM(profit_wd_contribution_cad) as budget_workday_effect_profit_CAD,
          SUM(profit_wd_contribution_mxn) as budget_workday_effect_profit_MXN,

          -- Profit Volume Effect
          SUM(profit_volume_effect_eur) as budget_volume_effect_profit_EUR,
          SUM(profit_volume_effect_usd) as budget_volume_effect_profit_USD,
          SUM(profit_volume_effect_brl) as budget_volume_effect_profit_BRL,
          SUM(profit_volume_effect_cad) as budget_volume_effect_profit_CAD,
          SUM(profit_volume_effect_mxn) as budget_volume_effect_profit_MXN,

          -- Profit Integration Effect
          SUM(profit_integrations_effect_eur) as budget_integration_effect_profit_EUR,
          SUM(profit_integrations_effect_usd) as budget_integration_effect_profit_USD,
          SUM(profit_integrations_effect_brl) as budget_integration_effect_profit_BRL,
          SUM(profit_integrations_effect_cad) as budget_integration_effect_profit_CAD,
          SUM(profit_integrations_effect_mxn) as budget_integration_effect_profit_MXN,

          -- Profit GAUP (Cost) Effect
          SUM(profit_gaup_effect_eur) as budget_cost_effect_profit_EUR,
          SUM(profit_gaup_effect_usd) as budget_cost_effect_profit_USD,
          SUM(profit_gaup_effect_brl) as budget_cost_effect_profit_BRL,
          SUM(profit_gaup_effect_cad) as budget_cost_effect_profit_CAD,
          SUM(profit_gaup_effect_mxn) as budget_cost_effect_profit_MXN,

          -- Profit Landed Cost Effect
          SUM(profit_landed_effect_eur) as budget_cost_landed_effect_profit_EUR,
          SUM(profit_landed_effect_usd) as budget_cost_landed_effect_profit_USD,
          SUM(profit_landed_effect_brl) as budget_cost_landed_effect_profit_BRL,
          SUM(profit_landed_effect_cad) as budget_cost_landed_effect_profit_CAD,
          SUM(profit_landed_effect_mxn) as budget_cost_landed_effect_profit_MXN

      from {{ref('stg_financial_sales_budget')}}
      where extract (year from budget_period) = 2026
      group by all


),

/*
product_budget as (

        select

          case
            is_link
              when true then 'Link'
              when false then 'Non-Link'
          end as source_actuals,
          'Product budget' as data_type,
          period as period,
          cast(null as string) as currency_transaction,
          macro_region,
          super_region,
          cast(null as string) as region,
          cast(null as string) as sub_region,
          cast(null as string) as equipment_market,
          cast(null as string) as equipment_sub_market,
          cast(null as string) as statistic_country,
          cast(null as string) as statistic_country_iso,
          cast(null as string) as division,
          cast(null as string) as company_description,
          cast(null as string) as company_code,
          cast(null as string) as sales_channel_code,
          cast(null as string) as sales_channel_description,
          cast(null as string) as industry,
          cast(null as string) as territory_code,
          cast(null as string) as territory_description,
          product_category,
          product_sub_category,               

          null as sales_amount_transaction_currency,
          null as sales_amount_EUR,
          null as sales_amount_USD,
          null as sales_amount_BRL,            
          null as sales_amount_CAD,
          null as sales_amount_MXN,          

          null as sales_amount_margin_transaction_currency,
          null as sales_amount_margin_EUR,
          null as sales_amount_margin_USD,
          null as sales_amount_margin_BRL,            
          null as sales_amount_margin_CAD,
          null as sales_amount_margin_MXN,

          null as Fees_sales_transaction_currency,
          null as Fees_sales_EUR,
          null as Fees_sales_USD,
          null as Fees_sales_BRL,
          null as Fees_sales_CAD,
          null as Fees_sales_MXN,

          null as Rebates_sales_transaction_currency,
          null as Rebates_sales_EUR,
          null as Rebates_sales_USD,
          null as Rebates_sales_BRL,
          null as Rebates_sales_CAD,
          null as Rebates_sales_MXN,

          null as warranties_sales_transaction_currency,
          null as warranties_sales_EUR,
          null as warranties_sales_USD,
          null as warranties_sales_BRL,
          null as warranties_sales_CAD,
          null as warranties_sales_MXN,

          null as returns_on_warranties_sales_transaction_currency,
          null as returns_on_warranties_sales_EUR,
          null as returns_on_warranties_sales_USD,
          null as returns_on_warranties_sales_BRL,
          null as returns_on_warranties_sales_CAD,
          null as returns_on_warranties_sales_MXN,

          null as returns_sales_transaction_currency,
          null as returns_sales_EUR,
          null as returns_sales_USD,
          null as returns_sales_BRL,
          null as returns_sales_CAD,
          null as returns_sales_MXN,

          null as orders_sales_EUR,
          null as orders_sales_USD,
          null as orders_sales_BRL,
          null as orders_sales_CAD,
          null as orders_sales_MXN,
          null as orders_sales_transaction_currency,

          null as orders_quantity,

          null as orders_cost_landed_transaction_currency,
          null as orders_cost_landed_EUR,
          null as orders_cost_landed_USD,
          null as orders_cost_landed_BRL,
          null as orders_cost_landed_CAD,
          null as orders_cost_landed_MXN,

          null as fess_cost_landed_transaction_currency,
          null as fees_cost_landed_EUR,
          null as fees_cost_landed_USD,
          null as fees_cost_landed_BRL,
          null as fees_cost_landed_CAD,
          null as fees_cost_landed_MXN,

          null as warranties_cost_landed_transaction_currency,
          null as warranties_cost_landed_EUR,
          null as warranties_cost_landed_USD,
          null as warranties_cost_landed_BRL,
          null as warranties_cost_landed_CAD,
          null as warranties_cost_landed_MXN,

          null as returns_on_warranties_cost_landed_transaction_currency,
          null as returns_on_warranties_cost_landed_EUR,
          null as returns_on_warranties_cost_landed_USD,
          null as returns_on_warranties_cost_landed_BRL,
          null as returns_on_warranties_cost_landed_CAD,
          null as returns_on_warranties_cost_landed_MXN,

          null as returns_cost_landed_transaction_currency,
          null as returns_cost_landed_EUR,
          null as returns_cost_landed_USD,
          null as returns_cost_landed_BRL,
          null as returns_cost_landed_CAD,
          null as returns_cost_landed_MXN,

          null as Noncommercial_cost_landed_transaction_currency,
          null as Noncommercial_cost_landed_EUR,
          null as Noncommercial_cost_landed_USD,
          null as Noncommercial_cost_landed_BRL,
          null as Noncommercial_cost_landed_CAD,
          null as Noncommercial_cost_landed_MXN,            

          sum(budget_amount_EUR) as sales_budget_amount_EUR,
          sum(budget_amount_USD) as sales_budget_amount_USD,
          sum(budget_amount_BRL) as sales_budget_amount_BRL,
          sum(budget_amount_CAD) as sales_budget_amount_CAD,
          sum(budget_amount_MXN) as sales_budget_amount_MXN,

          null as budget_profit_EUR,
          null as budget_profit_USD,
          null as budget_profit_BRL,
          null as budget_profit_CAD,
          null as budget_profit_MXN,

          null as budget_rate_eur,
          null as budget_rate_usd,
          null as budget_rate_brl,
          null as budget_rate_cad,
          null as budget_rate_mxn 

      from data-lake-dwh-fin.public.vw_product_budget_and_actuals_including_non_link_companies_no_rls
      group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23


),
*/

final_union as (

select * from margin_budget
union all
select * from sales_budget

)

select
      *,
      case
          when sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB') then sales_channel_description
          when sales_channel_code in ('TVH BE','BEPCO LA','SML') then statistic_country_iso
          when (source_actuals != 'Link' and company_code in ('GMPBE','UH','A7')) then 'PNS'
          else sub_region
      end as brm_grouping_sales_team_calc,
from final_union
























