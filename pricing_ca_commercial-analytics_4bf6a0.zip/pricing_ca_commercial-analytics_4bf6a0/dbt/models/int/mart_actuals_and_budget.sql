{{ config(
    materialized='table',
    partition_by={
      "field": "period",
      "data_type": "date",
      "granularity": "month"
    },
    cluster_by="sub_region"
) }}

with base as (

      select * from {{ref('int_actuals_and_budget_union')}}

),

main as (

      -- Budget rows arrive with territory_code NULL, so they fall through to
      -- the company / ISO branches on their own. Deliberately derived here
      -- rather than in int_comal_actuals / int_comal_budget: those two are
      -- combined by a POSITIONAL union all in int_actuals_and_budget_union,
      -- where a column added to one and not the other silently misaligns
      -- every column after it.
      select
            base.*,
            {{ territory_for_sales_teams('territory_code', 'company_code', 'statistic_country_iso') }}
                as territory_for_sales_teams
      from base

)

select 

      main.*,
      brm.brm_grouping_sales_team,
      brm.brm_grouping_region,
      brm.brm_grouping_super_region,
      brm.brm_grouping_macro_region,
      brm.brm_grouping_macro_region_ext,
      {{ sales_team_columns('stt') }}


from main

    left join
    (
      select
        distinct
        brm_grouping_sales_team_calc,
        brm_grouping_sales_team,
        brm_grouping_region,
        brm_grouping_super_region,
        brm_grouping_macro_region,
        brm_grouping_macro_region_ext
      from {{ref('int_brm_structure')}}
    ) brm
      on brm.brm_grouping_sales_team_calc = main.brm_grouping_sales_team_calc
    left join {{ ref('stg_territory_sales_teams') }} stt
      on stt.territory_for_salesteams_code = main.territory_for_sales_teams