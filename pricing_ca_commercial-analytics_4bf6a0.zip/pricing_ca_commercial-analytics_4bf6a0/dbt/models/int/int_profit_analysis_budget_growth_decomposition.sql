SELECT

  # This is the primary key that uniquely identifies each record  
  sin.Sales_invoices_id,
  
  # This is the unique key for an order line
  sin.Sales_order_line_no,

  # Order/Invoice - Dimensions
  # -------------------------------------------------------------
  sin.Sales_order_type,
  sin.Sales_invoice_date,
  DATE_TRUNC(sin.Sales_invoice_date, MONTH) as Sales_invoice_date_my,
  sin.Sales_invoice_no,
  sin.TVH_part_no,
  sin.TVH_stock_no,
  sin.part_no,
  sin.SKU_no,
  sin.TVH_no_Brand_code,
  sin.TVH_no_Brand_descr,
  sin.Currency_transaction,
  sin.Fee_type,
  sin.Rebate_TF,
  sin.Sales_order_source,
  sin.source_system,

  # Hard coded change so these records are not taken as LINK sales but Non-link sales due to integrations | NOT NEEDED ANYMORE
  case when
      (sin.Company = 'BOZ' and extract(month from Sales_invoice_date) < 6)
      or
      (sin.statistic_country = 'Poland' and extract(month from Sales_invoice_date) = 1)
      then 'Non-Link'
      else source_system
  end as source_system_new,

  # This is a new way of calculating the sales order type so that we can easily filter on each type
  # -------------------------------------------------------------
  case 
    when sin.Rebate_TF then "Rebates" 
    when not(sin.Fee_type is null) then "Fees" 
    when sin.Sales_order_type = "O" then "Orders" 
    when sin.Sales_order_type = "R" then "Returns" 
    when sin.Sales_order_type = "W" then "Warranties"
    when sin.Sales_order_type = "RW" then "Returns on warranties"
    else "[Unknown]"
  end as Sales_order_type_alternative,
  
  # Fields used in Tableau to quickly filter/isolate data on rebates, fees and "other" (non rebate, non fee lines)
  case when sin.Rebate_TF then True else False end as isRebate,
  case when not(sin.Rebate_TF) and not(sin.Fee_type is null) then True else False end as isFee,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and sin.sales_order_type = "O" then True else False end as isOrder,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and sin.sales_order_type = "R" then True else False end as isReturn,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and sin.Sales_order_type = "W"  then TRUE else FALSE end as isWarranty,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and sin.Sales_order_type = "RW" then TRUE else FALSE end as isReturnOnWarranty,

  --case when not(sin.Rebate_TF) and sin.Fee_type is null then True else False end as isNoRebateAndNoFee, # still needed??????
   
  # Order/Invoice - Measures
  # -------------------------------------------------------------
  # Delivered
  sin.Delivered_amount_EUR,
  sin.Delivered_amount_USD,
  sin.Delivered_amount_transaction_cur,
  sin.Delivered_quantity,

  # Split the sales so that we have only the non-commercial amount
  case when Exclude_in_global_management_reporting_TF = true then sin.Delivered_amount_EUR else 0 end as Noncommercial_sales_EUR,
  case when Exclude_in_global_management_reporting_TF = true then sin.Delivered_amount_USD else 0 end as Noncommercial_sales_USD,
  case when Exclude_in_global_management_reporting_TF = true then sin.Delivered_amount_transaction_cur else 0 end as Noncommercial_sales_transaction_cur,   

  # Split the sales so that we have only the rebates amount
  case when sin.Rebate_TF and Exclude_in_global_management_reporting_TF = false then sin.Delivered_amount_EUR else 0 end as Rebates_sales_EUR,
  case when sin.Rebate_TF and Exclude_in_global_management_reporting_TF = false then sin.Delivered_amount_USD else 0 end as Rebates_sales_USD,
  case when sin.Rebate_TF and Exclude_in_global_management_reporting_TF = false then sin.Delivered_amount_transaction_cur else 0 end as Rebates_sales_transaction_cur,

  # Split the sales so that we have only the fees amount
  case when not(sin.Rebate_TF) and not(sin.Fee_type is null) and Exclude_in_global_management_reporting_TF = false then sin.Delivered_amount_EUR else 0 end as Fees_sales_EUR,
  case when not(sin.Rebate_TF) and not(sin.Fee_type is null) and Exclude_in_global_management_reporting_TF = false then sin.Delivered_amount_USD else 0 end as Fees_sales_USD,
  case when not(sin.Rebate_TF) and not(sin.Fee_type is null) and Exclude_in_global_management_reporting_TF = false then sin.Delivered_amount_transaction_cur else 0 end as Fees_sales_transaction_cur,

  # Split the sales so that we have sales amount for Orders only
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "O" then sin.Delivered_amount_EUR else 0 end as Orders_sales_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "O" then sin.Delivered_amount_USD else 0 end as Orders_sales_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "O" then sin.Delivered_amount_transaction_cur else 0 end as Orders_sales_transaction_cur,

  # Split the sales so that we have sales amount for Returns only
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "R" then sin.Delivered_amount_EUR else 0 end as Returns_sales_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "R" then sin.Delivered_amount_USD else 0 end as Returns_sales_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "R" then sin.Delivered_amount_transaction_cur else 0 end as Returns_sales_transaction_cur,

  # Split the sales so that we have sales amount for Warranties only
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "W" then sin.Delivered_amount_EUR else 0 end as Warranties_sales_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "W" then sin.Delivered_amount_USD else 0 end as Warranties_sales_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "W"  then sin.Delivered_amount_transaction_cur else 0 end as Warranties_sales_transaction_cur,

  # Split the sales so that we have sales amount for Returns on warranties only
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "RW"  then sin.Delivered_amount_EUR else 0 end as Returns_on_warranties_sales_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "RW"  then sin.Delivered_amount_USD else 0 end as Returns_on_warranties_sales_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "RW"  then sin.Delivered_amount_transaction_cur else 0 end as Returns_on_warranties_sales_transaction_cur,

  # Split the delivered quantity so that we have the quantity for orders only
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "O" then sin.Delivered_quantity else 0 end as Orders_quantity,

  #-------------------------DELETE ????-------------------
  #Can be deleted?????????
  # Split the sales so that we have only the sales amount without rebates and fees
  --case when not(sin.Rebate_TF) and sin.Fee_type is null and sin.Sales_order_type !="R" then sin.Delivered_amount_EUR else 0 end as Sales_excl_rebates_and_fees_EUR,
  --case when not(sin.Rebate_TF) and sin.Fee_type is null and sin.Sales_order_type !="R" then sin.Delivered_amount_USD else 0 end as Sales_excl_rebates_and_fees_USD,
  --case when not(sin.Rebate_TF) and sin.Fee_type is null and sin.Sales_order_type !="R" then sin.Delivered_amount_transaction_cur else 0 end as Sales_excl_rebates_and_fees_transaction_cur,

  # Split the delivered quantity so that we have only the quantity without rebates and fees  ?????????  DELETE
  --case when not(sin.Rebate_TF) and sin.Fee_type is null then sin.Delivered_quantity else 0 end as Delivered_quantity_excl_rebates_and_fees_EUR,

  #--------------------------------------------------------------------


  # Average unit price group - amount
  sin.Avg_unit_price_group_amount_EUR,
  sin.Avg_unit_price_group_amount_USD,
  sin.Avg_unit_price_group_amount_transaction_cur,

  # Split the Average unit price group - amount so that we have only the non-commercial amount
  case when Exclude_in_global_management_reporting_TF = true then sin.Avg_unit_price_group_amount_EUR else 0 end as Noncommercial_cost_EUR,
  case when Exclude_in_global_management_reporting_TF = true then sin.Avg_unit_price_group_amount_USD else 0 end as Noncommercial_cost_USD,
  case when Exclude_in_global_management_reporting_TF = true then sin.Avg_unit_price_group_amount_transaction_cur else 0 end as Noncommercial_cost_transaction_cur,    

  # Split the Average unit price group - amount so that we have only the rebates
  case when sin.Rebate_TF and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_amount_EUR else 0 end as Rebates_cost_EUR,
  case when sin.Rebate_TF and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_amount_USD else 0 end as Rebates_cost_USD,
  case when sin.Rebate_TF and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_amount_transaction_cur else 0 end as Rebates_cost_transaction_cur,

  # Split the Average unit price group - amount so that we have only the fees
  case when not(sin.Rebate_TF) and not(sin.Fee_type is null) and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_amount_EUR else 0 end as Fees_cost_EUR,
  case when not(sin.Rebate_TF) and not(sin.Fee_type is null) and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_amount_USD else 0 end as Fees_cost_USD,
  case when not(sin.Rebate_TF) and not(sin.Fee_type is null) and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_amount_transaction_cur else 0 end as Fees_cost_transaction_cur,

  # Split the Average unit price group - amount so that we have only the orders
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "O" then sin.Avg_unit_price_group_amount_EUR else 0 end as Orders_cost_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "O" then sin.Avg_unit_price_group_amount_USD else 0 end as Orders_cost_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "O" then sin.Avg_unit_price_group_amount_transaction_cur else 0 end as Orders_cost_transaction_cur,

  # Split the Average unit price group - amount so that we have only the returns
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "R" then sin.Avg_unit_price_group_amount_EUR else 0 end as Returns_cost_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "R" then sin.Avg_unit_price_group_amount_USD else 0 end as Returns_cost_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "R" then sin.Avg_unit_price_group_amount_transaction_cur else 0 end as Returns_cost_transaction_cur,

  # Split the Average unit price group - amount so that we have only the warranties
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "W" then sin.Avg_unit_price_group_amount_EUR else 0 end as Warranties_cost_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "W" then sin.Avg_unit_price_group_amount_USD else 0 end as Warranties_cost_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "W"  then sin.Avg_unit_price_group_amount_transaction_cur else 0 end as Warranties_cost_transaction_cur,

  # Split the Average unit price group - amount so that we have only the returs on warranties
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "RW"  then sin.Avg_unit_price_group_amount_EUR else 0 end as Returns_on_warranties_cost_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "RW"  then sin.Avg_unit_price_group_amount_USD else 0 end as Returns_on_warranties_cost_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "RW"  then sin.Avg_unit_price_group_amount_transaction_cur else 0 end as Returns_on_warranties_cost_transaction_cur,

  # Average unit price group landed - amount
  sin.avg_unit_price_group_landed_amount_EUR,
  sin.avg_unit_price_group_landed_amount_USD,
  sin.avg_unit_price_group_landed_amount_transaction_cur,

  # Split the Average unit price group landed - amount so that we have only the non-commercial amount
  case when Exclude_in_global_management_reporting_TF = true then sin.Avg_unit_price_group_landed_amount_EUR else 0 end as Noncommercial_cost_landed_EUR,
  case when Exclude_in_global_management_reporting_TF = true then sin.Avg_unit_price_group_landed_amount_USD else 0 end as Noncommercial_cost_landed_USD,
  case when Exclude_in_global_management_reporting_TF = true then sin.Avg_unit_price_group_landed_amount_transaction_cur else 0 end as Noncommercial_cost_landed_transaction_cur,  

  # Split the Average unit price group landed - amount so that we have only the rebates
  case when sin.Rebate_TF and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_landed_amount_EUR else 0 end as Rebates_cost_landed_EUR,
  case when sin.Rebate_TF and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_landed_amount_USD else 0 end as Rebates_cost_landed_USD,
  case when sin.Rebate_TF and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_landed_amount_transaction_cur else 0 end as Rebates_cost_landed_transaction_cur,

  # Split the Average unit price group landed - amount so that we have only the fees
  case when not(sin.Rebate_TF) and not(sin.Fee_type is null) and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_landed_amount_EUR else 0 end as Fees_cost_landed_EUR,
  case when not(sin.Rebate_TF) and not(sin.Fee_type is null) and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_landed_amount_USD else 0 end as Fees_cost_landed_USD,
  case when not(sin.Rebate_TF) and not(sin.Fee_type is null) and Exclude_in_global_management_reporting_TF = false then sin.Avg_unit_price_group_landed_amount_transaction_cur else 0 end as Fees_cost_landed_transaction_cur,

  # Split the Average unit price group landed - amount so that we have only the orders
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "O" then sin.Avg_unit_price_group_landed_amount_EUR else 0 end as Orders_cost_landed_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "O" then sin.Avg_unit_price_group_landed_amount_USD else 0 end as Orders_cost_landed_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "O" then sin.Avg_unit_price_group_landed_amount_transaction_cur else 0 end as Orders_cost_landed_transaction_cur,

  # Split the Average unit price group landed - amount so that we have only the returns
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "R" then sin.Avg_unit_price_group_landed_amount_EUR else 0 end as Returns_cost_landed_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.sales_order_type = "R" then sin.Avg_unit_price_group_landed_amount_USD else 0 end as Returns_cost_landed_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "R" then sin.Avg_unit_price_group_landed_amount_transaction_cur else 0 end as Returns_cost_landed_transaction_cur,

  # Split the Average unit price group landed - amount so that we have only the warranties
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "W" then sin.Avg_unit_price_group_landed_amount_EUR else 0 end as Warranties_cost_landed_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "W" then sin.Avg_unit_price_group_landed_amount_USD else 0 end as Warranties_cost_landed_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "W"  then sin.Avg_unit_price_group_landed_amount_transaction_cur else 0 end as Warranties_cost_landed_transaction_cur,

  # Split the Average unit price group landed - amount so that we have only the returs on warranties
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "RW"  then sin.Avg_unit_price_group_landed_amount_EUR else 0 end as Returns_on_warranties_cost_landed_EUR,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "RW"  then sin.Avg_unit_price_group_landed_amount_USD else 0 end as Returns_on_warranties_cost_landed_USD,
  case when not(sin.Rebate_TF) and sin.Fee_type is null and Exclude_in_global_management_reporting_TF = false and sin.Sales_order_type = "RW"  then sin.Avg_unit_price_group_landed_amount_transaction_cur else 0 end as Returns_on_warranties_cost_landed_transaction_cur,

  # Customer - Dmensions
  # -------------------------------------------------------------
  sin.Customer_no,
  sin.Customer_name,
  sin.Grandparent_customer_no,
  sin.Grandparent_customer_name,  
  sin.Customer,
  sin.Customer_branch,
  sin.related_customer_group,
  sin.customer_and_supplier_flag,
  sin.webservice_integration_type,
  sin.key_account_type,

  # Supplier - Dmensions
  # -------------------------------------------------------------
  sin.Main_supplier_no,
  sin.Main_supplier_quality_type,

  # Customer (Geographic) - Dimensions
  # -------------------------------------------------------------
  sin.Statistic_country,
  sin.Statistic_country_iso, 
  sin.Macro_region,
  sin.micro_region,
  sin.Super_region,
  sin.Region,
  sin.Sub_region,
  sin.growth_segment, #BI-12723
  
  # Company - Dimensions
  # -------------------------------------------------------------
  sin.Company,
  sin.Company_descr,
  sin.Logistics_company,
  sin.Logistics_company_descr,
  sin.Division,
  sin.Territory,
  sin.Territory_code,
  sin.Shipping_company,
  sin.Shipping_company_descr,
  
  # Customer-Company - Dimensions
  # -------------------------------------------------------------
  sin.Accounts_receivable_group,
  sin.Accounts_receivable_group_descr,
  sin.sales_channel_description,
  sin.sales_channel_code,
 
  # Part (Grouping) - Dimensions
  # -------------------------------------------------------------
  sin.Business_line,
  sin.Sub_business_line,
  sin.Sub_business_line_descr,
  sin.Business_line_SEM_2020,
  sin.Sub_business_line_SEM_2020,
  sin.Sub_business_line_descr_SEM_2020,
  sin.Part_group,
  sin.Part_group_descr,
  sin.Part_group_main_group,
  sin.Part_group_level_1,
  sin.Part_group_level_2,
  sin.Part_group_level_3,
  sin.Part_group_level_4,
  sin.Part_group_level_5,      
  sin.product_category, # BI-10530
  sin.product_subcategory,
  sin.product_class,
  sin.product_type,
  sin.category_id_code,
  sin.category_id_level,
  sin.Article_type,
  sin.Article_type_descr,

  sin.equipment_market,
  coalesce(sin.equipment_sub_market, concat(sin.equipment_market,"-OTHER")) as equipment_sub_market,  -- To prevent issues with null values in Tableau level of detail
  sin.equipment_category,
  sin.equipment_type,
  sin.equipment_id_code,
  sin.equipment_id_code_formatted,
  sin.equipment_id_description,
  sin.equipment_id_level,

  sin.product_growth_classification_macro_region,
  sin.product_growth_classification_division,

  sin.Market,
  sin.competitor_range,

  CAST(sin.BEPCO_sales_availability_code as STRING) AS BEPCO_sales_availability_code,
  CASE sin.BEPCO_sales_availability_code
      when 0 then ""
      when 1 then "Sellable and searchable and displayed on MBF"
      when 2 then "Sellable and searchable but not displayed on MBF"
      when 3 then "Searchable only via internal programs, sellable to all customers"
      when 4 then "N/A"
      when 5 then "Searchable only via internal programs. Not sellable at all."
      when null then null
  END AS BEPCO_sales_availability_description,
  has_agri_reference,
  sin.primary_vendor_no, 
  sin.primary_vendor_name, 

  # Agri fields
  # -------------------------------------------------------------
  sin.AGRI_product_family_code,
  sin.AGRI_product_family_description,
  sin.AGRI_product_sub_family_code,
  sin.AGRI_product_sub_family_description,
  sin.AGRI_product_sub_sub_family_code,
  sin.AGRI_product_sub_sub_family_description,
  sin.AGRI_product_sector,
  sin.AGRI_product_sub_sector,

  # Pre-calcuated LOD dimensions for performance reason (used in Tableau workbook)
  # We also include the level "order" or "other" so that we can isolate the order lines on which we need to calculate effects
  # -------------------------------------------------------------------------------------------------------------------------
  
  # SKU no
  CONCAT(
    case 
      when sin.Rebate_TF then "rebate" 
      when not(sin.Fee_type is null) then "fee" 
      when sin.Sales_order_type = "O" then "order" 
      when sin.Sales_order_type = "R" then "return" 
      when sin.Sales_order_type = "W" then "warranty"
      when sin.Sales_order_type = "RW" then "return_on_warranty"
      else "unknown"
    end, "-",
    CAST(sin.sku_no as STRING), "-", sin.Currency_transaction) 
  as LOD_dimension_SKU,

  # SKU + Equipment id + country
  CONCAT(
    case 
      when sin.Rebate_TF then "rebate" 
      when not(sin.Fee_type is null) then "fee" 
      when sin.Sales_order_type = "O" then "order" 
      when sin.Sales_order_type = "R" then "return" 
      when sin.Sales_order_type = "W" then "warranty"
      when sin.Sales_order_type = "RW" then "return_on_warranty"
      else "unknown"
    end, "-",
    CAST(sin.sku_no as STRING), "-", IFNULL(CAST(sin.equipment_id_code AS STRING),"Undefined"), "-", sin.Statistic_country_iso, "-", sin.Currency_transaction)
  as LOD_dimension_SKU_equipment_id_country,

    # SKU + Equipment id + country
    CONCAT(
        CASE 
            WHEN sin.Rebate_TF THEN "rebate" 
            WHEN NOT(sin.Fee_type IS NULL) THEN "fee" 
            WHEN sin.Sales_order_type = "O" THEN "order" 
            WHEN sin.Sales_order_type = "R" THEN "return" 
            WHEN sin.Sales_order_type = "W" THEN "warranty"
            WHEN sin.Sales_order_type = "RW" THEN "return_on_warranty"
            ELSE "unknown"
        END, "-",       CAST(sin.sku_no as STRING), "-", sin.Statistic_country_iso, "-", sin.Currency_transaction) AS LOD_dimension_SKU_country,

  #BI-10984
  sin.part_state,
  sin.sku_responsible_workgroup,
  sin.sku_responsible_workgroup_code,

  # TVH Part no & Customer
  CONCAT(
    case 
      when sin.Rebate_TF then "rebate" 
      when not(sin.Fee_type is null) then "fee" 
      when sin.Sales_order_type = "O" then "order" 
      when sin.Sales_order_type = "R" then "return" 
      when sin.Sales_order_type = "W" then "warranty"
      when sin.Sales_order_type = "RW" then "return_on_warranty"
      else "unknown"
    end, "-",
    CAST(sin.TVH_part_no as STRING), "-", IFNULL(sin.Related_customer_group, sin.Customer_no), "-", sin.Currency_transaction)
  as LOD_dimension_TVH_part_no_customer,

  # Exchange rates - Dimensions
  # -------------------------------------------------------------
  sin.Rate_to_AED,
  sin.Rate_to_AUD,
  sin.Rate_to_BRL,
  sin.Rate_to_CAD,
  sin.Rate_to_CNY,
  sin.Rate_to_GBP,
  sin.Rate_to_MXN,
  sin.Rate_to_MYR,
  sin.Rate_to_NZD,
  sin.Rate_to_PLN,
  sin.Rate_to_RUB,
  sin.Rate_to_SEK,
  sin.Rate_to_SGD,
  sin.Rate_to_TRY,
  sin.Rate_to_ZAR,

  # Global reporting filter
  sin.Exclude_in_global_management_reporting_TF,

  # Stocking filter
  sin.is_stocking_item,

  # Unit
  sin.unit,  

  # Acquisition fields
  acq.company_acquisition_date,
  acq.source,
  acq.source_group,
  ifnull(int.is_integrated,false) as is_integrated,

  
  case
      when date_trunc(company_acquisition_date,year) between
         date_add(date_trunc(Sales_invoice_date,year), interval -1 year) and date_add(date_trunc(Sales_invoice_date,year), interval 1 year)
      and ifnull(is_integrated,false) = true
      and extract (year from company_acquisition_date) in (2025,2026) 
      and extract (year from Sales_invoice_date) in (2025,2026)
      then true else false
  end as is_integrated_flag,

  # BRM grouping

  /*
  case
      when sin.sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB','SML') then territory
      when sin.company in ('GMPBE','UH','A7') then 'PNS'
      else sin.statistic_country_iso
  end as brm_grouping,


  
  case
      when sin.sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB','SML','TVH BE','BEPCO LA') then sin.sales_channel_description
      when sin.source_system != 'Link' and sin.company in ('GMPBE','UH','A7') then 'PNS'
      else sin.sub_region
  end as brm_grouping_sales_team,
  */

  case
      when sin.sales_channel_code in ('USA','SMM','SMC','SSI','FSIP') then territory
      when sin.company in ('GMPBE','UH','A7') then 'PNS'
      else sin.statistic_country_iso
  end as brm_grouping,  

  case
      when sin.sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB') then sin.sales_channel_description
      when sin.sales_channel_code in ('TVH BE','BEPCO LA','SML') then sin.statistic_country_iso
      when (sin.source_system != 'Link' and sin.company in ('GMPBE','UH','A7')) then 'PNS'
      else sin.sub_region
  end as brm_grouping_sales_team, 
  

  # For rls
  sin.Industry


, IF(FORMAT_DATE('%m%d', sales_invoice_date) BETWEEN '0317' AND '0430', TRUE,FALSE) AS is_in_cyberattack_exclusion_period,
sin.part_rotation_type,
sin.Price_group,
  
FROM
  {{ref('stg_sales_invoices_filtered')}} sin

LEFT JOIN
  {{ ref('stg_cleaned_waterfall_customer_flagging')}} acq
  on acq.customer_code = sin.customer_no

LEFT JOIN
    {{ref('stg_integrations')}} int
      on  acq.source = int.source
      AND sin.company = int.company
      AND sin.product_subcategory = int.product_subcategory
      AND sin.TVH_no_Brand_code = int.TVH_no_Brand_code
      AND sin.equipment_market = int.equipment_market
      AND coalesce(sin.equipment_sub_market, concat(sin.equipment_market,"-OTHER")) = int.equipment_sub_market
      AND sin.region = int.region
      AND sin.Statistic_country = int.Statistic_country














