{{ config(
    materialized='table',
    partition_by={
      "field": "period",
      "data_type": "date",
      "granularity": "month"
    },
    cluster_by="sub_region"
) }}

--- Getting the DATA FOR LINK SALES
with total_sales_link as (

        select

          'Link' as record_source,
          'Actual' as data_type,
          date_trunc(sales_invoice_date,month) as period,
          currency_transaction,
          macro_region,
          super_region,
          region,
          sub_region,
          equipment_market,
          equipment_sub_market,
          statistic_country,
          statistic_country_iso,
          division,
          company_descr as company_description,
          company as company_code,
          sales_channel_code,
          sales_channel_description,
          industry,
          territory_code,
          territory as territory_description,
          product_category,
          product_subcategory,
          product_class,
          product_type,
          
          TVH_no_brand_code,
          TVH_no_brand_descr,

          growth_segment,
          product_growth_classification_division,
          product_growth_classification_macro_region,

          grandparent_customer_name,
          grandparent_customer_no,
          key_account_type,

          sum(delivered_amount_transaction_cur) as sales_amount_transaction_currency,
          sum(delivered_amount_EUR) as sales_amount_EUR,
          sum(delivered_amount_USD) as sales_amount_USD,
          sum(delivered_amount_transaction_cur * rate_to_brl)  as sales_amount_BRL,            
          sum(delivered_amount_transaction_cur * rate_to_cad)  as sales_amount_CAD,
          sum(delivered_amount_transaction_cur * rate_to_mxn)  as sales_amount_MXN,            

          null as sales_amount_margin_transaction_currency,
          null as sales_amount_margin_EUR,
          null as sales_amount_margin_USD,
          null as sales_amount_margin_BRL,            
          null as sales_amount_margin_CAD,
          null as sales_amount_margin_MXN,

          null as Fees_sales_transaction_currency,
          null as Fees_sales_EUR,
          null as Fees_sales_USD,
          null as Fees_sales_BRL,
          null as Fees_sales_CAD,
          null as Fees_sales_MXN,

          null as Rebates_sales_transaction_currency,
          null as Rebates_sales_EUR,
          null as Rebates_sales_USD,
          null as Rebates_sales_BRL,
          null as Rebates_sales_CAD,
          null as Rebates_sales_MXN,

          null as warranties_sales_transaction_currency,
          null as warranties_sales_EUR,
          null as warranties_sales_USD,
          null as warranties_sales_BRL,
          null as warranties_sales_CAD,
          null as warranties_sales_MXN,

          null as returns_on_warranties_sales_transaction_currency,
          null as returns_on_warranties_sales_EUR,
          null as returns_on_warranties_sales_USD,
          null as returns_on_warranties_sales_BRL,
          null as returns_on_warranties_sales_CAD,
          null as returns_on_warranties_sales_MXN,

          null as returns_sales_transaction_currency,
          null as returns_sales_EUR,
          null as returns_sales_USD,
          null as returns_sales_BRL,
          null as returns_sales_CAD,
          null as returns_sales_MXN,

          null as orders_sales_EUR,
          null as orders_sales_USD,
          null as orders_sales_BRL,
          null as orders_sales_CAD,
          null as orders_sales_MXN,
          null as orders_sales_transaction_currency,

          null as orders_quantity,

          null as orders_cost_landed_transaction_currency,
          null as orders_cost_landed_EUR,
          null as orders_cost_landed_USD,
          null as orders_cost_landed_BRL,
          null as orders_cost_landed_CAD,
          null as orders_cost_landed_MXN,

          null as fees_cost_landed_transaction_currency,
          null as fees_cost_landed_EUR,
          null as fees_cost_landed_USD,
          null as fees_cost_landed_BRL,
          null as fees_cost_landed_CAD,
          null as fees_cost_landed_MXN,

          null as warranties_cost_landed_transaction_currency,
          null as warranties_cost_landed_EUR,
          null as warranties_cost_landed_USD,
          null as warranties_cost_landed_BRL,
          null as warranties_cost_landed_CAD,
          null as warranties_cost_landed_MXN,

          null as returns_on_warranties_cost_landed_transaction_currency,
          null as returns_on_warranties_cost_landed_EUR,
          null as returns_on_warranties_cost_landed_USD,
          null as returns_on_warranties_cost_landed_BRL,
          null as returns_on_warranties_cost_landed_CAD,
          null as returns_on_warranties_cost_landed_MXN,

          null as returns_cost_landed_transaction_currency,
          null as returns_cost_landed_EUR,
          null as returns_cost_landed_USD,
          null as returns_cost_landed_BRL,
          null as returns_cost_landed_CAD,
          null as returns_cost_landed_MXN,

          null as noncommercial_cost_landed_transaction_currency,
          null as noncommercial_cost_landed_EUR,
          null as noncommercial_cost_landed_USD,
          null as noncommercial_cost_landed_BRL,
          null as noncommercial_cost_landed_CAD,
          null as noncommercial_cost_landed_MXN,                

    from {{ref('stg_sales_invoices_filtered')}}
        where extract(year from sales_invoice_date) >= 2024
    group by all


),

--- Getting the DATA FOR MARGIN CALCULATION
margin_sales as (


        select

          record_source,
          'Actual' as data_type,
          period as period,
          currency_transaction,
          macro_region,
          super_region,
          region,
          sub_region,
          equipment_market,
          equipment_sub_market,
          statistic_country,
          statistic_country_iso,
          division,
          Company_descr as company_description,
          Company as company_code,
          sales_channel_code,
          sales_channel_description,
          industry,
          territory_code,
          territory_description,
          product_category,
          product_subcategory,
          product_class,
          product_type,

          TVH_no_brand_code,
          TVH_no_brand_descr,

          growth_segment,
          product_growth_classification_division,
          product_growth_classification_macro_region,

          grandparent_customer_name,
          grandparent_customer_no,
          key_account_type,                    

          null as sales_amount_transaction_currency,
          null as sales_amount_EUR,
          null as sales_amount_USD,
          null as sales_amount_BRL,            
          null as sales_amount_CAD,
          null as sales_amount_MXN,          

          sales_amount_transaction_currency as sales_amount_margin_transaction_currency,
          sales_amount_EUR as sales_amount_margin_EUR,
          sales_amount_USD as sales_amount_margin_USD,
          sales_amount_BRL  as sales_amount_margin_BRL,            
          sales_amount_CAD  as sales_amount_margin_CAD,
          sales_amount_MXN  as sales_amount_margin_MXN,

          Fees_sales_transaction_currency,
          Fees_sales_EUR,
          Fees_sales_USD,
          Fees_sales_BRL,
          Fees_sales_CAD,
          Fees_sales_MXN,

          Rebates_sales_transaction_currency,
          Rebates_sales_EUR,
          Rebates_sales_USD,
          Rebates_sales_BRL,
          Rebates_sales_CAD,
          Rebates_sales_MXN,

          warranties_sales_transaction_currency,
          warranties_sales_EUR,
          warranties_sales_USD,
          warranties_sales_BRL,
          warranties_sales_CAD,
          warranties_sales_MXN,

          returns_on_warranties_sales_transaction_currency,
          returns_on_warranties_sales_EUR,
          returns_on_warranties_sales_USD,
          returns_on_warranties_sales_BRL,
          returns_on_warranties_sales_CAD,
          returns_on_warranties_sales_MXN,

          returns_sales_transaction_currency,
          returns_sales_EUR,
          returns_sales_USD,
          returns_sales_BRL,
          returns_sales_CAD,
          returns_sales_MXN,

          orders_sales_EUR,
          orders_sales_USD,
          orders_sales_BRL,
          orders_sales_CAD,
          orders_sales_MXN,
          orders_sales_transaction_currency,

          orders_quantity,

          orders_cost_landed_transaction_currency,
          orders_cost_landed_EUR,
          orders_cost_landed_USD,
          orders_cost_landed_BRL,
          orders_cost_landed_CAD,
          orders_cost_landed_MXN,

          fees_cost_landed_transaction_currency,
          fees_cost_landed_EUR,
          fees_cost_landed_USD,
          fees_cost_landed_BRL,
          fees_cost_landed_CAD,
          fees_cost_landed_MXN,

          warranties_cost_landed_transaction_currency,
          warranties_cost_landed_EUR,
          warranties_cost_landed_USD,
          warranties_cost_landed_BRL,
          warranties_cost_landed_CAD,
          warranties_cost_landed_MXN,

          returns_on_warranties_cost_landed_transaction_currency,
          returns_on_warranties_cost_landed_EUR,
          returns_on_warranties_cost_landed_USD,
          returns_on_warranties_cost_landed_BRL,
          returns_on_warranties_cost_landed_CAD,
          returns_on_warranties_cost_landed_MXN,

          returns_cost_landed_transaction_currency,
          returns_cost_landed_EUR,
          returns_cost_landed_USD,
          returns_cost_landed_BRL,
          returns_cost_landed_CAD,
          returns_cost_landed_MXN,

          noncommercial_cost_landed_transaction_currency,   
          noncommercial_cost_landed_EUR,
          noncommercial_cost_landed_USD,
          noncommercial_cost_landed_BRL,
          noncommercial_cost_landed_CAD,
          noncommercial_cost_landed_MXN,              

        from (

              select  
                  --- Calculation level
                    'Link' as record_source,
                    currency_transaction,
                    equipment_market,
                    ifnull(equipment_sub_market, concat(equipment_market,"-OTHER")) as equipment_sub_market,
                    macro_region,
                    super_region,
                    sub_region,
                    region,
                    Statistic_country,
                    Statistic_country_iso,
                    Division,
                    Company_descr,
                    Company,
                    sales_channel_code,
                    sales_channel_description,
                    Industry,
                    date_trunc(Sales_invoice_date, month) as Period,
                    Territory as territory_description,
                    territory_code,
                    product_category,
                    product_subcategory,
                    product_class,
                    product_type,

                    TVH_no_brand_code,
                    TVH_no_brand_descr,

                    growth_segment,
                    product_growth_classification_division,
                    product_growth_classification_macro_region,

                    grandparent_customer_name,
                    grandparent_customer_no,
                    key_account_type,                                        

                  --- Sales
                    sum(Delivered_amount_transaction_cur)                             as sales_amount_transaction_currency,
                    sum(Delivered_amount_EUR)                                         as sales_amount_EUR,
                    sum(Delivered_amount_USD)                                         as sales_amount_USD,
                    sum(Delivered_amount_transaction_cur * Rate_to_BRL)               as sales_amount_BRL,
                    sum(Delivered_amount_transaction_cur * Rate_to_CAD)               as sales_amount_CAD,
                    sum(Delivered_amount_transaction_cur * Rate_to_MXN)               as sales_amount_MXN,                    

                    sum(Fees_sales_transaction_cur)                                   as Fees_sales_transaction_currency,
                    sum(Fees_sales_EUR)                                               as Fees_sales_EUR,
                    sum(Fees_sales_USD)                                               as Fees_sales_USD,
                    sum(Fees_sales_transaction_cur * Rate_to_BRL)                     as Fees_sales_BRL,
                    sum(Fees_sales_transaction_cur * Rate_to_CAD)                     as Fees_sales_CAD,
                    sum(Fees_sales_transaction_cur * Rate_to_MXN)                     as Fees_sales_MXN,                    

                    sum(Rebates_sales_transaction_cur)                                as Rebates_sales_transaction_currency,
                    sum(Rebates_sales_EUR)                                            as Rebates_sales_EUR,
                    sum(Rebates_sales_USD)                                            as Rebates_sales_USD,
                    sum(Rebates_sales_transaction_cur * Rate_to_BRL)                  as Rebates_sales_BRL,
                    sum(Rebates_sales_transaction_cur * Rate_to_CAD)                  as Rebates_sales_CAD,
                    sum(Rebates_sales_transaction_cur * Rate_to_MXN)                  as Rebates_sales_MXN,

                    sum(Warranties_sales_transaction_cur)                             as warranties_sales_transaction_currency,
                    sum(warranties_sales_EUR)                                         as warranties_sales_EUR,
                    sum(warranties_sales_USD)                                         as warranties_sales_USD,
                    sum(warranties_sales_transaction_cur * Rate_to_BRL)               as warranties_sales_BRL,
                    sum(warranties_sales_transaction_cur * Rate_to_CAD)               as warranties_sales_CAD,
                    sum(warranties_sales_transaction_cur * Rate_to_MXN)               as warranties_sales_MXN,

                    sum(Returns_on_warranties_sales_transaction_cur)                  as returns_on_warranties_sales_transaction_currency,
                    sum(returns_on_warranties_sales_EUR)                              as returns_on_warranties_sales_EUR,
                    sum(returns_on_warranties_sales_USD)                              as returns_on_warranties_sales_USD,
                    sum(returns_on_warranties_sales_transaction_cur * Rate_to_BRL)    as returns_on_warranties_sales_BRL,
                    sum(returns_on_warranties_sales_transaction_cur * Rate_to_CAD)    as returns_on_warranties_sales_CAD,
                    sum(returns_on_warranties_sales_transaction_cur * Rate_to_MXN)    as returns_on_warranties_sales_MXN,

                    sum(Returns_sales_transaction_cur)                                as returns_sales_transaction_currency,
                    sum(returns_sales_EUR)                                            as returns_sales_EUR,
                    sum(returns_sales_USD)                                            as returns_sales_USD,
                    sum(returns_sales_transaction_cur * Rate_to_BRL)                  as returns_sales_BRL,
                    sum(returns_sales_transaction_cur * Rate_to_CAD)                  as returns_sales_CAD,
                    sum(returns_sales_transaction_cur * Rate_to_MXN)                  as returns_sales_MXN,

                    sum(orders_sales_EUR)                                             as orders_sales_EUR,
                    sum(orders_sales_USD)                                             as orders_sales_USD,
                    sum(orders_sales_transaction_cur * Rate_to_BRL)                   as orders_sales_BRL,
                    sum(orders_sales_transaction_cur * Rate_to_CAD)                   as orders_sales_CAD,
                    sum(orders_sales_transaction_cur * Rate_to_MXN)                   as orders_sales_MXN,
                    sum(orders_sales_transaction_cur)                                 as orders_sales_transaction_currency,
                  
                  --- QTY
                    sum(ifnull(orders_quantity,0)) as orders_quantity,
                  
                  --- Cost
                    sum(Orders_cost_landed_transaction_cur)                              as orders_cost_landed_transaction_currency,
                    sum(Orders_cost_landed_EUR)                                          as orders_cost_landed_EUR,
                    sum(Orders_cost_landed_USD)                                          as orders_cost_landed_USD,
                    sum(Orders_cost_landed_transaction_cur * Rate_to_BRL)                as orders_cost_landed_BRL,
                    sum(Orders_cost_landed_transaction_cur * Rate_to_CAD)                as orders_cost_landed_CAD,
                    sum(Orders_cost_landed_transaction_cur * Rate_to_MXN)                as orders_cost_landed_MXN,

                    sum(Fees_cost_landed_transaction_cur)                                as fees_cost_landed_transaction_currency,
                    sum(Fees_cost_landed_EUR)                                            as fees_cost_landed_EUR,
                    sum(Fees_cost_landed_USD)                                            as fees_cost_landed_USD,
                    sum(Fees_cost_landed_transaction_cur * Rate_to_BRL)                  as fees_cost_landed_BRL,
                    sum(Fees_cost_landed_transaction_cur * Rate_to_CAD)                  as fees_cost_landed_CAD,
                    sum(Fees_cost_landed_transaction_cur * Rate_to_MXN)                  as Fees_cost_landed_MXN,

                    sum(Warranties_cost_landed_transaction_cur)                          as warranties_cost_landed_transaction_currency,
                    sum(Warranties_cost_landed_EUR)                                      as warranties_cost_landed_EUR,
                    sum(Warranties_cost_landed_USD)                                      as warranties_cost_landed_USD,
                    sum(Warranties_cost_landed_transaction_cur * Rate_to_BRL)            as warranties_cost_landed_BRL,
                    sum(Warranties_cost_landed_transaction_cur * Rate_to_CAD)            as warranties_cost_landed_CAD,
                    sum(Warranties_cost_landed_transaction_cur * Rate_to_MXN)            as warranties_cost_landed_MXN,

                    sum(Returns_on_warranties_cost_landed_transaction_cur)               as returns_on_warranties_cost_landed_transaction_currency,
                    sum(Returns_on_warranties_cost_landed_EUR)                           as returns_on_warranties_cost_landed_EUR,
                    sum(Returns_on_warranties_cost_landed_USD)                           as returns_on_warranties_cost_landed_USD,
                    sum(Returns_on_warranties_cost_landed_transaction_cur * Rate_to_BRL) as returns_on_warranties_cost_landed_BRL,
                    sum(Returns_on_warranties_cost_landed_transaction_cur * Rate_to_CAD) as returns_on_warranties_cost_landed_CAD,
                    sum(Returns_on_warranties_cost_landed_transaction_cur * Rate_to_MXN) as returns_on_warranties_cost_landed_MXN,

                    sum(Returns_cost_landed_transaction_cur)                             as returns_cost_landed_transaction_currency,
                    sum(Returns_cost_landed_EUR)                                         as returns_cost_landed_EUR,
                    sum(Returns_cost_landed_USD)                                         as returns_cost_landed_USD,
                    sum(Returns_cost_landed_transaction_cur * Rate_to_BRL)               as returns_cost_landed_BRL,
                    sum(Returns_cost_landed_transaction_cur * Rate_to_CAD)               as returns_cost_landed_CAD,
                    sum(Returns_cost_landed_transaction_cur * Rate_to_MXN)               as returns_cost_landed_MXN,

                    sum(Noncommercial_cost_landed_transaction_cur)                       as noncommercial_cost_landed_transaction_currency,
                    sum(Noncommercial_cost_landed_EUR)                                   as noncommercial_cost_landed_EUR,
                    sum(Noncommercial_cost_landed_USD)                                   as noncommercial_cost_landed_USD,
                    sum(Noncommercial_cost_landed_transaction_cur * Rate_to_BRL)         as noncommercial_cost_landed_BRL,
                    sum(Noncommercial_cost_landed_transaction_cur * Rate_to_CAD)         as noncommercial_cost_landed_CAD,
                    sum(Noncommercial_cost_landed_transaction_cur * Rate_to_MXN)         as noncommercial_cost_landed_MXN,                    

              from {{ref('stg_profit_analysis_2023')}}
                                  where extract(YEAR from sales_invoice_date) in (2024,2025,2026)                                 
                group by all
        )
),

total_sales_non_link as (

        select

          'Non-link' as record_source,
          'Actual' as data_type,
          sales_period as period,
          currency_company as currency_transaction,
          macro_region,
          super_region,
          region,
          sub_region,
          equipment_market,
          equipment_sub_market,
          statistic_country,
          statistic_country_iso,
          division,
          company_description as company_description,
          company_code as company_code,
          sales_channel_code,
          sales_channel_description,
          industry,
          territory_code,
          territory_description as territory_description,
          cast(null as string) as product_category,
          cast(null as string) as product_subcategory,
          cast(null as string) as product_class,
          cast(null as string) as product_type,

          cast(null as string) as brand_code,
          cast(null as string) as brand_description,

          cast(null as string) as growth_segment,
          cast(null as string) as product_growth_classification_division,
          cast(null as string) as product_growth_classification_macro_region,

          cast(null as string) as grandparent_customer_name,
          cast(null as string) as grandparent_customer_no,
          cast(null as string) as key_account_type,                              

          sales_amount_company_cur as sales_amount_transaction_currency,
          sales_amount_EUR,
          sales_amount_USD,
          sales_amount_BRL,            
          sales_amount_CAD,
          sales_amount_MXN,          

          null as sales_amount_transaction_currency,
          null as sales_amount_margin_EUR,
          null as sales_amount_margin_USD,
          null as sales_amount_margin_BRL,            
          null as sales_amount_margin_CAD,
          null as sales_amount_margin_MXN,

          null as Fees_sales_transaction_currency,
          null as Fees_sales_EUR,
          null as Fees_sales_USD,
          null as Fees_sales_BRL,
          null as Fees_sales_CAD,
          null as Fees_sales_MXN,

          null as Rebates_sales_transaction_currency,
          null as Rebates_sales_EUR,
          null as Rebates_sales_USD,
          null as Rebates_sales_BRL,
          null as Rebates_sales_CAD,
          null as Rebates_sales_MXN,

          null as warranties_sales_transaction_currency,
          null as warranties_sales_EUR,
          null as warranties_sales_USD,
          null as warranties_sales_BRL,
          null as warranties_sales_CAD,
          null as warranties_sales_MXN,

          null as returns_on_warranties_sales_transaction_currency,
          null as returns_on_warranties_sales_EUR,
          null as returns_on_warranties_sales_USD,
          null as returns_on_warranties_sales_BRL,
          null as returns_on_warranties_sales_CAD,
          null as returns_on_warranties_sales_MXN,

          null as returns_sales_transaction_currency,
          null as returns_sales_EUR,
          null as returns_sales_USD,
          null as returns_sales_BRL,
          null as returns_sales_CAD,
          null as returns_sales_MXN,

          null as orders_sales_EUR,
          null as orders_sales_USD,
          null as orders_sales_BRL,
          null as orders_sales_CAD,
          null as orders_sales_MXN,
          null as orders_sales_transaction_currency,

          null as orders_quantity,

          null as orders_cost_landed_transaction_currency,
          null as orders_cost_landed_EUR,
          null as orders_cost_landed_USD,
          null as orders_cost_landed_BRL,
          null as orders_cost_landed_CAD,
          null as orders_cost_landed_MXN,

          null as fees_cost_landed_transaction_currency,
          null as fees_cost_landed_EUR,
          null as fees_cost_landed_USD,
          null as fees_cost_landed_BRL,
          null as fees_cost_landed_CAD,
          null as fees_cost_landed_MXN,

          null as warranties_cost_landed_transaction_currency,
          null as warranties_cost_landed_EUR,
          null as warranties_cost_landed_USD,
          null as warranties_cost_landed_BRL,
          null as warranties_cost_landed_CAD,
          null as warranties_cost_landed_MXN,

          null as returns_on_warranties_cost_landed_transaction_currency,
          null as returns_on_warranties_cost_landed_EUR,
          null as returns_on_warranties_cost_landed_USD,
          null as returns_on_warranties_cost_landed_BRL,
          null as returns_on_warranties_cost_landed_CAD,
          null as returns_on_warranties_cost_landed_MXN,

          null as returns_cost_landed_transaction_currency,
          null as returns_cost_landed_EUR,
          null as returns_cost_landed_USD,
          null as returns_cost_landed_BRL,
          null as returns_cost_landed_CAD,
          null as returns_cost_landed_MXN,

          null as noncommercial_cost_landed_transaction_currency,
          null as noncommercial_cost_landed_EUR,
          null as noncommercial_cost_landed_USD,
          null as noncommercial_cost_landed_BRL,
          null as noncommercial_cost_landed_CAD,
          null as noncommercial_cost_landed_MXN                  

    from {{ ref('int_sales_non_link_companies_territory')}}
        where extract(year from sales_period) >= 2024
        and company_code <> 'TVPMO'

),

total_sales_non_link_accounting as (

        select

          'Non-link' as record_source,
          'Actual' as data_type,
          sales_period as period,
          currency_company as currency_transaction,
          macro_region,
          super_region,
          region,
          sub_region,
          equipment_market,
          equipment_sub_market,
          statistic_country,
          statistic_country_iso,
          division,
          company_description as company_description,
          company_code as company_code,
          sales_channel_code,
          sales_channel_description,
          industry,
          cast(null as string) as territory_code,
          cast(null as string) as territory_description,
          cast(null as string) as product_category,
          cast(null as string) as product_subcategory,
          cast(null as string) as product_class,
          cast(null as string) as product_type,

          cast(null as string) as brand_code,
          cast(null as string) as brand_description,

          cast(null as string) as growth_segment,
          cast(null as string) as product_growth_classification_division,
          cast(null as string) as product_growth_classification_macro_region,

          cast(null as string) as grandparent_customer_name,
          cast(null as string) as grandparent_customer_no,
          cast(null as string) as key_account_type,                              

          sales_amount_company_currency as sales_amount_transaction_currency,
          sales_amount_EUR,
          sales_amount_USD,
          sales_amount_BRL,            
          sales_amount_CAD,
          sales_amount_MXN,          

          null as sales_amount_margin_transaction_currency,
          null as sales_amount_margin_EUR,
          null as sales_amount_margin_USD,
          null as sales_amount_margin_BRL,            
          null as sales_amount_margin_CAD,
          null as sales_amount_margin_MXN,

          null as Fees_sales_transaction_currency,
          null as Fees_sales_EUR,
          null as Fees_sales_USD,
          null as Fees_sales_BRL,
          null as Fees_sales_CAD,
          null as Fees_sales_MXN,

          null as Rebates_sales_transaction_currency,
          null as Rebates_sales_EUR,
          null as Rebates_sales_USD,
          null as Rebates_sales_BRL,
          null as Rebates_sales_CAD,
          null as Rebates_sales_MXN,

          null as warranties_sales_transaction_currency,
          null as warranties_sales_EUR,
          null as warranties_sales_USD,
          null as warranties_sales_BRL,
          null as warranties_sales_CAD,
          null as warranties_sales_MXN,

          null as returns_on_warranties_sales_transaction_currency,
          null as returns_on_warranties_sales_EUR,
          null as returns_on_warranties_sales_USD,
          null as returns_on_warranties_sales_BRL,
          null as returns_on_warranties_sales_CAD,
          null as returns_on_warranties_sales_MXN,

          null as returns_sales_transaction_currency,
          null as returns_sales_EUR,
          null as returns_sales_USD,
          null as returns_sales_BRL,
          null as returns_sales_CAD,
          null as returns_sales_MXN,

          null as orders_sales_EUR,
          null as orders_sales_USD,
          null as orders_sales_BRL,
          null as orders_sales_CAD,
          null as orders_sales_MXN,
          null as orders_sales_transaction_currency,

          null as orders_quantity,

          null as orders_cost_landed_transaction_currency,
          null as orders_cost_landed_EUR,
          null as orders_cost_landed_USD,
          null as orders_cost_landed_BRL,
          null as orders_cost_landed_CAD,
          null as orders_cost_landed_MXN,

          null as fees_cost_landed_transaction_currency,
          null as fees_cost_landed_EUR,
          null as fees_cost_landed_USD,
          null as fees_cost_landed_BRL,
          null as fees_cost_landed_CAD,
          null as fees_cost_landed_MXN,

          null as warranties_cost_landed_transaction_currency,
          null as warranties_cost_landed_EUR,
          null as warranties_cost_landed_USD,
          null as warranties_cost_landed_BRL,
          null as warranties_cost_landed_CAD,
          null as warranties_cost_landed_MXN,

          null as returns_on_warranties_cost_landed_transaction_currency,
          null as returns_on_warranties_cost_landed_EUR,
          null as returns_on_warranties_cost_landed_USD,
          null as returns_on_warranties_cost_landed_BRL,
          null as returns_on_warranties_cost_landed_CAD,
          null as returns_on_warranties_cost_landed_MXN,

          null as returns_cost_landed_transaction_currency,
          null as returns_cost_landed_EUR,
          null as returns_cost_landed_USD,
          null as returns_cost_landed_BRL,
          null as returns_cost_landed_CAD,
          null as returns_cost_landed_MXN,

          null as noncommercial_cost_landed_transaction_currency,
          null as noncommercial_cost_landed_EUR,
          null as noncommercial_cost_landed_USD,
          null as noncommercial_cost_landed_BRL,
          null as noncommercial_cost_landed_CAD,
          null as noncommercial_cost_landed_MXN                  

    from {{ref('stg_sales_non_link_accounting_data')}}
        where extract(year from sales_period) >= 2024

),

main as (
select * from total_sales_link
union all
select * from margin_sales
union all
select * from total_sales_non_link
union all
select * from total_sales_non_link_accounting
),

/* 
final as (

select 
      main.*,
      # Keeping the budget rates fields for now to keep dashboard live. This fields can be removed in future.
      budget_rates.budget_rate_eur_CY as budget_rate_eur,
      budget_rates.budget_rate_usd_CY as budget_rate_usd,
      budget_rates.budget_rate_brl_CY as budget_rate_brl,
      budget_rates.budget_rate_cad_CY as budget_rate_cad,
      budget_rates.budget_rate_mxn_CY as budget_rate_mxn,

      budget_rates.budget_rate_eur_CY,
      budget_rates.budget_rate_usd_CY,
      budget_rates.budget_rate_brl_CY,
      budget_rates.budget_rate_cad_CY,
      budget_rates.budget_rate_mxn_CY,
      budget_rates.budget_rate_eur_PY,
      budget_rates.budget_rate_usd_PY,
      budget_rates.budget_rate_brl_PY,
      budget_rates.budget_rate_cad_PY,
      budget_rates.budget_rate_mxn_PY,
      case
          when sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB') then sales_channel_description
          when sales_channel_code in ('TVH BE','BEPCO LA','SML') then statistic_country_iso
          when (record_source != 'Link' and company_code in ('GMPBE','UH','A7')) then 'PNS'
          else sub_region
      end as brm_grouping_sales_team_calc

from main

LEFT JOIN (
    SELECT
      
      currency_from,
      
      min(case when budget_year = EXTRACT(Year FROM CURRENT_DATE()) AND currency_to = 'EUR' then budget_exchange_rate else null end) as budget_rate_eur_CY,
      min(case when budget_year = EXTRACT(Year FROM CURRENT_DATE()) AND currency_to = 'USD' then budget_exchange_rate else null end) as budget_rate_usd_CY,
      min(case when budget_year = EXTRACT(Year FROM CURRENT_DATE()) AND currency_to = 'BRL' then budget_exchange_rate else null end) as budget_rate_brl_CY,
      min(case when budget_year = EXTRACT(Year FROM CURRENT_DATE()) AND currency_to = 'CAD' then budget_exchange_rate else null end) as budget_rate_cad_CY,
      min(case when budget_year = EXTRACT(Year FROM CURRENT_DATE()) AND currency_to = 'MXN' then budget_exchange_rate else null end) as budget_rate_mxn_CY,

      min(case when budget_year = EXTRACT(Year FROM CURRENT_DATE())-1 AND currency_to = 'EUR' then budget_exchange_rate else null end) as budget_rate_eur_PY,
      min(case when budget_year = EXTRACT(Year FROM CURRENT_DATE())-1 AND currency_to = 'USD' then budget_exchange_rate else null end) as budget_rate_usd_PY,
      min(case when budget_year = EXTRACT(Year FROM CURRENT_DATE())-1 AND currency_to = 'BRL' then budget_exchange_rate else null end) as budget_rate_brl_PY,
      min(case when budget_year = EXTRACT(Year FROM CURRENT_DATE())-1 AND currency_to = 'CAD' then budget_exchange_rate else null end) as budget_rate_cad_PY,
      min(case when budget_year = EXTRACT(Year FROM CURRENT_DATE())-1 AND currency_to = 'MXN' then budget_exchange_rate else null end) as budget_rate_mxn_PY

  FROM
    {{ref('stg_financial_sales_budget_exchangerates')}}
  WHERE
      currency_to IN ('EUR','USD','BRL','CAD','MXN')
      AND EXTRACT(YEAR FROM budget_month) IN (EXTRACT(YEAR FROM CURRENT_DATE()), EXTRACT(YEAR FROM CURRENT_DATE()) - 1)
  GROUP BY
      
      currency_from) budget_rates ON 
        currency_transaction = budget_rates.currency_from 
        


where extract(year from period) >= 2024

)
*/

final as (

select 
      main.*,
      budget_rates.budget_rate_eur,
      budget_rates.budget_rate_usd,
      budget_rates.budget_rate_brl,
      budget_rates.budget_rate_cad,
      budget_rates.budget_rate_mxn,
      case
          when sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB') then sales_channel_description
          when sales_channel_code in ('TVH BE','BEPCO LA','SML') then statistic_country_iso
          when (record_source != 'Link' and company_code in ('GMPBE','UH','A7')) then 'PNS'
          else sub_region
      end as brm_grouping_sales_team_calc

from main

LEFT JOIN (
    SELECT
      budget_month,
      currency_from,
      min(case when currency_to = 'EUR' then budget_exchange_rate else null end) as budget_rate_eur,
      min(case when currency_to = 'USD' then budget_exchange_rate else null end) as budget_rate_usd,
      min(case when currency_to = 'BRL' then budget_exchange_rate else null end) as budget_rate_brl,
      min(case when currency_to = 'CAD' then budget_exchange_rate else null end) as budget_rate_cad,
      min(case when currency_to = 'MXN' then budget_exchange_rate else null end) as budget_rate_mxn,

  FROM
    {{ref('stg_financial_sales_budget_exchangerates')}}
  WHERE
      currency_to IN ('EUR','USD','BRL','CAD','MXN')
  GROUP BY
      budget_month,
      currency_from) budget_rates ON 
        currency_transaction = budget_rates.currency_from 
        AND date_trunc(period, month) = budget_rates.budget_month

where extract(year from period) >= 2024

)

select
      final.*,
      {{ territory_for_sales_teams('final.territory_code', 'final.company_code', 'final.statistic_country_iso') }}
          as territory_for_sales_teams,
      brm.brm_grouping_sales_team,
      brm.brm_grouping_region,
      brm.brm_grouping_super_region,
      brm.brm_grouping_macro_region,
      brm.brm_grouping_macro_region_ext,
      {{ sales_team_columns('stt') }}
from final

    left join
    (
      select
        distinct
        brm_grouping_sales_team_calc,
        brm_grouping_sales_team,
        brm_grouping_region,
        brm_grouping_super_region,
        brm_grouping_macro_region,
        brm_grouping_macro_region_ext
      from {{ref('int_brm_structure')}}
    ) brm
      on brm.brm_grouping_sales_team_calc = final.brm_grouping_sales_team_calc
    left join {{ ref('stg_territory_sales_teams') }} stt
      on stt.territory_for_salesteams_code =
         {{ territory_for_sales_teams('final.territory_code', 'final.company_code', 'final.statistic_country_iso') }}