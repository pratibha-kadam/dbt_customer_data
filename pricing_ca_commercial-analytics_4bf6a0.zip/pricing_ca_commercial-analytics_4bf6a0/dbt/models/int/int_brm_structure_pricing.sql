with brm_sales_team_calc as (

select

distinct

  case
      when sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB') then sales_channel_description
      when sales_channel_code in ('TVH BE','BEPCO LA','SML') then statistic_country_iso
      else sub_region
  end as brm_grouping_sales_team_calc 

from {{ref('stg_sales_invoices_filtered_sls')}}


),

brm_sales_team as (

select
    *,
    case
        when brm_grouping_sales_team_calc in ('Americas - Latin America','Americas by TVH Parts NV','BRAZIL','LATIN AMERICA','Latin America by BEPCO Parts SA') then 'OTHER SOUTH AMERICA'
        when brm_grouping_sales_team_calc in ('Americas - Brazil') then 'SMB'
        when brm_grouping_sales_team_calc in ('Americas - Canada') then 'SMC'
        when brm_grouping_sales_team_calc in ('Americas - Mexico') then 'SMM'
        when brm_grouping_sales_team_calc in ('Americas - USA') then 'USA'
        when brm_grouping_sales_team_calc in ('CANADA','MEXICO','USA') then 'OTHER NORTH AMERICA'
        when brm_grouping_sales_team_calc in ('Superior Signals') then 'SSI'
        when brm_grouping_sales_team_calc in ('HN','DO','US','NI','HT','PR','GT','SV') then 'NORTH LATAM'
        when brm_grouping_sales_team_calc in ('CO','CR','EC','GF','GY','PA','PE','SR', 'VE') then 'MIDDLE LATAM'
        when brm_grouping_sales_team_calc in ('AR','BO','CL','PY','UY') then 'SOUTH LATAM'
        when brm_grouping_sales_team_calc in ('BR') then 'BRAZIL'
        when length(brm_grouping_sales_team_calc) = 2 then 'OTHER SOUTH AMERICA'
        else brm_grouping_sales_team_calc
    end as brm_grouping_sales_team
from brm_sales_team_calc

),

brm_region as (

select
    *,
    case
        when brm_grouping_sales_team in ('AUSTRALIA','NEW ZEALAND') then 'OCEANIA'
        when brm_grouping_sales_team in ('BELUX','NETHERLANDS') then 'BENELUX'
        when brm_grouping_sales_team in ('CHINA') then 'CHINA'
        when brm_grouping_sales_team in ('EAST ASIA','SAARC','SEA') then 'ASIA'
        when brm_grouping_sales_team in ('MIDDLE EAST','NORTHERN AFRICA','SOUTHERN AFRICA','TURKIYE') then 'META'
        -- when brm_grouping_sales_team in ('NORTH EASTERN EUROPE','POLAND','SOUTH EASTERN EUROPE') then 'EASTERN EUROPE'
        when brm_grouping_sales_team in ('NORTH EASTERN EUROPE', 'SOUTH EASTERN EUROPE', 'SOUTH-CENTRAL EASTERN EUROPE') then 'EASTERN EUROPE'
        when brm_grouping_sales_team in ('POLAND') then 'POLAND'
        when brm_grouping_sales_team in ('DACH') then 'DACH'
        else brm_grouping_sales_team
    end as brm_grouping_region
from brm_sales_team

),

brm_super_region as (

select
    *,
    case
        when brm_grouping_region in ('ASIA','CHINA','OCEANIA') then 'APAC'
        when brm_grouping_region in ('BENELUX','NORDICS','UK/IRELAND') then 'NORTHERN EUROPE'
        when brm_grouping_region in ('META') then 'META'
        when brm_grouping_region in ('EASTERN EUROPE', 'POLAND', 'DACH') then 'CENTRAL EUROPE'
        when brm_grouping_region in ('Flight Systems','OTHER NORTH AMERICA','SMC','SMM','SSI','USA') then 'NORTH AMERICA'
        when brm_grouping_region in ('FRANCE','IBERICA','ITALY') then 'SOUTHERN EUROPE'
        when brm_grouping_region in ('SMB','OTHER SOUTH AMERICA','NORTH LATAM','MIDDLE LATAM','SOUTH LATAM','BRAZIL') then 'SOUTH AMERICA'
        else brm_grouping_region
    end as brm_grouping_super_region
from brm_region

),

brm_macro_region as (

select
    *,
    case
        when brm_grouping_super_region in ('META','NORTHERN EUROPE','SOUTHERN EUROPE', 'CENTRAL EUROPE') then 'EMEA'
        when brm_grouping_super_region in ('NORTH AMERICA','SOUTH AMERICA') then 'AMERICAS'
        else brm_grouping_super_region
    end as brm_grouping_macro_region,

    case
        when brm_grouping_super_region in ('META','NORTHERN EUROPE','SOUTHERN EUROPE', 'CENTRAL EUROPE') then 'EMEA'
        else brm_grouping_super_region
    end as brm_grouping_macro_region_ext

from brm_super_region

)

select distinct  * from brm_macro_region