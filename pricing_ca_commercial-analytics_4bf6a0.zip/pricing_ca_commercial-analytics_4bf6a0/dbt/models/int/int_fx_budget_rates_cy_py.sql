-- int_fx_budget_rates_cy_py.sql
{{ config(materialized='view') }}

with rates as (

    select
        budget_year,
        currency_from,
        min(if(currency_to = 'EUR', budget_exchange_rate, null)) as budget_rate_eur,
        min(if(currency_to = 'USD', budget_exchange_rate, null)) as budget_rate_usd,
        min(if(currency_to = 'BRL', budget_exchange_rate, null)) as budget_rate_brl,
        min(if(currency_to = 'CAD', budget_exchange_rate, null)) as budget_rate_cad,
        min(if(currency_to = 'MXN', budget_exchange_rate, null)) as budget_rate_mxn
    from {{ ref('stg_financial_sales_budget_exchangerates') }}
    where currency_to in ('EUR','USD','BRL','CAD','MXN')
    group by budget_year, currency_from   -- drops budget_month: rate is constant within a year

),

year_bounds as (
    -- CY = latest budget year with rates loaded; PY = CY - 1.
    -- Rolls forward automatically the moment next year's rates land.
    select max(budget_year) as current_year from rates
),

final as (

    select
        r.currency_from,

        max(if(r.budget_year = yb.current_year,     r.budget_rate_eur, null)) as budget_rate_eur_cy,
        max(if(r.budget_year = yb.current_year,     r.budget_rate_usd, null)) as budget_rate_usd_cy,
        max(if(r.budget_year = yb.current_year,     r.budget_rate_brl, null)) as budget_rate_brl_cy,
        max(if(r.budget_year = yb.current_year,     r.budget_rate_cad, null)) as budget_rate_cad_cy,
        max(if(r.budget_year = yb.current_year,     r.budget_rate_mxn, null)) as budget_rate_mxn_cy,

        max(if(r.budget_year = yb.current_year - 1, r.budget_rate_eur, null)) as budget_rate_eur_py,
        max(if(r.budget_year = yb.current_year - 1, r.budget_rate_usd, null)) as budget_rate_usd_py,
        max(if(r.budget_year = yb.current_year - 1, r.budget_rate_brl, null)) as budget_rate_brl_py,
        max(if(r.budget_year = yb.current_year - 1, r.budget_rate_cad, null)) as budget_rate_cad_py,
        max(if(r.budget_year = yb.current_year - 1, r.budget_rate_mxn, null)) as budget_rate_mxn_py

    from rates r
    cross join year_bounds yb
    group by r.currency_from

)

select * from final