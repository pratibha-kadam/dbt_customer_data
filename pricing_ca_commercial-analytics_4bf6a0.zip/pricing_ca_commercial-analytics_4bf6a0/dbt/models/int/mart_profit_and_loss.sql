{{ config(
    materialized='table',
    partition_by={
      "field": "period",
      "data_type": "date",
      "granularity": "month"
    },
    cluster_by="sub_region"
) }}

with main as (

select * from {{ref('int_profit_and_loss_agg')}}
union all
select * from {{ref('int_profit_and_loss_budget_agg')}}

)

select 

      main.*,
      brm.brm_grouping_sales_team,
      brm.brm_grouping_region,
      brm.brm_grouping_super_region,
      brm.brm_grouping_macro_region,
      brm.brm_grouping_macro_region_ext,
      {{ sales_team_columns('stt') }}


from main

    left join
    (
      select
        distinct
        brm_grouping_sales_team_calc,
        brm_grouping_sales_team,
        brm_grouping_region,
        brm_grouping_super_region,
        brm_grouping_macro_region,
        brm_grouping_macro_region_ext
      from {{ref('int_brm_structure')}}
    ) brm
      on brm.brm_grouping_sales_team_calc = main.brm_grouping_sales_team_calc
    left join {{ ref('stg_territory_sales_teams') }} stt
      on stt.territory_for_salesteams_code = main.territory_for_sales_teams