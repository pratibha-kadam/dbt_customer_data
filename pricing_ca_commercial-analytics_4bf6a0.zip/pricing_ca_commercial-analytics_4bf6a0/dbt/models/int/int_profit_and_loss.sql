with budget_exhange_rates as (

SELECT
      budget_month,
      currency_from,
      min(case when currency_to = 'EUR' then budget_exchange_rate else null end) as budget_rate_eur,
      min(case when currency_to = 'USD' then budget_exchange_rate else null end) as budget_rate_usd,
      min(case when currency_to = 'BRL' then budget_exchange_rate else null end) as budget_rate_brl,
      min(case when currency_to = 'CAD' then budget_exchange_rate else null end) as budget_rate_cad,
      min(case when currency_to = 'MXN' then budget_exchange_rate else null end) as budget_rate_mxn,

  FROM
    {{ref('stg_financial_sales_budget_exchangerates')}}
  WHERE
      currency_to IN ('EUR','USD','BRL','CAD','MXN')
      and budget_year = 2026
  GROUP BY
      budget_month,
      currency_from

),


--- Getting the DATA FOR LINK FREIGHT
total_freight_link as (

        select

          'Link' as source_actuals,
          'Actual' as data_type,
          date_trunc(shipment_date,month) as period,
          customer_macro_region as macro_region,
          customer_super_region as super_region,
          customer_region as region,
          customer_sub_region as sub_region,
          equipment_market,
          equipment_sub_market,
          statistic_country,
          statistic_country_iso,
          sales_channel_code,
          sales_channel_description,

          case
            when sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB') then sales_channel_description
            when sales_channel_code in ('TVH BE','BEPCO LA','SML') then statistic_country_iso
            else customer_sub_region
          end as brm_grouping_sales_team_calc,
          {{ territory_for_sales_teams('cast(null as string)', 'cast(null as string)', 'statistic_country_iso') }}
              as territory_for_sales_teams,
          null as sales_amount_EUR,
          null as sales_amount_USD,
          null as sales_amount_BRL,
          null as sales_amount_CAD,
          null as sales_amount_MXN,

          null as sales_amount_fx_neutral_EUR,
          null as sales_amount_fx_neutral_USD,
          null as sales_amount_fx_neutral_BRL,
          null as sales_amount_fx_neutral_CAD,
          null as sales_amount_fx_neutral_MXN,                     

          sum(freight_income_EUR) as freight_income_EUR,
          sum(freight_income_EUR * rate_usd) as freight_income_USD,
          sum(freight_income_EUR * rate_brl) as freight_income_BRL,
          sum(freight_income_EUR * rate_cad) as freight_income_CAD,
          sum(freight_income_EUR * rate_mxn) as freight_income_MXN,

          sum(freight_income_currency_cust * budget_rate_eur) as freight_income_fx_neutral_EUR,
          sum(freight_income_currency_cust * budget_rate_usd) as freight_income_fx_neutral_USD,
          sum(freight_income_currency_cust * budget_rate_brl) as freight_income_fx_neutral_BRL,
          sum(freight_income_currency_cust * budget_rate_cad) as freight_income_fx_neutral_CAD,
          sum(freight_income_currency_cust * budget_rate_mxn) as freight_income_fx_neutral_MXN,          

          sum(freight_expense_system_EUR) as freight_expense_system_EUR,
          sum(freight_expense_system_EUR * rate_usd) as freight_expense_system_USD,
          sum(freight_expense_system_EUR * rate_brl) as freight_expense_system_BRL,
          sum(freight_expense_system_EUR * rate_cad) as freight_expense_system_CAD,
          sum(freight_expense_system_EUR * rate_mxn) as freight_expense_system_MXN,

          sum(freight_expense_system_currency_cust * budget_rate_eur) as freight_expense_system_fx_neutral_EUR,
          sum(freight_expense_system_currency_cust * budget_rate_usd) as freight_expense_system_fx_neutral_USD,
          sum(freight_expense_system_currency_cust * budget_rate_brl) as freight_expense_system_fx_neutral_BRL,
          sum(freight_expense_system_currency_cust * budget_rate_cad) as freight_expense_system_fx_neutral_CAD,
          sum(freight_expense_system_currency_cust * budget_rate_mxn) as freight_expense_system_fx_neutral_MXN,

          null as cost_landed_EUR,
          null as cost_landed_USD,
          null as cost_landed_BRL,
          null as cost_landed_CAD,
          null as cost_landed_MXN,

          null as cost_landed_fx_neutral_EUR,
          null as cost_landed_fx_neutral_USD,
          null as cost_landed_fx_neutral_BRL,
          null as cost_landed_fx_neutral_CAD,
          null as cost_landed_fx_neutral_MXN,

          null as cost_EUR,
          null as cost_USD,
          null as cost_BRL,
          null as cost_CAD,
          null as cost_MXN,

          null as cost_fx_neutral_EUR,
          null as cost_fx_neutral_USD,
          null as cost_fx_neutral_BRL,
          null as cost_fx_neutral_CAD,
          null as cost_fx_neutral_MXN,
    

    from {{ ref('stg_sales_orders_traffic')}}

      left join budget_exhange_rates
        on currency_from = invoice_currency
        and extract(month from shipment_date) = extract(month from budget_month)
    where extract(year from shipment_date) >= 2025

    --- Extra filters which are applied in the 'Transport insights' dashboard
    and accounts_receivable_group_description = 'External'
    and delivery_address_name is not null
    and intercompany_or_external = 'External'
    and is_pick_up = false
    and upper(freight_term) not in ('COLLECT','PICKUP','PICKUPEX')    

    group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15


),

--- Getting the DATA FOR MARGIN CALCULATION
total_sales_and_cost as (


        select

          source_actuals,
          'Actual' as data_type,
          period as period,
          macro_region,
          super_region,
          region,
          sub_region,
          equipment_market,
          equipment_sub_market,
          statistic_country,
          statistic_country_iso,
          sales_channel_code,
          sales_channel_description,

          case
              when sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB') then sales_channel_description
              when sales_channel_code in ('TVH BE','BEPCO LA','SML') then statistic_country_iso
              when (source_actuals != 'Link' and company in ('GMPBE','UH','A7')) then 'PNS'
              else sub_region
          end as brm_grouping_sales_team_calc, 
          {{ territory_for_sales_teams('territory_code', 'company', 'statistic_country_iso') }}
              as territory_for_sales_teams,

          sales_amount_EUR,
          sales_amount_USD,
          sales_amount_BRL,
          sales_amount_CAD,
          sales_amount_MXN,

          sales_amount_fx_neutral_EUR,
          sales_amount_fx_neutral_USD,
          sales_amount_fx_neutral_BRL,
          sales_amount_fx_neutral_CAD,
          sales_amount_fx_neutral_MXN,                    

          null as freight_income_EUR,
          null as freight_income_USD,
          null as freight_income_BRL,
          null as freight_income_CAD,
          null as freight_income_MXN,

          null as freight_income_fx_neutral_EUR,
          null as freight_income_fx_neutral_USD,
          null as freight_income_fx_neutral_BRL,
          null as freight_income_fx_neutral_CAD,
          null as freight_income_fx_neutral_MXN,          

          null as freight_expense_system_EUR,
          null as freight_expense_system_USD,
          null as freight_expense_system_BRL,
          null as freight_expense_system_CAD,
          null as freight_expense_system_MXN,

          null as freight_expense_system_fx_neutral_EUR,
          null as freight_expense_system_fx_neutral_USD,
          null as freight_expense_system_fx_neutral_BRL,
          null as freight_expense_system_fx_neutral_CAD,
          null as freight_expense_system_fx_neutral_MXN,         

          cost_landed_EUR,
          cost_landed_USD,
          cost_landed_BRL,
          cost_landed_CAD,
          cost_landed_MXN,

          cost_landed_fx_neutral_EUR,
          cost_landed_fx_neutral_USD,
          cost_landed_fx_neutral_BRL,
          cost_landed_fx_neutral_CAD,
          cost_landed_fx_neutral_MXN,

          cost_EUR,
          cost_USD,
          cost_BRL,
          cost_CAD,
          cost_MXN,

          cost_fx_neutral_EUR,
          cost_fx_neutral_USD,
          cost_fx_neutral_BRL,
          cost_fx_neutral_CAD,
          cost_fx_neutral_MXN,          


        from (

              select  
                  --- Calculation level
                    'Link' as source_actuals,
                    currency_transaction,
                    equipment_market,
                    ifnull(equipment_sub_market, concat(equipment_market,"-OTHER")) as equipment_sub_market,
                    macro_region,
                    super_region,
                    sub_region,
                    region,
                    Statistic_country,
                    Statistic_country_iso,
                    sales_channel_code,
                    sales_channel_description,
                    date_trunc(Sales_invoice_date, month) as Period,
                    Company,
                    territory_code, 

                  --- Sales - spot
                    sum(delivered_amount_transaction_cur)                                as sales_amount_transaction_currency,
                    sum(Delivered_amount_EUR)                                            as sales_amount_EUR,
                    sum(Delivered_amount_USD)                                            as sales_amount_USD,
                    sum(Delivered_amount_transaction_cur * Rate_to_BRL)                  as sales_amount_BRL,
                    sum(Delivered_amount_transaction_cur * Rate_to_CAD)                  as sales_amount_CAD,
                    sum(Delivered_amount_transaction_cur * Rate_to_MXN)                  as sales_amount_MXN,

                  --- Sales - FX neutral
                    sum(Delivered_amount_transaction_cur * budget_rate_eur)              as sales_amount_fx_neutral_EUR,
                    sum(Delivered_amount_transaction_cur * budget_rate_usd)              as sales_amount_fx_neutral_USD,
                    sum(Delivered_amount_transaction_cur * budget_rate_brl)              as sales_amount_fx_neutral_BRL,
                    sum(Delivered_amount_transaction_cur * budget_rate_cad)              as sales_amount_fx_neutral_CAD,
                    sum(Delivered_amount_transaction_cur * budget_rate_mxn)              as sales_amount_fx_neutral_MXN,                                        
                  
                  --- Cost landed - spot
                    sum(Orders_cost_landed_transaction_cur) + sum(Fees_cost_landed_transaction_cur) + sum(Warranties_cost_landed_transaction_cur) + sum(Returns_on_warranties_cost_landed_transaction_cur) + sum(Returns_cost_landed_transaction_cur) + sum(Noncommercial_cost_landed_transaction_cur) as cost_landed_transaction_currency,
                    sum(Orders_cost_landed_EUR) + sum(Fees_cost_landed_EUR) + sum(Warranties_cost_landed_EUR) + sum(Returns_on_warranties_cost_landed_EUR) + sum(Returns_cost_landed_EUR) + sum(Noncommercial_cost_landed_eur) as cost_landed_EUR,
                    sum(Orders_cost_landed_USD) + sum(Fees_cost_landed_USD) + sum(Warranties_cost_landed_USD) + sum(Returns_on_warranties_cost_landed_USD) + sum(Returns_cost_landed_USD) + sum(Noncommercial_cost_landed_usd) as cost_landed_USD,
                    sum(Orders_cost_landed_transaction_cur * Rate_to_BRL) + sum(Fees_cost_landed_transaction_cur * Rate_to_BRL) + sum(Warranties_cost_landed_transaction_cur * Rate_to_BRL) + sum(Returns_on_warranties_cost_landed_transaction_cur * Rate_to_BRL) + sum(Returns_cost_landed_transaction_cur * Rate_to_BRL) + sum(Noncommercial_cost_landed_transaction_cur * Rate_to_BRL) as cost_landed_BRL,
                    sum(Orders_cost_landed_transaction_cur * Rate_to_CAD) + sum(Fees_cost_landed_transaction_cur * Rate_to_CAD) + sum(Warranties_cost_landed_transaction_cur * Rate_to_CAD) + sum(Returns_on_warranties_cost_landed_transaction_cur * Rate_to_CAD) + sum(Returns_cost_landed_transaction_cur * Rate_to_CAD) + + sum(Noncommercial_cost_landed_transaction_cur * Rate_to_CAD) as cost_landed_CAD,
                    sum(Orders_cost_landed_transaction_cur * Rate_to_MXN) + sum(Fees_cost_landed_transaction_cur * Rate_to_MXN) + sum(Warranties_cost_landed_transaction_cur * Rate_to_MXN) + sum(Returns_on_warranties_cost_landed_transaction_cur * Rate_to_MXN) + sum(Returns_cost_landed_transaction_cur * Rate_to_MXN) + + sum(Noncommercial_cost_landed_transaction_cur * Rate_to_MXN) as cost_landed_MXN,

                  --- Cost landed - FX neutral
                    sum(Orders_cost_landed_transaction_cur * budget_rate_eur) + sum(Fees_cost_landed_transaction_cur * budget_rate_eur) + sum(Warranties_cost_landed_transaction_cur * budget_rate_eur) + sum(Returns_on_warranties_cost_landed_transaction_cur * budget_rate_eur) + sum(Returns_cost_landed_transaction_cur * budget_rate_eur) + sum(Noncommercial_cost_landed_transaction_cur * budget_rate_eur) as cost_landed_fx_neutral_EUR,
                    sum(Orders_cost_landed_transaction_cur * budget_rate_usd) + sum(Fees_cost_landed_transaction_cur * budget_rate_usd) + sum(Warranties_cost_landed_transaction_cur * budget_rate_usd) + sum(Returns_on_warranties_cost_landed_transaction_cur * budget_rate_usd) + sum(Returns_cost_landed_transaction_cur * budget_rate_usd) + sum(Noncommercial_cost_landed_transaction_cur * budget_rate_usd) as cost_landed_fx_neutral_USD,
                    sum(Orders_cost_landed_transaction_cur * budget_rate_brl) + sum(Fees_cost_landed_transaction_cur * budget_rate_brl) + sum(Warranties_cost_landed_transaction_cur * budget_rate_brl) + sum(Returns_on_warranties_cost_landed_transaction_cur * budget_rate_brl) + sum(Returns_cost_landed_transaction_cur * budget_rate_brl) + sum(Noncommercial_cost_landed_transaction_cur * budget_rate_brl) as cost_landed_fx_neutral_BRL,
                    sum(Orders_cost_landed_transaction_cur * budget_rate_cad) + sum(Fees_cost_landed_transaction_cur * budget_rate_cad) + sum(Warranties_cost_landed_transaction_cur * budget_rate_cad) + sum(Returns_on_warranties_cost_landed_transaction_cur * budget_rate_cad) + sum(Returns_cost_landed_transaction_cur * budget_rate_cad) + sum(Noncommercial_cost_landed_transaction_cur * budget_rate_cad) as cost_landed_fx_neutral_CAD,
                    sum(Orders_cost_landed_transaction_cur * budget_rate_mxn) + sum(Fees_cost_landed_transaction_cur * budget_rate_mxn) + sum(Warranties_cost_landed_transaction_cur * budget_rate_mxn) + sum(Returns_on_warranties_cost_landed_transaction_cur * budget_rate_mxn) + sum(Returns_cost_landed_transaction_cur * budget_rate_mxn) + sum(Noncommercial_cost_landed_transaction_cur * budget_rate_mxn) as cost_landed_fx_neutral_MXN,  

                 --- Cost - spot
                    sum(Orders_cost_transaction_cur) + sum(Fees_cost_transaction_cur) + sum(Warranties_cost_transaction_cur) + sum(Returns_on_warranties_cost_transaction_cur) + sum(Returns_cost_transaction_cur) as cost_transaction_currency,
                    sum(Orders_cost_EUR) + sum(Fees_cost_EUR) + sum(Warranties_cost_EUR) + sum(Returns_on_warranties_cost_EUR) + sum(Returns_cost_EUR) + sum(Noncommercial_cost_EUR) as cost_EUR,
                    sum(Orders_cost_USD) + sum(Fees_cost_USD) + sum(Warranties_cost_USD) + sum(Returns_on_warranties_cost_USD) + sum(Returns_cost_USD) + sum(Noncommercial_cost_USD) as cost_USD,
                    sum(Orders_cost_transaction_cur * Rate_to_BRL) + sum(Fees_cost_transaction_cur * Rate_to_BRL) + sum(Warranties_cost_transaction_cur * Rate_to_BRL) + sum(Returns_on_warranties_cost_transaction_cur * Rate_to_BRL) + sum(Returns_cost_transaction_cur * Rate_to_BRL) + sum(Noncommercial_cost_transaction_cur * Rate_to_BRL) as cost_BRL,
                    sum(Orders_cost_transaction_cur * Rate_to_CAD) + sum(Fees_cost_transaction_cur * Rate_to_CAD) + sum(Warranties_cost_transaction_cur * Rate_to_CAD) + sum(Returns_on_warranties_cost_transaction_cur * Rate_to_CAD) + sum(Returns_cost_transaction_cur * Rate_to_CAD) + sum(Noncommercial_cost_transaction_cur * Rate_to_CAD) as cost_CAD,
                    sum(Orders_cost_transaction_cur * Rate_to_MXN) + sum(Fees_cost_transaction_cur * Rate_to_MXN) + sum(Warranties_cost_transaction_cur * Rate_to_MXN) + sum(Returns_on_warranties_cost_transaction_cur * Rate_to_MXN) + sum(Returns_cost_transaction_cur * Rate_to_MXN) + sum(Noncommercial_cost_transaction_cur * Rate_to_MXN) as cost_MXN,

                  --- Cost - FX neutral
                    sum(Orders_cost_transaction_cur * budget_rate_eur) + sum(Fees_cost_transaction_cur * budget_rate_eur) + sum(Warranties_cost_transaction_cur * budget_rate_eur) + sum(Returns_on_warranties_cost_transaction_cur * budget_rate_eur) + sum(Returns_cost_transaction_cur * budget_rate_eur) + sum(Noncommercial_cost_transaction_cur * budget_rate_eur) as cost_fx_neutral_EUR,
                    sum(Orders_cost_transaction_cur * budget_rate_usd) + sum(Fees_cost_transaction_cur * budget_rate_usd) + sum(Warranties_cost_transaction_cur * budget_rate_usd) + sum(Returns_on_warranties_cost_transaction_cur * budget_rate_usd) + sum(Returns_cost_transaction_cur * budget_rate_usd) + sum(Noncommercial_cost_transaction_cur * budget_rate_usd) as cost_fx_neutral_USD,
                    sum(Orders_cost_transaction_cur * budget_rate_brl) + sum(Fees_cost_transaction_cur * budget_rate_brl) + sum(Warranties_cost_transaction_cur * budget_rate_brl) + sum(Returns_on_warranties_cost_transaction_cur * budget_rate_brl) + sum(Returns_cost_transaction_cur * budget_rate_brl) + sum(Noncommercial_cost_transaction_cur * budget_rate_brl) as cost_fx_neutral_BRL,
                    sum(Orders_cost_transaction_cur * budget_rate_cad) + sum(Fees_cost_transaction_cur * budget_rate_cad) + sum(Warranties_cost_transaction_cur * budget_rate_cad) + sum(Returns_on_warranties_cost_transaction_cur * budget_rate_cad) + sum(Returns_cost_transaction_cur * budget_rate_cad) + sum(Noncommercial_cost_transaction_cur * budget_rate_cad) as cost_fx_neutral_CAD,
                    sum(Orders_cost_transaction_cur * budget_rate_mxn) + sum(Fees_cost_transaction_cur * budget_rate_mxn) + sum(Warranties_cost_transaction_cur * budget_rate_mxn) + sum(Returns_on_warranties_cost_transaction_cur * budget_rate_mxn) + sum(Returns_cost_transaction_cur * budget_rate_mxn) + sum(Noncommercial_cost_transaction_cur * budget_rate_mxn) as cost_fx_neutral_MXN,                                                                         

              from {{ref('stg_profit_analysis_2023')}}

                left join budget_exhange_rates
                  on currency_from = currency_transaction
                  and extract(month from sales_invoice_date) = extract(month from budget_month)
              
              where extract(YEAR from sales_invoice_date) in (2025,2026)
              group by all
        )
),

total_sales_non_link as (

        select

          'Non-Link' as source_actuals,
          'Actual' as data_type,
          sales_period as period,
          macro_region,
          super_region,
          region,
          sub_region,
          equipment_market,
          equipment_sub_market,
          statistic_country,
          statistic_country_iso,
          sales_channel_code,
          sales_channel_description,

          case
              when sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB') then sales_channel_description
              when sales_channel_code in ('TVH BE','BEPCO LA','SML') then statistic_country_iso
              when company_code in ('GMPBE','UH','A7') then 'PNS'
              else sub_region
          end as brm_grouping_sales_team_calc, 
          {{ territory_for_sales_teams('territory_code', 'company_code', 'statistic_country_iso') }}
              as territory_for_sales_teams,

          sales_amount_EUR,
          sales_amount_USD,
          sales_amount_BRL,            
          sales_amount_CAD,
          sales_amount_MXN,

          sales_amount_company_cur * budget_rate_eur as sales_amount_fx_neutral_EUR,
          sales_amount_company_cur * budget_rate_usd as sales_amount_fx_neutral_USD,
          sales_amount_company_cur * budget_rate_brl as sales_amount_fx_neutral_BRL,
          sales_amount_company_cur * budget_rate_cad as sales_amount_fx_neutral_CAD,
          sales_amount_company_cur * budget_rate_mxn as sales_amount_fx_neutral_MXN,

          null as freight_income_EUR,
          null as freight_income_USD,
          null as freight_income_BRL,
          null as freight_income_CAD,
          null as freight_income_MXN,

          null as freight_income_fx_neutral_EUR,
          null as freight_income_fx_neutral_USD,
          null as freight_income_fx_neutral_BRL,
          null as freight_income_fx_neutral_CAD,
          null as freight_income_fx_neutral_MXN,          

          null as freight_expense_system_EUR,
          null as freight_expense_system_USD,
          null as freight_expense_system_BRL,
          null as freight_expense_system_CAD,
          null as freight_expense_system_MXN,

          null as freight_expense_system_fx_neutral_EUR,
          null as freight_expense_system_fx_neutral_USD,
          null as freight_expense_system_fx_neutral_BRL,
          null as freight_expense_system_fx_neutral_CAD,
          null as freight_expense_system_fx_neutral_MXN,

          null as cost_landed_EUR,
          null as cost_landed_USD,
          null as cost_landed_BRL,
          null as cost_landed_CAD,
          null as cost_landed_MXN,

          null as cost_landed_fx_neutral_EUR,
          null as cost_landed_fx_neutral_USD,
          null as cost_landed_fx_neutral_BRL,
          null as cost_landed_fx_neutral_CAD,
          null as cost_landed_fx_neutral_MXN,

          null as cost_EUR,
          null as cost_USD,
          null as cost_BRL,
          null as cost_CAD,
          null as cost_MXN,

          null as cost_fx_neutral_EUR,
          null as cost_fx_neutral_USD,
          null as cost_fx_neutral_BRL,
          null as cost_fx_neutral_CAD,
          null as cost_fx_neutral_MXN                    
       

    from {{ref('int_sales_non_link_companies_territory')}}

                left join budget_exhange_rates
                  on currency_from = currency_company
                  and extract(month from sales_period) = extract(month from budget_month)

        where extract(year from sales_period) >= 2025
        and company_code <> 'TVPMO'

),

total_sales_non_link_accounting as (

        select

          'Non-Link' as source_actuals,
          'Actual' as data_type,
          sales_period as period,
          macro_region,
          super_region,
          region,
          sub_region,
          equipment_market,
          equipment_sub_market,
          statistic_country,
          statistic_country_iso,
          sales_channel_code,
          sales_channel_description,

          case
              when sales_channel_code in ('USA','SMM','SMC','SSI','FSIP','SMB') then sales_channel_description
              when sales_channel_code in ('TVH BE','BEPCO LA','SML') then statistic_country_iso
              when company_code in ('GMPBE','UH','A7') then 'PNS'
              else sub_region
          end as brm_grouping_sales_team_calc, 
          {{ territory_for_sales_teams('cast(null as string)', 'company_code', 'statistic_country_iso') }}
              as territory_for_sales_teams,
              
          sales_amount_EUR,
          sales_amount_USD,
          sales_amount_BRL,            
          sales_amount_CAD,
          sales_amount_MXN,

          sales_amount_company_currency * budget_rate_eur as sales_amount_fx_neutral_EUR,
          sales_amount_company_currency * budget_rate_usd as sales_amount_fx_neutral_USD,
          sales_amount_company_currency * budget_rate_brl as sales_amount_fx_neutral_BRL,
          sales_amount_company_currency * budget_rate_cad as sales_amount_fx_neutral_CAD,
          sales_amount_company_currency * budget_rate_mxn as sales_amount_fx_neutral_MXN,

          null as freight_income_EUR,
          null as freight_income_USD,
          null as freight_income_BRL,
          null as freight_income_CAD,
          null as freight_income_MXN,

          null as freight_income_fx_neutral_EUR,
          null as freight_income_fx_neutral_USD,
          null as freight_income_fx_neutral_BRL,
          null as freight_income_fx_neutral_CAD,
          null as freight_income_fx_neutral_MXN,          

          null as freight_expense_system_EUR,
          null as freight_expense_system_USD,
          null as freight_expense_system_BRL,
          null as freight_expense_system_CAD,
          null as freight_expense_system_MXN,

          null as freight_expense_system_fx_neutral_EUR,
          null as freight_expense_system_fx_neutral_USD,
          null as freight_expense_system_fx_neutral_BRL,
          null as freight_expense_system_fx_neutral_CAD,
          null as freight_expense_system_fx_neutral_MXN,

          null as cost_landed_EUR,
          null as cost_landed_USD,
          null as cost_landed_BRL,
          null as cost_landed_CAD,
          null as cost_landed_MXN,

          null as cost_landed_fx_neutral_EUR,
          null as cost_landed_fx_neutral_USD,
          null as cost_landed_fx_neutral_BRL,
          null as cost_landed_fx_neutral_CAD,
          null as cost_landed_fx_neutral_MXN,

          null as cost_EUR,
          null as cost_USD,
          null as cost_BRL,
          null as cost_CAD,
          null as cost_MXN,

          null as cost_fx_neutral_EUR,
          null as cost_fx_neutral_USD,
          null as cost_fx_neutral_BRL,
          null as cost_fx_neutral_CAD,
          null as cost_fx_neutral_MXN           
      

    from {{ref('stg_sales_non_link_accounting_data')}}

      left join budget_exhange_rates
        on currency_from = currency_company
        and extract(month from sales_period) = extract(month from budget_month)
    where extract(year from sales_period) >= 2025
    and company_code <> 'TVPMO'

),

final as (
select * from total_sales_and_cost
union all
select * from total_freight_link
union all
select * from total_sales_non_link
union all
select * from total_sales_non_link_accounting
)

select 
      *
from final
where extract(year from period) >= 2025
