{{ config(
    materialized='table',
    partition_by={
      "field": "period",
      "data_type": "date",
      "granularity": "month"
    },
    cluster_by="sub_region"
) }}

with source as (
    select * from {{ ref('mart_freight_actuals_and_budget')}}
)
select * from source 