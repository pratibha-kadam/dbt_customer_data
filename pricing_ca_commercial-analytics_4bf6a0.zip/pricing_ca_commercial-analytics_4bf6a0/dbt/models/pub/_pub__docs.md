# https://docs.getdbt.com/docs/collaborate/documentation#using-docs-blocks

{% docs pub_<table_name> %}
    description of public table pub\_<table_name>
{% enddocs %}
