{{ config(
    materialized='table',
    cluster_by="brm_grouping_sales_team_calc"
) }}

with source as (
    select * from {{ ref('int_brm_structure_pricing')}}
)
select * from source 