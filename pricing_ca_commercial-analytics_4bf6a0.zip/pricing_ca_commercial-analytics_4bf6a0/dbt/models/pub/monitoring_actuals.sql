{{ config(
    materialized='table',
    partition_by={
      "field": "period",
      "data_type": "date",
      "granularity": "month"
    },
    cluster_by="sub_region"
) }}

with source as (
    select * from {{ ref('mart_monitoring_actuals')}}
)
select * from source 