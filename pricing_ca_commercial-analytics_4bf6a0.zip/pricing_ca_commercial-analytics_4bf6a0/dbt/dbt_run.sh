#!/bin/bash
mode=$1
dbt_target=$2
full_refresh=$3
dbt_models=$4

cd /var/tmp/dbt

if [ $mode = "run" ]; then
    echo "dbt Mode is run"
    if [ $full_refresh = "True" ]; then
        echo "Doing a full refresh"
        dbt run --target="$dbt_target" --profiles-dir=/var/tmp/dbt  --selector="$dbt_models" --full-refresh
    else
        echo "Not doing a full refresh"
        dbt run --target="$dbt_target" --profiles-dir=/var/tmp/dbt --selector="$dbt_models"
    fi
elif [ $mode = "debug" ]; then
    echo "dbt Mode is debug"
    dbt debug --profiles-dir=/var/tmp/dbt --target="$dbt_target"
elif [ $mode = "test" ] && [ "$dbt_target" = "dev" ]; then
    echo "dbt mode is test"
    dbt test --profiles-dir=/var/tmp/dbt --target="$dbt_target"  --select tag:dev --selector="$dbt_models"
elif [ $mode = "test" ] && [ "$dbt_target" != "dev" ]; then
    echo "dbt mode is test"
    dbt test --profiles-dir=/var/tmp/dbt --target="$dbt_target"  --select tag:prod --selector="$dbt_models"
elif [ $mode = "freshness" ] && [ "$dbt_target" != "dev" ]; then
    echo "dbt mode is freshness test"
    dbt source freshness --profiles-dir=/var/tmp/dbt --target="$dbt_target"
elif [ $mode = "snapshot" ] && [ "$dbt_target" != "dev" ]; then
    echo "dbt mode is snapshot"
    dbt snapshot --profiles-dir=/var/tmp/dbt --target="$dbt_target"
elif [ $mode = "seed" ] && [ "$dbt_target" != "dev" ]; then
    echo "dbt mode is seed"
    dbt seed --profiles-dir=/var/tmp/dbt --target="$dbt_target"
else
    echo -e "Incorrect dbt Mode $mode. Nothing to do"
fi