git config --global --unset http.sslcainfo \
& git config --global pull.rebase false \
& git config --global core.autocrlf true \
#& pip install sqlfluff \
#& pip install sqlfluff-templater-dbt \
#& pip install data-diff google-cloud-bigquery -U \
& dbt deps